-- NusaPet cloud schema. Static encyclopedia remains in versioned game packs; Supabase stores account/progress.
create extension if not exists pgcrypto;
create table if not exists users(id uuid primary key references auth.users(id) on delete cascade, created_at timestamptz default now());
create table if not exists profiles(id uuid primary key references users(id) on delete cascade, display_name text, created_at timestamptz default now());
create table if not exists species(id text primary key, category text not null, scientific_name text, content_version text not null);
create table if not exists creatures(id text primary key, species_id text references species(id), content_version text not null);
create table if not exists creature_localizations(creature_id text references creatures(id) on delete cascade, locale text not null, name text not null, primary key(creature_id,locale));
create table if not exists evolution_forms(id text primary key, creature_id text references creatures(id), stage int not null, content_version text not null);
create table if not exists evolution_paths(id text primary key, source_form text references evolution_forms(id), target_form text references evolution_forms(id), permanent boolean not null default true);
create table if not exists cross_evolution_paths(id text primary key, source_form text references evolution_forms(id), target_form text references evolution_forms(id), requirements jsonb not null);
create table if not exists artifacts(id text primary key, affinity text not null, rarity text not null, content_version text not null);
create table if not exists artifact_localizations(artifact_id text references artifacts(id) on delete cascade, locale text not null, name text not null, primary key(artifact_id,locale));
create table if not exists artifact_compatibility(artifact_id text references artifacts(id) on delete cascade, creature_id text references creatures(id) on delete cascade, affinity int not null default 0, primary key(artifact_id,creature_id));
create table if not exists armor_forms(id text primary key, creature_id text references creatures(id), artifact_id text references artifacts(id), minimum_stage int not null, content_version text not null);
create table if not exists armor_mastery(profile_id uuid references profiles(id) on delete cascade, artifact_id text references artifacts(id), mastery int not null default 0, primary key(profile_id,artifact_id));
create table if not exists taxonomy(creature_id text primary key references creatures(id), payload jsonb not null);
create table if not exists habitats(id text primary key, payload jsonb not null);
create table if not exists regions(id text primary key, payload jsonb not null);
create table if not exists encyclopedia_entries(creature_id text primary key references creatures(id), payload jsonb not null, published boolean not null default false);
create table if not exists encyclopedia_sources(id bigserial primary key, creature_id text references creatures(id), source jsonb not null);
create table if not exists player_creatures(id uuid primary key default gen_random_uuid(), profile_id uuid references profiles(id) on delete cascade, creature_id text references creatures(id), payload jsonb not null, updated_at timestamptz default now());
create table if not exists player_inventory(profile_id uuid references profiles(id) on delete cascade, item_id text not null, quantity int not null default 1, primary key(profile_id,item_id));
create table if not exists player_artifacts(profile_id uuid references profiles(id) on delete cascade, artifact_id text references artifacts(id), payload jsonb not null, primary key(profile_id,artifact_id));
create table if not exists player_stats(profile_id uuid primary key references profiles(id) on delete cascade, payload jsonb not null, updated_at timestamptz default now());
create table if not exists player_evolution_history(id bigserial primary key, profile_id uuid references profiles(id) on delete cascade, payload jsonb not null, created_at timestamptz default now());
create table if not exists player_discoveries(profile_id uuid references profiles(id) on delete cascade, discovery_id text not null, discovered_at timestamptz default now(), primary key(profile_id,discovery_id));
create table if not exists quests(id text primary key, payload jsonb not null);
create table if not exists player_quests(profile_id uuid references profiles(id) on delete cascade, quest_id text references quests(id), payload jsonb not null, primary key(profile_id,quest_id));
create table if not exists achievements(id text primary key, payload jsonb not null);
create table if not exists player_achievements(profile_id uuid references profiles(id) on delete cascade, achievement_id text references achievements(id), unlocked_at timestamptz default now(), primary key(profile_id,achievement_id));
create table if not exists settings(profile_id uuid primary key references profiles(id) on delete cascade, payload jsonb not null);
create table if not exists cloud_saves(id uuid primary key default gen_random_uuid(), profile_id uuid references profiles(id) on delete cascade, save_version int not null, content_version text not null, payload jsonb not null, checksum text, updated_at timestamptz default now());

create index if not exists idx_species_category on species(category);
create index if not exists idx_species_scientific on species(scientific_name);
create index if not exists idx_player_creatures_profile on player_creatures(profile_id);
create index if not exists idx_cloud_saves_profile_updated on cloud_saves(profile_id,updated_at desc);

create or replace function public.handle_new_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.users(id) values (new.id) on conflict (id) do nothing;
  insert into public.profiles(id, display_name) values (new.id, coalesce(new.raw_user_meta_data->>'display_name', new.email))
  on conflict (id) do update set display_name=excluded.display_name;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_auth_user();

alter table profiles enable row level security;
alter table player_creatures enable row level security;
alter table player_inventory enable row level security;
alter table player_artifacts enable row level security;
alter table player_stats enable row level security;
alter table player_evolution_history enable row level security;
alter table player_discoveries enable row level security;
alter table player_quests enable row level security;
alter table player_achievements enable row level security;
alter table settings enable row level security;
alter table cloud_saves enable row level security;

-- Application policies should be created in the deployment project using auth.uid() = profile_id.
-- No anonymous write policy is supplied here by design.


-- Minimal owner policies. Deployment may add stricter policies, but production must never expose cross-player writes.
drop policy if exists "profiles_self" on profiles;
create policy "profiles_self" on profiles for all using (id = auth.uid()) with check (id = auth.uid());
drop policy if exists "player_creatures_self" on player_creatures;
create policy "player_creatures_self" on player_creatures for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists "player_inventory_self" on player_inventory;
create policy "player_inventory_self" on player_inventory for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists "player_artifacts_self" on player_artifacts;
create policy "player_artifacts_self" on player_artifacts for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists "player_stats_self" on player_stats;
create policy "player_stats_self" on player_stats for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists "player_evolution_history_self" on player_evolution_history;
create policy "player_evolution_history_self" on player_evolution_history for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists "player_discoveries_self" on player_discoveries;
create policy "player_discoveries_self" on player_discoveries for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists "player_quests_self" on player_quests;
create policy "player_quests_self" on player_quests for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists "player_achievements_self" on player_achievements;
create policy "player_achievements_self" on player_achievements for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists "settings_self" on settings;
create policy "settings_self" on settings for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());
drop policy if exists "cloud_saves_self" on cloud_saves;
create policy "cloud_saves_self" on cloud_saves for all using (profile_id = auth.uid()) with check (profile_id = auth.uid());

-- Cloud-data deletion for the signed-in owner. Local user:// save is intentionally untouched.
create or replace function delete_my_cloud_data()
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  delete from users where id = auth.uid();
end;
$$;
revoke all on function delete_my_cloud_data() from public;
grant execute on function delete_my_cloud_data() to authenticated;
