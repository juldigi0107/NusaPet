extends SceneTree

func _init():
    var gs=preload("res://scripts/core/GameState.gd").new()
    gs._load_content(); gs.new_game()
    assert(gs.state.pet.stage==1)
    assert(gs.compatible_affinities("real_001").size()>=2)
    gs.hatch(); assert(gs.state.pet.hatched)
    var before=gs.state.pet.stats.bond; gs.act("pet"); assert(gs.state.pet.stats.bond>before)
    gs.state.pet.stage=3
    gs.state.pet.inventory.append("pusaka_rimba_01")
    gs.state.pet.discovered_artifacts.append("pusaka_rimba_01")
    var aid=gs.state.pet.inventory[0]; assert(gs.transform(aid))
    assert(not gs.state.pet.current_armor.is_empty())
    var mastery_before:=int(gs.state.pet.artifact_mastery.get("pusaka_rimba_01",0))
    gs.act("play")
    assert(int(gs.state.pet.artifact_mastery.get("pusaka_rimba_01",0))>=mastery_before)
    gs.revert_armor(); assert(gs.state.pet.current_armor.is_empty())
    # Evolution choice and offline resume invariants.
    gs.state.pet.pending_evolution_choice={"edge_ids": ["missing_a","missing_b"],"created_at":Time.get_unix_time_from_system()}
    assert(gs.state.pet.pending_evolution_choice.size()==2)
    gs.state.pet.pending_evolution_choice={}
    gs.state.pet.offline_evolution_pending=true
    gs.save_game(); assert(gs.load_game())
    assert(bool(gs.state.pet.offline_evolution_pending))
    gs.state.pet.offline_evolution_pending=false
    gs.save_game(); assert(gs.load_game())
    assert(str(gs.state.get("checksum","")).length()==64)
    assert(gs.current_creature().id==gs.state.pet.current_line_id)
    # Relevant research is required for Perfect Resonance; a generic global research score is insufficient.
    gs.state.pet.stage=6
    gs.state.pet.current_armor="armor_real_001_s6_rimba"
    gs.state.pet.resonance_form="resonance_real_001_RIMBA"
    gs.state.pet.stats.bond=99; gs.state.pet.stats.health=99; gs.state.pet.stats.happiness=99
    gs.state.pet.artifact_mastery["pusaka_rimba_01"]=100
    gs.state.player.research=999; gs.state.player.regional_mastery={"sumatra":100}
    gs.state.player.research_levels={"real_001":"OBSERVED"}
    assert(not gs.try_perfect_resonance())
    gs.state.player.research_levels["real_001"]="MASTERED"
    assert(gs.try_perfect_resonance())
    # Generation preserves the previous companion in Legacy and creates a new active pet.
    old_legacy:=gs.state.legacy.archive.size()
    assert(gs.can_start_new_generation())
    assert(gs.start_new_generation("real_002"))
    assert(gs.state.legacy.archive.size()==old_legacy+1)
    assert(gs.state.pet.creature_id=="real_002")
    print("UNIT TESTS PASS")
    quit(0)
