extends SceneTree
func _init():
    var gs=preload("res://scripts/core/GameState.gd").new()
    gs._load_content(); gs.new_game()
    assert(gs.state.pet.has("current_line_id"))
    assert(gs.state.pet.stage==1)
    var path="user://nusa_export_test.json"
    assert(gs.export_save(path))
    assert(FileAccess.file_exists(path))
    print("SAVE CONTRACT PASS")
    quit(0)
