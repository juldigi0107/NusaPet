extends SceneTree
func _init():
    var base="res://data/"
    var creatures=_read(base+"creatures/creatures.json"); var forms=_read(base+"evolutions/primary_forms.json"); var armor=_read(base+"armor-forms/armor_forms.json"); var cross=_read(base+"cross-evolutions/cross_paths.json"); var artifacts=_read(base+"artifacts/pusaka.json"); var dual=_read(base+"artifacts/dual_resonance.json")
    var errors=[]; var warnings=[]; var ids={}; var scientific={}; var form_ids={}; var content_hashes={}
    if creatures.size()!=350: errors.append("creatures != 350")
    if forms.size()!=2100: errors.append("forms != 2100")
    if armor.size()<700: errors.append("armor < 700")
    if cross.size()!=350: errors.append("cross != 350")
    if artifacts.size()!=15: errors.append("pusaka != 15")
    if dual.size()<1: errors.append("dual resonance missing")
    for c in creatures:
        if ids.has(c.id): errors.append("duplicate creature id "+str(c.id))
        ids[c.id]=true
        if not c.has("content_hash"): warnings.append("missing content hash: "+str(c.id))
        elif content_hashes.has(c.content_hash): warnings.append("duplicate content hash: "+str(c.id))
        else: content_hashes[c.content_hash]=c.id
        if not typeof(c.get("pusaka_compatibility",{}))==TYPE_DICTIONARY or c.pusaka_compatibility.size()<2: errors.append("compatibility <2 "+str(c.id))
        if c.get("locomotion_profile",[]).size()==0: errors.append("missing locomotion "+str(c.id))
        if c.category=="REAL":
            var sn=str(c.get("scientific_name","")); if sn.is_empty(): errors.append("missing scientific name "+str(c.id))
            elif scientific.has(sn): errors.append("duplicate REAL scientific name "+sn)
            else: scientific[sn]=true
            var tax=c.get("factual_data",{}).get("taxonomy",{})
            for k in ["kingdom","phylum","class","order","family","genus","species","rank"]:
                if str(tax.get(k,"")).is_empty(): errors.append("missing taxonomy.%s %s"%[k,c.id])
            if str(tax.get("kingdom",""))!="Animalia": errors.append("non-Animalia REAL "+str(c.id))
            if str(tax.get("species",""))!=sn: errors.append("taxonomy species mismatch "+str(c.id))
            if str(c.get("research_record",{}).get("status",""))!="PUBLISHED": warnings.append("REAL factual research not PUBLISHED: "+str(c.id))
        elif c.category in ["MYTHOLOGY","MYSTICAL"]:
            if str(c.get("cultural_review",{}).get("status",""))!="PUBLISHED": warnings.append("cultural review not PUBLISHED: "+str(c.id))
    if scientific.size()!=250: errors.append("unique REAL scientific names != 250")
    for f in forms:
        form_ids[f.id]=true
        if not f.has("content_hash"): warnings.append("missing form content hash: "+str(f.id))
        var asset_path=str(f.get("asset_manifest",{}).get("path",""))
        if asset_path.is_empty() or not FileAccess.file_exists(asset_path): errors.append("missing primary asset "+str(f.id))
        var base_id=str(f.id).split("_s")[0]
        if not ids.has(base_id): errors.append("orphan form "+str(f.id))
    for cid in ids.keys():
        var count=0
        for f in forms: if str(f.creature_line)==str(cid): count+=1
        if count!=6: errors.append("primary stage count for %s = %d"%[cid,count])
    var edges={}
    for e in cross:
        if not form_ids.has(e.source) or not form_ids.has(e.target): errors.append("orphan cross edge "+str(e.id))
        if e.source==e.target: errors.append("self-loop "+str(e.id))
        var edge_key=str(e.source)+">"+str(e.target); if edges.has(edge_key): errors.append("duplicate cross edge "+edge_key); edges[edge_key]=true
        if not e.has("rationale") or str(e.rationale.get("narrative",""))!="ORIGINAL GAME LORE": errors.append("cross rationale missing "+str(e.id))
        if not e.has("condition_weights"): errors.append("cross condition weights missing "+str(e.id))
    var armor_per={}
    for ar in armor:
        if not ids.has(ar.base_creature): errors.append("orphan armor "+str(ar.id))
        if not bool(ar.get("temporary",false)): errors.append("armor not temporary "+str(ar.id))
        armor_per[ar.base_creature]=int(armor_per.get(ar.base_creature,0))+1
        var armor_path=str(ar.get("asset_manifest",{}).get("path",""))
        if armor_path.is_empty() or not FileAccess.file_exists(armor_path): errors.append("missing armor asset "+str(ar.id))
    for cid in ids.keys(): if int(armor_per.get(cid,0))<2: errors.append("less than 2 armor forms for "+str(cid))
    print("NusaPet CONTENT GATE")
    print("350 lines / 250 REAL / 50 MYTHOLOGY / 50 MYSTICAL")
    print("2100 primary / %d armor / 350 cross / 15 pusaka / %d dual"%[armor.size(),dual.size()])
    print("unique REAL scientific names = %d"%scientific.size())
    for e in errors: print("ERROR: "+e)
    for w in warnings: print("WARNING: "+w)
    if errors.size()>0: quit(1)
    quit(0)
func _read(path):
    var f=FileAccess.open(path,FileAccess.READ)
    if f==null: return []
    var value=JSON.parse_string(f.get_as_text())
    return value if value!=null else []
