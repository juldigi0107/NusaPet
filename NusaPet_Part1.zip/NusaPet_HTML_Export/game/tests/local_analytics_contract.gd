extends SceneTree

func _init() -> void:
    var analytics = preload("res://scripts/core/LocalAnalytics.gd").new()
    analytics.set_enabled(false)
    analytics.record("must_not_record")
    assert(analytics.events.is_empty())
    analytics.set_enabled(true)
    analytics.record("care_action", {"action": "play"})
    assert(analytics.events.size() == 1)
    analytics.clear()
    assert(analytics.events.is_empty())
    analytics.set_enabled(false)
    print("LOCAL ANALYTICS CONTRACT PASS")
    quit(0)
