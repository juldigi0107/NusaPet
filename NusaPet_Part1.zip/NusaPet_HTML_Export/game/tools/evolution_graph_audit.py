#!/usr/bin/env python3
import json, sys
from collections import defaultdict, deque
ROOT='.'
forms=json.load(open(ROOT+'/data/evolutions/primary_forms.json'))
cross=json.load(open(ROOT+'/data/cross-evolutions/cross_paths.json'))
creatures=json.load(open(ROOT+'/data/creatures/creatures.json'))
errors=[]; warnings=[]
ids={x['id'] for x in creatures}
form_ids={x['id'] for x in forms}
for i,x in enumerate(forms):
    fid=x.get('id','')
    if not fid: errors.append(f'primary[{i}] missing id')
    if fid in form_ids and list(form_ids).count(fid)>1: errors.append(f'duplicate primary id {fid}')
    base=x.get('base_creature') or x.get('creature_line') or x.get('creature_id')
    if base not in ids: errors.append(f'{fid}: missing base creature {base}')
    stage=int(x.get('stage',0))
    if stage<1 or stage>6: errors.append(f'{fid}: invalid stage {stage}')
# cross paths
path_ids=set(); edges=defaultdict(list)
for i,x in enumerate(cross):
    pid=str(x.get('id',''))
    if not pid: errors.append(f'cross[{i}] missing id')
    if pid in path_ids: errors.append(f'duplicate cross path {pid}')
    path_ids.add(pid)
    src=str(x.get('from_form') or x.get('source','')); dst=str(x.get('to_form') or x.get('target',''))
    if src not in form_ids or dst not in form_ids: errors.append(f'{pid}: missing endpoint {src}->{dst}')
    if src==dst: errors.append(f'{pid}: self-loop')
    if src and dst and src in form_ids and dst in form_ids:
        ss=int(next(f for f in forms if f['id']==src).get('stage',0)); ds=int(next(f for f in forms if f['id']==dst).get('stage',0))
        if ds<ss: warnings.append(f'{pid}: reverse-stage edge {ss}->{ds}; allowed only if explicitly reversible')
        edges[src].append(dst)
    req=x.get('requirements',{})
    if not isinstance(req,dict) or not req: errors.append(f'{pid}: missing requirements')
    rat=x.get('rationale',{})
    basis=rat.get('basis',[]) if isinstance(rat,dict) else []
    if not basis: errors.append(f'{pid}: missing rationale basis')
# permanent stage reachability: every line has s1..s6
by={cid:[] for cid in ids}
for f in forms:
    base=f.get('base_creature') or f.get('creature_line') or f.get('creature_id')
    if base in by: by[base].append(int(f.get('stage',0)))
for cid,st in by.items():
    if sorted(st)!=[1,2,3,4,5,6]: errors.append(f'{cid}: primary stages are {sorted(st)}')
# cycle check for cross graph, report only cycles; reversible edges must carry explicit flag
color={}
def dfs(u,stack):
    color[u]=1; stack.append(u)
    for v in edges.get(u,[]):
        if color.get(v,0)==0:
            if dfs(v,stack): return True
        elif color.get(v)==1:
            errors.append('unapproved cross-evolution cycle: '+' -> '.join(stack+[v])); return True
    stack.pop(); color[u]=2; return False
for u in list(edges):
    if color.get(u,0)==0: dfs(u,[])
report={'errors':errors,'warnings':warnings,'counts':{'creatures':len(creatures),'primary_forms':len(forms),'cross_paths':len(cross)},'pass':not errors}
json.dump(report,open(ROOT+'/data/qa/evolution_graph_audit.json','w'),indent=2,ensure_ascii=False)
print(json.dumps(report,indent=2,ensure_ascii=False))
sys.exit(0 if not errors else 1)
