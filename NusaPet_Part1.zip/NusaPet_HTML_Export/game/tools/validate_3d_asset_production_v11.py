#!/usr/bin/env python3
import json, hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
creatures=json.load(open(ROOT/'data/creatures/creatures.json'))
manifest=json.load(open(ROOT/'data/assets/asset_manifest.json'))
items={x['asset_id']:x for x in manifest['items']}
profiles=json.load(open(ROOT/'data/creatures/creature_3d_profiles_v10.json'))
rig=json.load(open(ROOT/'data/creatures/rig_animation_matrix_v11.json'))['profiles']
errors=[]; checks={'lines':0,'primary':0,'armor':0,'nonempty':0,'profiles':0,'rig_profiles':0,'provenance':0,'morphology':0}
for c in creatures:
 cid=c['id']; checks['lines']+=1
 if cid in profiles and profiles[cid].get('signature'): checks['profiles']+=1
 else: errors.append(f'profile:{cid}')
 if cid in rig and len(rig[cid].get('animation_states',[]))>=20: checks['rig_profiles']+=1
 else: errors.append(f'rig:{cid}')
 for s in range(1,7):
  aid=f'{cid}_s{s}'; checks['primary']+=1
  it=items.get(aid); path=ROOT/'assets/generated/creatures'/f'{aid}.glb'
  if not it or not path.exists() or path.stat().st_size<1000: errors.append(f'primary:{aid}')
  else: checks['nonempty']+=1
  if not it or 'provenance' not in it: errors.append(f'provenance:{aid}')
  else: checks['provenance']+=1
  if not it or not it.get('morphology_signature'): errors.append(f'morphology:{aid}')
  else: checks['morphology']+=1
for it in manifest['items']:
 if it['type']=='ARMOR_FORM':
  checks['armor']+=1
  path=ROOT/it['resource_path'].replace('res://','')
  if not path.exists() or path.stat().st_size<1000: errors.append(f"armor:{it['asset_id']}")
report={'version':'11.0','checks':checks,'errors':errors[:200],'error_count':len(errors),'status':'PASS_CANDIDATE_COVERAGE' if not errors else 'FAIL'}
json.dump(report,open(ROOT/'data/qa/3d_asset_production_v11.json','w'),ensure_ascii=False,indent=2)
print(json.dumps(report,indent=2))
raise SystemExit(1 if errors else 0)
