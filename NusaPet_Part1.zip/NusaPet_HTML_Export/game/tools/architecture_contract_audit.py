#!/usr/bin/env python3
import json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
errors=[]
def need(path):
    if not (ROOT/path).is_file(): errors.append(f'missing: {path}')
need(pathlib.Path('scripts/core/UpdateManager.gd'))
need(pathlib.Path('scripts/core/LocalAnalytics.gd'))
need(pathlib.Path('data/system/release_channels.json'))
text=(ROOT/'project.godot').read_text(encoding='utf-8')
for key in ['UpdateManager="*res://scripts/core/UpdateManager.gd"','LocalAnalytics="*res://scripts/core/LocalAnalytics.gd"']:
    if key not in text: errors.append(f'autoload missing: {key}')
try:
    cfg=json.loads((ROOT/'data/system/release_channels.json').read_text(encoding='utf-8'))
    channels=cfg.get('channels',{})
    if not all(k in channels for k in ['development','staging','production']): errors.append('release channels incomplete')
    if channels.get('production',{}).get('allow_experimental',True): errors.append('production experimental features enabled')
    if channels.get('production',{}).get('allow_asset_lab',True): errors.append('production asset lab enabled')
except Exception as e: errors.append(f'release_channels invalid: {e}')
privacy=json.loads((ROOT/'data/privacy/privacy_policy.json').read_text(encoding='utf-8'))
if privacy.get('default_tracking') is not False or privacy.get('telemetry_consent_required') is not True:
    errors.append('privacy defaults are not local-first/consent-gated')
print('ARCHITECTURE CONTRACT PASS' if not errors else '\n'.join(errors))
sys.exit(0 if not errors else 2)
