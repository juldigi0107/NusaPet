#!/usr/bin/env python3
import json, hashlib, pathlib, trimesh, datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
m=json.load(open(ROOT/'data/assets/asset_manifest.json'))
res=[]; errors=[]
for i,a in enumerate(m['items'],1):
 p=a.get('resource_path'); f=ROOT/p.replace('res://','') if p else None
 r={'asset_id':a['asset_id'],'exists':bool(f and f.exists()),'approved':bool(a.get('approved'))}
 if not f or not f.exists(): r['status']='MISSING';errors.append(a['asset_id']);res.append(r);continue
 try:
  sc=trimesh.load(f,file_type='glb',force='scene'); verts=sum(len(g.vertices) for g in sc.geometry.values() if hasattr(g,'vertices')); geoms=len(sc.geometry)
  r.update({'status':'NON_EMPTY','geometry_nodes':geoms,'vertices':verts,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
  if geoms<1 or verts<1: r['status']='EMPTY';errors.append(a['asset_id'])
 except Exception as e: r['status']='INVALID';r['error']=str(e);errors.append(a['asset_id'])
 res.append(r)
out={'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_records':len(m['items']),'validated':len(res),'errors':len(errors),'missing_or_invalid':errors[:100],'all_non_empty':not errors,'approved':sum(x['approved'] for x in res),'status':'CANDIDATE_REVIEW'}
json.dump(out,open(ROOT/'data/qa/all_3d_assets_geometry.json','w'),ensure_ascii=False,indent=2)
print(json.dumps(out,indent=2))
