#!/usr/bin/env python3
"""Generate differentiated, data-driven 3D candidate assets.
Uses taxonomy/order/name to select a morphology family. These are authored game-art candidates,
not claims of production anatomical reconstruction; approval remains a separate gate.
"""
import json, math, hashlib
from pathlib import Path
import numpy as np, trimesh
from trimesh.transformations import rotation_matrix
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'assets/generated/creatures'; OUT.mkdir(parents=True,exist_ok=True)
STAGE=[.28,.44,.62,.80,1.0,1.08]

def mat(c,rough=.72,metal=.0): return trimesh.visual.material.PBRMaterial(baseColorFactor=tuple(int(max(0,min(1,x))*255) for x in c)+(255,),roughnessFactor=rough,metallicFactor=metal)
def ell(sc,n,p,s,m,seg=12,rings=8):
 x=trimesh.creation.uv_sphere(radius=1,count=[max(seg,8),max(rings,6)]);x.apply_scale(s);x.apply_translation(p);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def cyl(sc,n,a,b,r,m,sec=10):
 a=np.array(a,float);b=np.array(b,float);v=b-a;L=np.linalg.norm(v)
 if L<1e-5:return
 x=trimesh.creation.cylinder(radius=r,height=L,sections=sec);z=np.array([0,0,1.]);u=v/L;d=np.clip(np.dot(z,u),-1,1)
 if d<.999999:
  ra=np.cross(z,u);ra/=np.linalg.norm(ra);x.apply_transform(rotation_matrix(math.acos(d),ra))
 x.apply_translation((a+b)/2);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def cone(sc,n,p,r,h,m,d=(0,0,1)):
 x=trimesh.creation.cone(radius=r,height=h,sections=10);u=np.array(d,float);u/=np.linalg.norm(u);z=np.array([0,0,1.]);dot=np.clip(np.dot(z,u),-1,1)
 if dot<.999999:
  ra=np.cross(z,u);ra/=np.linalg.norm(ra);x.apply_transform(rotation_matrix(math.acos(dot),ra))
 x.apply_translation(p);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def box(sc,n,p,s,m):
 x=trimesh.creation.box(extents=s);x.apply_translation(p);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def family(c):
 t=c.get('factual_data',{}).get('taxonomy',{}); cls=(t.get('class') or '').lower(); order=(t.get('order') or '').lower(); name=(c.get('name_id') or '').lower(); arch=c.get('archetype','')
 if arch=='ETHEREAL':
  if any(k in name for k in ['garuda','burung','elang','rajawali','phoenix']): return 'bird'
  if any(k in name for k in ['naga','ular','dragon']): return 'serpent'
  if any(k in name for k in ['kuda','horse']) : return 'horse'
  if any(k in name for k in ['ikan','fish','hiu','shark','pari','ray']): return 'fish'
  if any(k in name for k in ['raksasa','buto','buta','rangda','nyai','jenglot','warak','kala','banaspati','orang']): return 'humanoid'
  return 'mythic'
 if 'aves' in cls: return 'bird'
 if 'actinopterygii' in cls or 'chondrichthyes' in cls: return 'fish'
 if 'amphibia' in cls: return 'amphibian'
 if 'insecta' in cls or 'arachnida' in cls or 'myriapoda' in cls: return 'arthropod'
 if 'mollusca' in cls: return 'cephalopod'
 if 'mammalia' in cls:
  if order in ('cetacea','sirenia'): return 'aquatic_mammal'
  if order in ('chiroptera',): return 'bat'
  if order in ('primates',): return 'primate'
  if order in ('perissodactyla','artiodactyla','proboscidea','rodentia','carnivora','pholidota'): return 'quadruped'
 if 'reptilia' in cls:
  if order in ('testudines',): return 'turtle'
  if order in ('squamata','crocodylia'): return 'reptile'
 return 'quadruped'

def build(c,stage):
 h=int(hashlib.sha256(c['id'].encode()).hexdigest()[:8],16); f=family(c); s=STAGE[stage-1]
 r=lambda a,b:a+(h%10000)/10000*(b-a)
 # stable per-species proportions; stage changes size/ornament, not identity
 L=r(.82,1.18); W=r(.55,.86); H=r(.58,.95); head=r(.25,.42); basecol=((h&255)/255*.34+.25,((h>>8)&255)/255*.30+.25,((h>>16)&255)/255*.28+.22)
 body=mat(basecol); accent=mat(tuple(min(1,x*1.55+.06) for x in basecol)); dark=mat(tuple(x*.42 for x in basecol)); eye=mat((.92,.90,.76),.3)
 sc=trimesh.Scene()
 if stage==1:
  ell(sc,'EmbryoCore',(0,0,.28*s),(L*.45*s,W*.38*s,.40*s),body)
  ell(sc,'EmbryoIdentity',(L*.22*s,0,.47*s),(head*.52*s,head*.42*s,.25*s),accent)
  sc.metadata.update({'asset_id':f"{c['id']}_s{stage}",'creature_id':c['id'],'stage':stage,'morphology_family':f,'scientific_name':c.get('scientific_name'),'generator':'NusaPet differentiated morphology generator v3','approval':'UNAPPROVED_CANDIDATE','fallback':'NONE_ASSET_PRESENT_PENDING_ART_QA'}); return sc
 z=H*s+.35; bodyL=L*s; bodyW=W*s; bodyH=H*s
 # family-specific core silhouette
 if f in ('fish','aquatic_mammal'):
  ell(sc,'Torso',(0,0,z),(bodyL*1.12,bodyW*.68,bodyH*.58),body)
  if f=='fish':
   ell(sc,'Head',(bodyL*.78,0,z+.04),(head*1.0,bodyW*.48,bodyH*.52),body)
   cone(sc,'Snout',(bodyL*1.38,0,z+.02),.16*s,.34*s,accent,(1,0,0))
   for side in (-1,1):
    box(sc,f'PectoralFin_{side}',(.25*s,side*bodyW*.65,z),(.45*s,.06*s,.30*s),accent)
   cone(sc,'DorsalFin',(-.05*s,0,z+bodyH*.72),.14*s,.42*s,accent,(0,0,1))
   cone(sc,'CaudalFin',(-bodyL*1.0,0,z),.28*s,.55*s,accent,(-1,0,.1))
  else:
   ell(sc,'Head',(bodyL*.72,0,z+.18*s),(head*1.1,bodyW*.60,bodyH*.65),body)
   for side in (-1,1): ell(sc,f'Flipper_{side}',(.15*s,side*bodyW*.80,z-.08*s),(.45*s,.10*s,.20*s),accent)
   cone(sc,'TailFluke',(-bodyL*1.1,0,z),.22*s,.55*s,accent,(-1,0,0))
 elif f=='bird':
  ell(sc,'Torso',(0,0,z),(bodyL*.85,bodyW*.62,bodyH*.70),body); ell(sc,'Head',(bodyL*.72,0,z+.30*s),(head*.70,head*.65,head*.78),body)
  cone(sc,'Beak',(bodyL*1.28,0,z+.28*s),.12*s,.42*s,accent,(1,0,.15))
  for side in (-1,1):
   ell(sc,f'Wing_{side}',(-.05*s,side*bodyW*.78,z+.15*s),(bodyL*.72,bodyW*.24,bodyH*.40),accent)
   cyl(sc,f'Leg_{side}',(.22*s,side*.18*s,z-bodyH*.55),(.20*s,side*.20*s,.18),.055*s,dark)
   ell(sc,f'Foot_{side}',(.30*s,side*.22*s,.13),(.18*s,.08*s,.045*s),dark)
  for i in range(3): cone(sc,f'TailFeather_{i}',(-bodyL*.80,(i-1)*.18*s,z+.10*s),.07*s,.52*s,accent,(-1,(i-1)*.18,.12))
 elif f in ('arthropod','cephalopod'):
  if f=='arthropod':
   for i in range(3): ell(sc,f'Segment_{i}',(-bodyL*.35+i*bodyL*.34,0,z),(bodyL*.35,bodyW*(.72-.07*i),bodyH*(.52-.04*i)),body)
   for i in range(6):
    side=-1 if i%2==0 else 1; x=-bodyL*.42+(i//2)*bodyL*.42
    cyl(sc,f'Leg_{i}',(x,side*bodyW*.45,z),(x-.10*s,side*bodyW*1.15,z-.30*s),.045*s,dark)
   ell(sc,'Head',(bodyL*.82,0,z+.05*s),(head*.75,bodyW*.65,bodyH*.58),body)
   for side in (-1,1): cyl(sc,f'Antenna_{side}',(bodyL*1.0,side*.18*s,z+.28*s),(bodyL*1.22,side*.38*s,z+.55*s),.018*s,accent)
  else:
   ell(sc,'Mantle',(0,0,z),(bodyL*.78,bodyW*.82,bodyH*.55),body)
   ell(sc,'Head',(bodyL*.55,0,z+.10*s),(head*.78,head*.78,head*.72),body)
   for i in range(8):
    a=2*math.pi*i/8; p=(math.cos(a)*bodyL*.62,math.sin(a)*bodyW*.75,z-.22*s); cyl(sc,f'Tentacle_{i}',(.18*bodyL*math.cos(a),.18*bodyW*math.sin(a),z-.10*s),p,.045*s,accent)
 elif f=='turtle':
  ell(sc,'Shell',(0,0,z),(bodyL,bodyW,bodyH*.65),accent,16,10); ell(sc,'Belly',(bodyL*.10,0,z-.35*s),(bodyL*.82,bodyW*.82,bodyH*.25),dark)
  ell(sc,'Head',(bodyL*.92,0,z+.02*s),(head*.85,head*.70,head*.65),body)
  for side in (-1,1):
   for i in range(2): ell(sc,f'Flipper_{side}_{i}',((.55-i*.35)*s,side*bodyW*.80,z-.12*s),(.32*s,.12*s,.10*s),accent)
  cone(sc,'Tail',(-bodyL*.95,0,z-.05*s),.10*s,.28*s,dark,(-1,0,0))
 elif f=='bat':
  ell(sc,'Torso',(0,0,z),(bodyL*.72,bodyW*.52,bodyH*.72),body); ell(sc,'Head',(bodyL*.55,0,z+.32*s),(head*.65,head*.60,head*.70),body)
  for side in (-1,1):
   box(sc,f'Wing_{side}',(-.05*s,side*bodyW*.95,z+.28*s),(bodyL*.95,.06*s,bodyH*.58),accent); cone(sc,f'Ear_{side}',(bodyL*.55,side*head*.45,z+.78*s),.07*s,.22*s,accent,(0,side,1))
 elif f=='amphibian':
  ell(sc,'Torso',(0,0,z),(bodyL*.80,bodyW*.72,bodyH*.62),body); ell(sc,'Head',(bodyL*.70,0,z+.20*s),(head*1.05,head*.88,head*.78),body)
  for side in (-1,1):
   for i,x in enumerate((.42,-.38)):
    cyl(sc,f'Leg_{side}_{i}',(x*s,side*bodyW*.48,z),(x*.90*s,side*bodyW*.82,.18),.07*s,accent)
  for side in (-1,1): ell(sc,f'Eye_{side}',(bodyL*.86,side*head*.62,z+.48*s),(.07*s,.07*s,.09*s),eye)
 elif f=='serpent':
  pts=[(-bodyL*.75,0,z),(-bodyL*.20,.10*s,z+.05*s),(bodyL*.35,-.08*s,z-.04*s),(bodyL*.85,0,z+.08*s)]
  for i in range(3): cyl(sc,f'Body_{i}',pts[i],pts[i+1],max(.08*s,(.24-.04*i)*s),body)
  ell(sc,'Head',(bodyL*.98,0,z+.10*s),(head,head*.72,head*.70),body)
  cone(sc,'Jaw',(bodyL*1.35,0,z+.03*s),.10*s,.28*s,accent,(1,0,0))
 elif f=='horse':
  ell(sc,'Torso',(0,0,z),(bodyL,bodyW*.72,bodyH*.75),body); ell(sc,'Head',(bodyL*.92,0,z+.45*s),(head*.72,head*.55,head*1.0),body)
  for side in (-1,1):
   for x in (-.55,.55): cyl(sc,f'Leg_{side}_{x}',(x*bodyL*.65,side*bodyW*.55,z-.45*s),(x*bodyL*.70,side*bodyW*.50,.16),.075*s,accent)
  ell(sc,'Mane',(bodyL*.45,0,z+.88*s),(.22*s,.10*s,.52*s),dark)
 elif f=='humanoid':
  ell(sc,'Torso',(0,0,z),(bodyL*.65,bodyW*.70,bodyH*.95),body); ell(sc,'Head',(0,0,z+bodyH*.98),(head*.78,head*.72,head*.88),body)
  for side in (-1,1):
   cyl(sc,f'Arm_{side}',(0,side*bodyW*.55,z+.45*s),(0,side*bodyW*1.02,z-.05*s),.08*s,accent); cyl(sc,f'Leg_{side}',(-.18*s,side*.22*s,z-.65*s),(-.22*s,side*.24*s,.18),.09*s,body)
  if any(k in c.get('name_id','').lower() for k in ['banaspati','buta','buto','kala']): cone(sc,'Crown',(0,0,z+bodyH*1.82),.16*s,.40*s,accent)
 else:
  ell(sc,'Torso',(0,0,z),(bodyL,bodyW,bodyH*.75),body); ell(sc,'Head',(bodyL*.86,0,z+.20*s),(head*.90,head*.72,head*.80),body)
  for side in (-1,1):
   for i,x in enumerate((.55,-.55)):
    hip=(x*bodyL*.70,side*bodyW*.58,z-bodyH*.35); foot=(x*bodyL*.74,side*bodyW*.55,.17); cyl(sc,f'Leg_{side}_{i}_upper',hip,((hip[0]+foot[0])/2,(hip[1]+foot[1])/2,(hip[2]+foot[2])/2),.085*s,accent); cyl(sc,f'Leg_{side}_{i}_lower',((hip[0]+foot[0])/2,(hip[1]+foot[1])/2,(hip[2]+foot[2])/2),foot,.06*s,body)
  cyl(sc,'TailBase',(-bodyL*.72,0,z),(-bodyL*1.25,0,z-.20*s),.10*s,accent)
 # common identity anchors
 for side in (-1,1): ell(sc,f'Eye_{side}',(bodyL*.98,side*head*.60,z+.38*s),(.055*s,.055*s,.065*s),eye,10,6)
 if stage>=4:
  for i in range(4):
   a=2*math.pi*i/4; ell(sc,f'StageMark_{i}',(math.cos(a)*bodyL*.45,math.sin(a)*bodyW*.55,z+bodyH*.55),(.045*s,.045*s,.16*s),accent,8,6)
 if stage>=6:
  for i in range(6):
   a=2*math.pi*i/6; ell(sc,f'Resonance_{i}',(0,math.cos(a)*bodyW*1.12,z+.12*math.sin(a)),(.035*s,.035*s,.12*s),accent,8,6)
 sc.metadata.update({'asset_id':f"{c['id']}_s{stage}",'creature_id':c['id'],'stage':stage,'morphology_family':f,'scientific_name':c.get('scientific_name'),'generator':'NusaPet differentiated morphology generator v3','approval':'UNAPPROVED_CANDIDATE','fallback':'NONE_ASSET_PRESENT_PENDING_ART_QA'})
 return sc

def main():
 creatures=json.load(open(ROOT/'data/creatures/creatures.json')); manifest=json.load(open(ROOT/'data/assets/asset_manifest.json')); by={x['asset_id']:x for x in manifest['items']}; created=0; skipped=0
 for idx,c in enumerate(creatures,1):
  for stage in range(1,7):
   aid=f"{c['id']}_s{stage}"; path=OUT/f'{aid}.glb'; build(c,stage).export(path,file_type='glb'); created+=1
   by[aid]['resource_path']=f'res://assets/generated/creatures/{aid}.glb'; by[aid]['approved']=False; by[aid]['fallback']='NONE_ASSET_PRESENT_PENDING_ART_QA'; by[aid]['morphology_family']=family(c); by[aid]['source_identity']=c.get('scientific_name') or c.get('name_id')
  if idx%50==0: print('batch',idx//50,'creatures',idx,'assets',idx*6)
 manifest['asset_generation_batches']=manifest.get('asset_generation_batches',[]);manifest['asset_generation_batches'].append({'batch':'PRIMARY_MORPHOLOGY_V3_ALL','scope':'350 creature lines x 6 stages','created':created,'status':'CANDIDATE_REVIEW','approval_required':True,'contains_empty_assets':False,'batch_size':50})
 json.dump(manifest,open(ROOT/'data/assets/asset_manifest.json','w'),ensure_ascii=False,indent=2)
 json.dump({'created':created,'total_present':created,'status':'CANDIDATE_REVIEW','generator':'v3','batches':7},open(ROOT/'data/qa/primary_asset_generation_v3.json','w'),ensure_ascii=False,indent=2)
 print('created',created)
if __name__=='__main__': main()
