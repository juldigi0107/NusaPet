#!/usr/bin/env python3
"""Deep structural QA for 3D batches. Checks non-empty geometry, metadata identity,
morphology-specific node signatures and byte-level diversity. Does not approve art."""
import json,hashlib,datetime
from pathlib import Path
import trimesh
ROOT=Path(__file__).resolve().parents[1]
manifest=json.load(open(ROOT/'data/assets/asset_manifest.json'))
creatures={x['id']:x for x in json.load(open(ROOT/'data/creatures/creatures.json'))}
items={x['asset_id']:x for x in manifest['items']}
reports=[]; hard=[]

def load(a):
 p=ROOT/a['resource_path'].replace('res://','')
 if not p.exists(): return p,None,'MISSING'
 try:return p,trimesh.load(p,file_type='glb',force='scene'),None
 except Exception as e:return p,None,str(e)
def sig(sc): return set(sc.geometry.keys())
for bi in range(7):
 start=bi*50
 chunk=list(creatures.values())[start:start+50]
 assets=[]; hashes=set(); families={}; errors=[]
 for c in chunk:
  cid=c['id']; fam=items.get(f'{cid}_s3',{}).get('morphology_family','unknown'); families[fam]=families.get(fam,0)+1
  for st in range(1,7):
   aid=f'{cid}_s{st}'; a=items.get(aid)
   if not a: errors.append([aid,'MANIFEST']); continue
   p,sc,e=load(a)
   if e: errors.append([aid,e]); continue
   v=sum(len(g.vertices) for g in sc.geometry.values() if hasattr(g,'vertices')); g=len(sc.geometry); hashes.add(hashlib.sha256(p.read_bytes()).hexdigest())
   meta=getattr(sc,'metadata',{}) or {}
   if v<20 or g<2: errors.append([aid,'LOW_GEOMETRY',g,v])
   if meta.get('creature_id')!=cid: errors.append([aid,'IDENTITY_METADATA'])
   if meta.get('morphology_family')!=fam: errors.append([aid,'FAMILY_METADATA'])
   assets.append({'asset_id':aid,'geometry_nodes':g,'vertices':v,'family':fam})
 reports.append({'batch':f'{start+1:03d}-{start+len(chunk):03d}','creature_lines':len(chunk),'assets':len(assets),'unique_binary_assets':len(hashes),'families':families,'errors':errors,'status':'PASS' if not errors and len(hashes)==len(assets) else 'BLOCKED'})
# armor batches
armor=json.load(open(ROOT/'data/armor-forms/armor_forms.json'))
for bi in range(7):
 chunk=armor[bi*100:(bi+1)*100]; errors=[]; hashes=set(); fams={}
 for a in chunk:
  p,sc,e=load(items[a['id']])
  if e: errors.append([a['id'],e]); continue
  hashes.add(hashlib.sha256(p.read_bytes()).hexdigest()); g=len(sc.geometry); v=sum(len(x.vertices) for x in sc.geometry.values() if hasattr(x,'vertices'))
  fam=items[a['id']].get('morphology_family','unknown'); fams[fam]=fams.get(fam,0)+1
  if g<3 or v<20: errors.append([a['id'],'LOW_GEOMETRY',g,v])
 reports.append({'batch':f'ARMOR-{bi+1:02d}','assets':len(chunk),'unique_binary_assets':len(hashes),'families':fams,'errors':errors,'status':'PASS' if not errors and len(hashes)==len(chunk) else 'BLOCKED'})
out={'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reports':reports,'all_structural_batches_pass':all(r['status']=='PASS' for r in reports),'approval_status':'UNAPPROVED_ART_CANDIDATE'}
json.dump(out,open(ROOT/'data/qa/3d_asset_batches_deep.json','w'),ensure_ascii=False,indent=2)
print(json.dumps({'batches':len(reports),'all_structural_batches_pass':out['all_structural_batches_pass'],'blocked_batches':[r['batch'] for r in reports if r['status']!='PASS']},indent=2))
