from pathlib import Path
import json, hashlib, numpy as np, trimesh, collections, datetime
root=Path('/mnt/data/NusaPet_AUDIT_WORK/NusaPet_Godot')
manifest_path=root/'data/assets/asset_manifest.json'; manifest=json.loads(manifest_path.read_text())
results=[]; errors=[]; structural=0
for idx,item in enumerate(manifest['items'],1):
    path=root/item['resource_path'].replace('res://','')
    try:
        sc=trimesh.load(path,force='scene')
        meshes=[g for g in sc.geometry.values() if hasattr(g,'vertices') and hasattr(g,'faces')]
        verts=sum(len(g.vertices) for g in meshes); faces=sum(len(g.faces) for g in meshes)
        ext=np.array(sc.bounds[1])-np.array(sc.bounds[0]) if meshes else np.zeros(3)
        ok=bool(meshes and verts>0 and faces>0 and np.all(np.isfinite(ext)) and np.all(ext>1e-5))
        if ok: structural+=1
        else: errors.append(item['asset_id'])
        results.append({'asset_id':item['asset_id'],'vertices':int(verts),'faces':int(faces),'extent':[float(x) for x in ext],'structural_valid':ok})
    except Exception as e:
        errors.append(item['asset_id']); results.append({'asset_id':item['asset_id'],'structural_valid':False,'error':str(e)})
    if idx%500==0: print(idx)
by={r['asset_id']:r for r in results}
for item in manifest['items']:
    r=by[item['asset_id']]
    item['approved']=False
    item['qa_gates']={
      'file_exists':'PASS' if item['resource_path'] else 'FAIL',
      'geometry':'PASS' if r.get('structural_valid') else 'FAIL',
      'species_specific_art_review':'REVIEW_REQUIRED',
      'anatomy':'HUMAN_REVIEW_REQUIRED',
      'animation':'RUNTIME_PIPELINE_REVIEW_REQUIRED',
      'armor_clipping':'HUMAN_REVIEW_REQUIRED' if item['type']=='ARMOR_FORM' else 'N/A',
      'cultural_design':'HUMAN_REVIEW_REQUIRED' if 'mystical' in item['asset_id'] or 'folklore' in item['asset_id'] else 'N/A'
    }
    item['structural_validation']=r
manifest['last_structural_audit']={'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'validated':structural,'failed':len(errors),'human_approval_required':len(manifest['items'])}
manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
out=root/'data/qa/geometry_audit.json'; out.write_text(json.dumps({'validated':structural,'failed':len(errors),'errors':errors,'records':results},ensure_ascii=False,indent=2))
print(json.dumps({'validated':structural,'failed':len(errors),'human_approval_required':len(manifest['items'])},indent=2))
