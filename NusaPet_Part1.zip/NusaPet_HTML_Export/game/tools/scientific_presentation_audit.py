#!/usr/bin/env python3
import json, re, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
creatures=json.loads((ROOT/"data/creatures/creatures.json").read_text())
errors=[]
for c in creatures:
    if c.get("category")=="REAL":
        n=str(c.get("scientific_name","")); parts=n.split()
        if len(parts)<2 or not parts[0][:1].isupper() or any(not part[:1].islower() for part in parts[1:]):
            errors.append(f"invalid scientific name style: {c.get('id')}: {n}")
        rr=c.get("research_record",{})
        if rr.get("status")=="PUBLISHED" and rr.get("source_confidence") not in ["HIGH","MEDIUM"]:
            errors.append(f"published REAL entry lacks sufficient source confidence: {c.get('id')}")
        if rr.get("status")!="PUBLISHED" and (rr.get("conservation_status") or rr.get("distribution_regions") or rr.get("habitats")):
            # Structured placeholders are allowed only when explicitly marked review-gated.
            if rr.get("source_confidence")!="REVIEW": errors.append(f"unverified factual field exposed: {c.get('id')}")
print(json.dumps({"real_entries":sum(1 for c in creatures if c.get("category")=="REAL"),"errors":errors,"pass":not errors},indent=2))
sys.exit(0 if not errors else 2)
