#!/usr/bin/env python3
import json,os,hashlib,re,sys
ROOT=os.path.dirname(os.path.dirname(__file__))
def load(r): return json.load(open(os.path.join(ROOT,r),encoding='utf8'))
creatures=load('data/creatures/creatures.json'); forms=load('data/evolutions/primary_forms.json'); cross=load('data/cross-evolutions/cross_paths.json'); armor=load('data/armor-forms/armor_forms.json'); pusaka=load('data/artifacts/pusaka.json')
errs=[]; warns=[]
ids=[x['id'] for x in creatures]
if len(creatures)!=350: errs.append('creature count != 350')
if len(set(ids))!=len(ids): errs.append('duplicate creature id')
real=[x for x in creatures if x.get('category')=='REAL']; myth=[x for x in creatures if x.get('category')=='MYTHOLOGY']; myst=[x for x in creatures if x.get('category')=='MYSTICAL']
if len(real)!=250: errs.append('REAL != 250')
if len(myth)!=50: errs.append('MYTHOLOGY != 50')
if len(myst)!=50: errs.append('MYSTICAL != 50')
scientific=[x.get('scientific_name') for x in real]
if any(not x for x in scientific): errs.append('REAL missing scientific name')
if len(set(scientific))!=len(scientific): errs.append('duplicate REAL scientific name')
for c in real:
 t=c.get('factual_data',{}).get('taxonomy',{})
 for k in ['kingdom','phylum','class','order','family','genus','species','rank']:
  if not t.get(k): errs.append(f'{c["id"]}: missing taxonomy {k}')
 if t.get('species')!=c.get('scientific_name'): warns.append(f'{c["id"]}: taxonomy species differs from record')
 cr=c.get('research_record',{})
 if cr.get('status')!='PUBLISHED': warns.append(f'{c["id"]}: factual research not PUBLISHED')
for c in myth+myst:
 cr=c.get('cultural_review',{})
 if cr.get('status')!='PUBLISHED': warns.append(f'{c["id"]}: cultural review not PUBLISHED')
if len(forms)!=2100: errs.append('primary forms != 2100')
formids={f['id'] for f in forms}
if len(formids)!=len(forms): errs.append('duplicate form id')
for cid in ids:
 fs=[f for f in forms if f.get('creature_line')==cid]
 if len(fs)!=6: errs.append(f'{cid}: primary stage count {len(fs)}')
for e in cross:
 if e.get('source') not in formids or e.get('target') not in formids: errs.append(f'{e.get("id")}: orphan cross edge')
 if e.get('source')==e.get('target'): errs.append(f'{e.get("id")}: self-loop')
 if not e.get('requirements'): errs.append(f'{e.get("id")}: missing requirements')
if len(armor)<700: errs.append('armor < 700')
for a in armor:
 if a.get('base_creature') not in ids: errs.append(f'{a.get("id")}: orphan armor')
 if not a.get('temporary',False): errs.append(f'{a.get("id")}: armor not temporary')
if len(pusaka)!=15: errs.append('pusaka != 15')
print(f'CREATURES {len(creatures)} REAL {len(real)} MYTH {len(myth)} MYST {len(myst)} FORMS {len(forms)} ARMOR {len(armor)} CROSS {len(cross)} PUSAKA {len(pusaka)}')
print(f'ERRORS {len(errs)} WARNINGS {len(warns)}')
for x in errs[:100]: print('ERROR:',x)
for x in warns[:20]: print('WARN:',x)
json.dump({'errors':errs,'warnings':warns,'counts':{'creatures':len(creatures),'real':len(real),'mythology':len(myth),'mystical':len(myst),'primary_forms':len(forms),'armor_forms':len(armor),'cross_paths':len(cross),'pusaka':len(pusaka)}},open(os.path.join(ROOT,'data/content_audit.json'),'w',encoding='utf8'),ensure_ascii=False,indent=2)
sys.exit(1 if errs else 0)
