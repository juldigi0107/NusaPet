"""Online taxonomy gate for NusaPet.
Run from a network-enabled CI/research environment.
Primary matcher: GBIF Species API v2, with Catalogue of Life / WoRMS cross-checks.
This tool is intentionally NOT part of offline gameplay.
"""
import json, pathlib, urllib.parse, urllib.request, sys, time
ROOT=pathlib.Path(__file__).parents[1]
DATA=ROOT/'data/creatures/creatures.json'
OUT=ROOT/'data/taxonomy/external_taxonomy_validation.json'
creatures=[x for x in json.loads(DATA.read_text(encoding='utf-8')) if x.get('category')=='REAL']
results=[]
for i,c in enumerate(creatures,1):
    sci=c['scientific_name']
    url='https://api.gbif.org/v2/species/match?'+urllib.parse.urlencode({'scientificName':sci})
    try:
        with urllib.request.urlopen(url,timeout=20) as r: obj=json.load(r)
        usage=obj.get('usage') or {}
        results.append({'id':c['id'],'input':sci,'match_type':obj.get('matchType'),'confidence':obj.get('confidence'),'status':usage.get('status'),'canonicalName':usage.get('canonicalName'),'rank':usage.get('rank'),'taxonKey':usage.get('key'),'family':usage.get('family'),'genus':usage.get('genus'),'order':usage.get('order'),'class':usage.get('class'),'phylum':usage.get('phylum'),'kingdom':usage.get('kingdom'),'ok':bool(usage) and usage.get('rank') in ('SPECIES','SUBSPECIES') and usage.get('kingdom')=='Animalia'})
    except Exception as e:
        results.append({'id':c['id'],'input':sci,'ok':False,'error':str(e)})
    if i%25==0: time.sleep(.2)
OUT.parent.mkdir(parents=True,exist_ok=True)
OUT.write_text(json.dumps({'generated_by':'tools/validate_taxonomy.py','source':'GBIF Species API v2','count':len(results),'passed':sum(1 for x in results if x.get('ok')),'failed':sum(1 for x in results if not x.get('ok')),'results':results},ensure_ascii=False,indent=2),encoding='utf-8')
failed=[x for x in results if not x.get('ok')]
print(f'Validated {len(results)} REAL lines; passed={len(results)-len(failed)} failed={len(failed)}')
for x in failed: print('FAIL',x)
sys.exit(1 if failed else 0)
