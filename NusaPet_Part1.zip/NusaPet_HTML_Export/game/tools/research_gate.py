#!/usr/bin/env python3
import json,sys
ROOT='.'
creatures=json.load(open(ROOT+'/data/creatures/creatures.json'))
errors=[]; blocked=[]; published=[]
for c in creatures:
    if c.get('category')!='REAL': continue
    rr=c.get('research_record',{}); fd=c.get('factual_data',{})
    required=['accepted_name','taxon_key','distribution_regions','habitats','conservation_status','references']
    missing=[k for k in required if rr.get(k) in (None,[], '')]
    if rr.get('status')!='PUBLISHED' or missing:
        blocked.append({'id':c['id'],'scientific_name':c.get('scientific_name'),'missing':missing,'status':rr.get('status'),'confidence':rr.get('source_confidence')})
    else: published.append(c['id'])
report={'total_real':len([c for c in creatures if c.get('category')=='REAL']),'published':len(published),'blocked':blocked,'pass':len(blocked)==0}
json.dump(report,open(ROOT+'/data/qa/research_gate.json','w'),indent=2,ensure_ascii=False)
print(f"REAL research gate: {len(published)}/{report['total_real']} published")
if blocked: print(f"BLOCKED: {len(blocked)} entries require verified source data")
sys.exit(0 if report['pass'] else 2)
