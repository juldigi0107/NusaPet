#!/usr/bin/env python3
import json,sys,os
ROOT='.'
creatures=json.load(open(ROOT+'/data/creatures/creatures.json'))
art=json.load(open(ROOT+'/data/artifacts/pusaka.json'))
armor=json.load(open(ROOT+'/data/armor-forms/armor_forms.json'))
ids={c['id'] for c in creatures}; aids={a['id'] for a in art}; armor_ids=set(); errors=[]; warnings=[]
valid_aff={a.get('affinity') for a in art}
for a in art:
    if not a.get('id'): errors.append('artifact missing id')
    if a.get('affinity') not in valid_aff: errors.append(f"{a.get('id')}: invalid affinity")
for x in armor:
    aid=x.get('id',''); armor_ids.add(aid)
    if not x.get('base_creature') in ids: errors.append(f'{aid}: missing base creature')
    if x.get('artifact_affinity') not in valid_aff: errors.append(f'{aid}: invalid affinity {x.get("artifact_affinity")}')
    if int(x.get('minimum_stage',0))<1 or int(x.get('minimum_stage',0))>6: errors.append(f'{aid}: invalid minimum stage')
    ref=x.get('asset_ref') or x.get('asset_manifest',{}).get('path')
    if not ref: warnings.append(f'{aid}: no asset reference')
    elif isinstance(ref,str) and ref.startswith('res://') and not os.path.exists(os.path.join(ROOT,ref[6:])): errors.append(f'{aid}: missing asset {ref}')
for c in creatures:
    matches=[x for x in armor if x.get('base_creature')==c['id']]
    if len(matches)<2: errors.append(f"{c['id']}: only {len(matches)} armor forms; minimum 2")
report={'errors':errors,'warnings':warnings,'counts':{'creatures':len(creatures),'artifacts':len(art),'armor_forms':len(armor)},'pass':not errors}
json.dump(report,open(ROOT+'/data/qa/pusaka_audit.json','w'),indent=2,ensure_ascii=False)
print(json.dumps(report,indent=2,ensure_ascii=False)); sys.exit(0 if not errors else 1)
