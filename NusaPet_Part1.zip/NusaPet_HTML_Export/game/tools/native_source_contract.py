#!/usr/bin/env python3
"""Offline source contract for native 3D wiring added after the V23 audit."""
from pathlib import Path
import re,sys
ROOT=Path(__file__).resolve().parents[1]
checks=[]
def req(ok,msg): checks.append((ok,msg))
project=(ROOT/'project.godot').read_text()
main=(ROOT/'scripts/main.gd').read_text()
world=(ROOT/'scripts/world/WorldBuilder.gd').read_text()
gs=(ROOT/'scripts/core/GameState.gd').read_text()
req('RecoveryManager="*res://scripts/core/RecoveryManager.gd"' in project,'RecoveryManager autoload')
req((ROOT/'scripts/core/RecoveryManager.gd').exists(),'RecoveryManager source')
req((ROOT/'scripts/evolution_presentation.gd').exists(),'Evolution presentation source')
req('preload("res://scripts/evolution_presentation.gd")' in main,'Evolution presentation wired')
req('preload("res://scripts/world/PusakaWorldController.gd")' in main,'Pusaka controller wired')
req('var interaction_anchors: Dictionary = {}' in world,'WorldBuilder anchor storage declared')
req('Node3D.new()' in world and 'HabitatAnchor_' in world,'Native habitat anchors')
req('RecoveryManager.begin("EVOLUTION")' in gs and 'RecoveryManager.complete()' in gs,'Evolution recovery lifecycle')
req('RecoveryManager.begin("ARMOR")' in gs,'Armor recovery lifecycle')
errors=[m for ok,m in checks if not ok]
print(f'NATIVE SOURCE CONTRACT: {len(checks)-len(errors)}/{len(checks)} PASS')
for e in errors: print('ERROR:',e)
sys.exit(1 if errors else 0)
