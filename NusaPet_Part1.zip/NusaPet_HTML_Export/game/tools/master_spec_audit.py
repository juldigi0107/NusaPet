#!/usr/bin/env python3
import json, os, re, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
def load(rel): return json.loads((ROOT/rel).read_text(encoding='utf8'))
def add(name,ok,detail,blocking=False):
    checks.append({"name":name,"status":"PASS" if ok else ("BLOCKED" if blocking else "WARN"),"detail":detail})
checks=[]
c=load("data/creatures/creatures.json"); f=load("data/evolutions/primary_forms.json"); x=load("data/cross-evolutions/cross_paths.json"); a=load("data/armor-forms/armor_forms.json"); pus=load("data/artifacts/pusaka.json")
add("Creature scale",len(c)==350 and sum(z.get("category")=="REAL" for z in c)==250 and sum(z.get("category")=="MYTHOLOGY" for z in c)==50 and sum(z.get("category")=="MYSTICAL" for z in c)==50,f"{len(c)} lines",True)
add("Primary scale",len(f)==2100,f"{len(f)} forms",True)
add("Cross Branch scale",len(x)==350,f"{len(x)} paths",True)
add("Armor scale",len(a)>=700,f"{len(a)} forms",True)
add("Pusaka affinity scale",len(pus)>=15,f"{len(pus)} artifacts",True)
add("Compatibility matrix",all(isinstance(z.get("pusaka_compatibility"),dict) and len(z["pusaka_compatibility"])>=2 for z in c),"350 creature records contain >=2 game compatibility weights",True)
scenes=list((ROOT/"scenes").rglob("*.tscn")); empty=[]
for q in scenes:
    t=q.read_text(errors="replace")
    if t.count("[node ")<=1 and "script =" not in t: empty.append(str(q.relative_to(ROOT)))
add("Declared modular scenes",len(empty)==0,f"{len(scenes)} scenes; empty={len(empty)}",True)
for rel in ["scripts/core/GameState.gd","scripts/main.gd","scripts/world/WorldBuilder.gd","scripts/creature_visual.gd","scripts/habitat.gd","scripts/region_map_3d.gd"]:
    add("Source "+rel,(ROOT/rel).exists(),"present",True)
gs=(ROOT/"scripts/core/GameState.gd").read_text()
for fn in ["hatch","act","evolve","transform","check_resonance","try_dual_resonance","try_perfect_resonance","add_companion_from_current","switch_companion","archive_current_to_legacy","start_team_expedition","merge_cloud_state","export_save","import_save","age_label","evolution_forecast","evolution_journal","evolution_hints","observe_field_clue","save_screenshot_memory"]:
    add("Runtime API "+fn,bool(re.search(r"func\s+"+re.escape(fn)+r"\s*\(",gs)),"implemented",True)
asset=load("data/qa/asset_audit.json") if (ROOT/"data/qa/asset_audit.json").exists() else {}
ac=asset.get("counts",{})
add("3D asset files present",int(ac.get("required_assets_missing",2800))==0,str(ac),True)
add("3D structural geometry",int(ac.get("structurally_invalid",2800))==0,str(ac),True)
add("Final art approval",int(ac.get("required_assets_unapproved",2800))==0,"Human Art Bible/anatomy/clipping/cultural review is still required",True)
add("Scientific publication",all(z.get("research_record",{}).get("status")=="PUBLISHED" for z in c if z.get("category")=="REAL"),"250 REAL entries must be PUBLISHED",True)
add("Cultural publication",all(z.get("cultural_review",{}).get("status")=="PUBLISHED" for z in c if z.get("category") in ["MYTHOLOGY","MYSTICAL"]),"100 cultural entries must be reviewed/published",True)
add("Native runtime",False,"Godot 4.x execution not available in this audit environment",True)
add("Native device E2E",False,"Android/iOS/desktop toolchains and representative devices not available",True)
out={"project":"NusaPet","master":"NusaPet v2+v3 FULL UNABRIDGED","checks":checks,"pass":all(x["status"]=="PASS" for x in checks)}
(ROOT/"data/qa/master_spec_audit.json").write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding="utf8")
for x in checks: print(x["status"],x["name"],"—",x["detail"])
sys.exit(0 if out["pass"] else 2)
