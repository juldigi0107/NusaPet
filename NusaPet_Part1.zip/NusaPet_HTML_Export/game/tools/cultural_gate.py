#!/usr/bin/env python3
import json,sys
cs=json.load(open('data/creatures/creatures.json'))
blocked=[]; published=[]
for c in cs:
    if c.get('category') not in ('MYTHOLOGY','MYSTICAL'): continue
    r=c.get('cultural_review',{})
    req=['region','tradition','variant','sources','framing']
    miss=[k for k in req if r.get(k) in (None,[], '')]
    if r.get('status')!='PUBLISHED' or miss or r.get('source_confidence') not in ('HIGH','MEDIUM'):
        blocked.append({'id':c['id'],'missing':miss,'status':r.get('status'),'confidence':r.get('source_confidence')})
    else: published.append(c['id'])
report={'total':len(published)+len(blocked),'published':len(published),'blocked':blocked,'pass':not blocked}
json.dump(report,open('data/qa/cultural_gate.json','w'),indent=2,ensure_ascii=False)
print(f"Cultural gate: {len(published)}/{report['total']} published")
sys.exit(0 if report['pass'] else 2)
