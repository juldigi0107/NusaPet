#!/usr/bin/env python3
import json, hashlib
from pathlib import Path
import trimesh
ROOT=Path(__file__).resolve().parents[1]
BATCH=json.load(open(ROOT/'data/qa/asset_batch_B01.json'))
results=[]; errors=[]
for a in BATCH['assets']:
    p=ROOT/a['path'].replace('res://','')
    r={'asset_id':a['asset_id'],'path':a['path'],'exists':p.exists(),'size_bytes':p.stat().st_size if p.exists() else 0}
    if not p.exists(): errors.append(a['asset_id']); r['error']='MISSING'; results.append(r); continue
    try:
        sc=trimesh.load(p, file_type='glb', force='scene')
        geoms=len(sc.geometry); verts=sum(len(g.vertices) for g in sc.geometry.values() if hasattr(g,'vertices'))
        names=list(sc.geometry.keys())
        r.update({'geometry_nodes':geoms,'vertices':verts,'non_empty':geoms>0 and verts>0,'node_names':names[:80],'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
        if geoms==0 or verts==0: errors.append(a['asset_id']); r['error']='EMPTY_GEOMETRY'
    except Exception as e:
        errors.append(a['asset_id']); r['error']=str(e)
    results.append(r)
out={'batch':'B01','count':len(results),'valid':len(errors)==0,'errors':errors,'assets':results,'quality_status':'CANDIDATE_REVIEW'}
json.dump(out,open(ROOT/'data/qa/asset_batch_B01_validation.json','w'),ensure_ascii=False,indent=2)
print(json.dumps({'count':len(results),'errors':errors,'valid':len(errors)==0},indent=2))
