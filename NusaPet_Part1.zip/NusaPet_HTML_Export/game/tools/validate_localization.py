#!/usr/bin/env python3
import json,os,re
ROOT=os.path.dirname(os.path.dirname(__file__))
idp=json.load(open(os.path.join(ROOT,'data/localization/id/strings.json'),encoding='utf8')); en=json.load(open(os.path.join(ROOT,'data/localization/en/strings.json'),encoding='utf8'))
errors=[]
for k,v in idp.items():
 if k not in en: errors.append('missing EN '+k)
 if not isinstance(v,str) or not v.strip(): errors.append('empty ID '+k)
for k,v in en.items():
 if k not in idp: errors.append('missing ID '+k)
 if not isinstance(v,str) or not v.strip(): errors.append('empty EN '+k)
# Technical terms should remain stable where present.
for term in ['Pusaka','Resonance','Nusapedia']:
 if term in idp and term not in en: errors.append('technical term lost '+term)
print('Localization keys ID',len(idp),'EN',len(en),'errors',len(errors))
for e in errors: print('ERROR',e)
raise SystemExit(1 if errors else 0)
