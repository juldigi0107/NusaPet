# Licenses
Project source generated for the user. Procedural fallback art contains no third-party franchise assets. External factual/cultural datasets and references must be licensed/attributed when added.
