# Testing

Required by the master prompt: content, unit, integration, E2E, device, performance, crash/recovery, localization and accessibility testing.

This source provides structural/content/unit scripts. Native device/export execution remains blocked until Godot and platform toolchains are available.
