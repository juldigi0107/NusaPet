# NusaPet Creature Art Bible — 3D Production v11

## Core identity
NusaPet uses original premium-stylized 3D. A creature must remain readable from silhouette alone before color, aura, armor, or effects are applied.

## Anatomy
- Scientific species are represented with recognizable proportions and diagnostic features.
- Mythology/folklore and mystical designs are original interpretations and must not imply historical reconstruction without evidence.
- Shared anatomical rigs/templates are allowed for scale, but every species requires species-specific correction.
- No universal humanoid armor conversion.

## Materials
Use restrained PBR materials, clear roughness hierarchy, subtle surface breakup, and affinity-driven energy only as an overlay. Affinity effects never replace the underlying species material identity.

## Face
Eyes, beak, snout, horns, antennae, tentacles, fins, and other diagnostic structures are preserved. Facial animation is used only where anatomically appropriate.

## Animation
Primary forms expose: Idle, Blink, Walk, Run, Eat, Drink, Happy, Sad, Angry, Sleep, Wake, Play, Train, Dirty, Sick, Heal, Interact, Discover, Evolution, Special Idle. Locomotion is selected by anatomical profile rather than forced universally.

## Armor integration
Armor is modular and socket-based. Use HEAD/CHEST/BACK/FORELIMB/HINDLIMB/WING/TAIL/HORN/FIN/ENERGY CORE/ORNAMENT/AURA/PARTICLES only when anatomically appropriate. Armor must preserve species silhouette and avoid clipping/floating geometry.

## Mobile quality
Prefer readable forms, controlled polygon density, LOD, lazy loading, texture tiers, and limited particle density. Do not sacrifice silhouette clarity for micro-detail that cannot survive mobile resolution.

## QA checklist
1. Silhouette readable
2. Anatomy preserved
3. No missing limb/diagnostic feature
4. Correct scale
5. No floating geometry
6. No armor clipping
7. Socket alignment correct
8. Palette/material hierarchy coherent
9. Animation does not clip
10. LOD remains readable
11. Provenance metadata complete
12. Approval only after human/art QA
