# NusaPet Deep Dive v5

This batch tightens the implementation against the master prompt rather than merely increasing feature count.

## Correctness upgrades
- Cross-Branch permanent evolution is now validated as a DAG; accidental cycles fail the graph gate.
- Cross-Branch evolution switches the active evolution line at a valid stage boundary instead of assigning a stage-4 form to a stage-5 pet.
- Active line identity is persisted separately from original creature identity.
- Armor compatibility and Resonance use the active evolution line.
- Save transactions now track pending operations and support structured export/import validation.
- Research and cultural publication remain hard release blockers until evidence exists.
- Asset manifest and art prompt counts are checked independently.
- 1,000 lifecycle simulations now measure branch distribution; no single generated branch may dominate the simulation.

## Important distinction
Procedural silhouettes, prompts and asset manifests are **not** counted as final production 3D assets. The final art gate remains blocked until actual production assets are ingested and reviewed.
