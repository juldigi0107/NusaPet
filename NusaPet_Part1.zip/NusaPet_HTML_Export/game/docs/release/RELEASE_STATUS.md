# NusaPet Release Status

This document is generated/maintained as a release gate, not as a claim of completion.

## Proven offline in repository
- 350 base creature lines
- 250 REAL / 50 MYTHOLOGY-FOLKLORE / 50 MYSTICAL
- 2,100 primary forms
- 700 Armor Forms
- 350 Cross-Branch paths
- 15 Pusaka
- bilingual localization structure
- taxonomy structure for all REAL records
- automated graph, Pusaka, asset, localization, research and cultural gates

## Must remain blocked until evidence exists
- external factual publication for all 250 REAL species
- cultural publication review for all 100 mythology/mystical entries
- final production 3D assets for every required visual state
- Godot headless compile/test in a real Godot 4.x environment
- Android/iOS/Desktop native export
- representative device E2E
- performance/memory profiling on target devices
- crash/recovery and visual-regression evidence

Never convert these blockers to PASS by changing a JSON status manually.
