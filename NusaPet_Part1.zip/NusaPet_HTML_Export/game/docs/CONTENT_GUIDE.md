# Content Guide
REAL factual data must carry validated references. MYTHOLOGY and MYSTICAL entries are framed as cultural/traditional narratives, never scientific fact. Game lore is stored separately from factual/cultural fields.
