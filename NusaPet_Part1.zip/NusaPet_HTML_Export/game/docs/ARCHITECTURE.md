# Architecture

## Layers
1. **Game runtime** — Godot Node/Scene, GDScript, camera, input, animation, world and interaction.
2. **Systems/state** — care, time, evolution, Pusaka/Armor, resonance, exploration, research and save state.
3. **Content** — JSON packs for creatures, taxonomy, forms, artifacts, habitats, regions, quests, achievements and localization.
4. **Presentation** — Godot Control/CanvasLayer-style game HUD/menu. Home remains a living habitat rather than a dashboard.
5. **Adapters** — optional authentication/cloud/storage implementations. Core gameplay remains independent of vendor APIs.
6. **QA/tooling** — offline content audit, localization audit, research validation, art prompt/provenance generation, lifecycle simulation and release readiness reporting.

## Progressive detail
The runtime must not preload all 2,800+ visual states. Production asset delivery should use manifest-addressed PackedScenes/GLB resources, lazy loading, cache, predictive prefetch and quality tiers. Procedural fallback geometry is retained for development/recovery only.

## Evolution state separation
- Primary Evolution = permanent stage/form.
- Cross-Branch = permanent alternate route.
- Armor = temporary Pusaka transformation.
- Resonance/Dual Resonance = rare temporary conditional layer.

These layers are stored independently so temporary transformation cannot corrupt permanent progression.

## Content truth model
REAL factual information and traditional cultural information are publication-gated. Original game lore is stored separately and explicitly labeled. Scientific taxonomy is not a gameplay evolution claim.
