class_name NusaCreatureVisual
extends Node3D
## Runtime procedural fallback renderer. Production assets must replace this through asset_manifest.
## The renderer is intentionally data-driven and never claims a fallback is a final species asset.
var creature_id := ""
var stage := 1
var archetype := "OTHER"
var body_color := Color("d09b4a")
var _base_y := 1.0
var _clock := 0.0
var _root_visual: Node3D

func configure(c: Dictionary, form: Dictionary, p: Dictionary) -> void:
    creature_id = str(c.get("id",""))
    archetype = str(c.get("archetype","OTHER"))
    stage = int(p.get("stage",1))
    body_color = _color_for(c, form)
    _clear()
    # Production candidate assets are preferred whenever the manifest points to a real GLB.
    # Procedural rendering remains an explicit fallback for batches not yet generated/approved.
    if _try_load_asset():
        _make_rare_trait_markers(p, 0.9)
        _make_armor(p)
        _make_resonance(p)
        _make_perfect_resonance(p)
        return
    _root_visual = Node3D.new()
    _root_visual.name = "ProceduralValidatedFallback"
    add_child(_root_visual)
    var scale_factor := 0.72 + stage * 0.08
    _make_body(scale_factor)
    _make_head(scale_factor)
    _make_limbs(scale_factor)
    _make_species_features(scale_factor)
    _make_face(scale_factor)
    _make_stage_aura(scale_factor)
    _make_rare_trait_markers(p, scale_factor)
    _make_armor(p)
    _make_resonance(p)
    _make_perfect_resonance(p)

func _try_load_asset() -> bool:
    var path := "res://assets/generated/creatures/%s_s%d.glb" % [creature_id, stage]
    if not ResourceLoader.exists(path):
        return false
    var packed := load(path) as PackedScene
    if packed == null:
        return false
    _root_visual = Node3D.new()
    _root_visual.name = "ProductionAssetCandidate"
    add_child(_root_visual)
    var instance := packed.instantiate()
    _root_visual.add_child(instance)
    # Normalize candidate scale to the existing world framing while retaining species proportions.
    var bounds_scale := 0.72 + stage * 0.08
    _root_visual.scale = Vector3.ONE * bounds_scale
    return true

func _process(delta: float) -> void:
    _clock += delta
    if _root_visual:
        _root_visual.position.y = sin(_clock*1.8)*0.045
        _root_visual.rotation.y = sin(_clock*0.55)*0.035

func _clear() -> void:
    for c in get_children(): c.queue_free()

func _mat(color: Color, rough:=0.58, metallic:=0.0) -> StandardMaterial3D:
    var m:=StandardMaterial3D.new()
    m.albedo_color=color
    m.roughness=rough
    m.metallic=metallic
    return m

func _mesh(type:String, size:Vector3, pos:Vector3, color:Color) -> MeshInstance3D:
    var n:=MeshInstance3D.new()
    if type=="sphere":
        var sm:=SphereMesh.new(); sm.radius=max(size.x,size.z)*0.5; sm.height=size.y; n.mesh=sm
    elif type=="capsule":
        var cm:=CapsuleMesh.new(); cm.radius=size.x; cm.height=size.y; n.mesh=cm
    elif type=="box":
        var bm:=BoxMesh.new(); bm.size=size; n.mesh=bm
    elif type=="cylinder":
        var cm:=CylinderMesh.new(); cm.top_radius=size.x*.65; cm.bottom_radius=size.x; cm.height=size.y; n.mesh=cm
    elif type=="cone":
        var cm:=CylinderMesh.new(); cm.top_radius=0.02; cm.bottom_radius=size.x; cm.height=size.y; n.mesh=cm
    n.position=pos; n.material_override=_mat(color); _root_visual.add_child(n); return n

func _make_body(s:float)->void:
    var body_type:="capsule"
    if archetype in ["AQUATIC","FISH","MOLLUSK"]: body_type="sphere"
    if archetype in ["ETHEREAL","HUMANOID_FOLKLORE"]: body_type="sphere"
    var body:=_mesh(body_type,Vector3(1.55*s,2.0*s,1.35*s),Vector3(0,0.9*s,0),body_color)
    if archetype in ["SERPENTINE","REPTILE"]:
        body.rotation_degrees.z=90

func _make_head(s:float)->void:
    var head:=_mesh("sphere",Vector3(1.15*s,1.05*s,1.05*s),Vector3(0,1.9*s,0.42*s),body_color.lightened(0.05))
    if archetype=="AVIAN" or archetype=="BIRD" or archetype=="WINGED":
        var beak:=_mesh("cone",Vector3(.32*s,.7*s,.32*s),Vector3(0,1.9*s,1.0*s),body_color.lightened(.25))
        beak.rotation_degrees.x=90

func _make_limbs(s:float)->void:
    if archetype in ["AQUATIC","FISH","MOLLUSK","SERPENTINE"]: return
    var limb_count:=4 if archetype in ["QUADRUPED","REPTILE","HORNED"] else 2
    for i in range(limb_count):
        var x:=(-.52 if i%2==0 else .52)*s
        var z:=(-.42 if i<2 else .34)*s
        _mesh("cylinder",Vector3(.22*s,.9*s,.22*s),Vector3(x,.25*s,z),body_color.darkened(.14))

func _make_species_features(s:float)->void:
    if archetype in ["AVIAN","BIRD","WINGED"]:
        for side in [-1.0,1.0]:
            var w:=_mesh("box",Vector3(1.25*s,.12*s,.72*s),Vector3(side*.72*s,1.0*s,0),body_color.darkened(.12))
            w.rotation_degrees.z=side*18
    elif archetype in ["QUADRUPED","REPTILE","SERPENTINE","HORNED"]:
        var tail:=_mesh("cone",Vector3(.28*s,1.5*s,.28*s),Vector3(0,.72*s,-.95*s),body_color.darkened(.10))
        tail.rotation_degrees.x=-90
    elif archetype in ["AQUATIC","FISH"]:
        for side in [-1.0,1.0]:
            var fin:=_mesh("box",Vector3(.55*s,.08*s,.9*s),Vector3(side*.72*s,.95*s,0),body_color.lightened(.1))
            fin.rotation_degrees.z=side*22
    elif archetype=="ARTHROPOD":
        for side in [-1.0,1.0]:
            for j in range(3):
                var leg:=_mesh("cylinder",Vector3(.10*s,.8*s,.10*s),Vector3(side*(.55+j*.12)*s,.55*s,(j-1)*.35*s),body_color.darkened(.08))
                leg.rotation_degrees.z=side*55

func _make_face(s:float)->void:
    for side in [-1.0,1.0]:
        var eye:=_mesh("sphere",Vector3(.16*s,.16*s,.16*s),Vector3(side*.28*s,1.98*s,.88*s),Color("0b1113"))
        eye.material_override.emission_enabled=true
        eye.material_override.emission=Color("d8f0d6")
        eye.material_override.emission_energy_multiplier=.15

func _make_stage_aura(s:float)->void:
    var ring:=MeshInstance3D.new(); var tor:=TorusMesh.new(); tor.inner_radius=.85*s; tor.outer_radius=.90*s; ring.mesh=tor; ring.position.y=-.18*s; ring.material_override=_mat(body_color,.45,.15); _root_visual.add_child(ring)

func _make_rare_trait_markers(p:Dictionary, s:float)->void:
    if not _root_visual: return
    var traits:Array=p.get("rare_traits",[])
    if traits.is_empty(): return
    var trait_id:=str(traits[0])
    if trait_id=="LEGACY_ECHO":
        var ring:=MeshInstance3D.new(); var tor:=TorusMesh.new(); tor.inner_radius=.72*s; tor.outer_radius=.78*s; ring.mesh=tor; ring.position.y=1.95*s; ring.material_override=_mat(Color("b9a7e6"),.35,.75); _root_visual.add_child(ring)
    elif trait_id=="SUNMARK":
        var mark:=_mesh("sphere",Vector3(.20*s,.10*s,.20*s),Vector3(0,1.95*s,.92*s),Color("e8c86a")); mark.material_override=_mat(Color("e8c86a"),.35,.2)
    elif trait_id=="FOREST_FRECKLE":
        for i in range(3): _mesh("sphere",Vector3(.10*s,.08*s,.10*s),Vector3((i-1)*.18*s,1.62*s,.82*s),Color("5e8c62"))
    elif trait_id=="MOON_EYE":
        var glow:=_mesh("sphere",Vector3(.18*s,.18*s,.18*s),Vector3(.28*s,1.98*s,.90*s),Color("d8e8ff")); glow.material_override=_mat(Color("d8e8ff"),.2,.0); glow.material_override.emission_enabled=true; glow.material_override.emission=Color("d8e8ff"); glow.material_override.emission_energy_multiplier=.65
    elif trait_id=="TIDAL_GLOW":
        var wave:=MeshInstance3D.new(); var tor2:=TorusMesh.new(); tor2.inner_radius=.52*s; tor2.outer_radius=.57*s; wave.mesh=tor2; wave.position.y=.62*s; wave.material_override=_mat(Color("79d4df"),.25,.7); _root_visual.add_child(wave)
    elif trait_id=="EMBER_TIP":
        var tip:=_mesh("sphere",Vector3(.22*s,.22*s,.22*s),Vector3(0,.70*s,-1.35*s),Color("ef8a57")); tip.material_override=_mat(Color("ef8a57"),.25,.25)

func _make_armor(p:Dictionary)->void:
    var armor_id:=str(p.get("current_armor",""))
    if armor_id.is_empty(): return
    # Armor candidates are loaded as real GLB attachments first. The procedural plate is only a
    # runtime-safe fallback when an asset is unavailable; it is never treated as final art.
    var armor_path:="res://assets/generated/armor/%s.glb" % armor_id
    if ResourceLoader.exists(armor_path):
        var packed:=load(armor_path) as PackedScene
        if packed:
            var armor_root:=Node3D.new()
            armor_root.name="ArmorAssetCandidate"
            _root_visual.add_child(armor_root)
            armor_root.add_child(packed.instantiate())
            armor_root.scale=Vector3.ONE * (0.72 + stage * 0.08)
            return
    var affinity:=GameState.armor_affinity(armor_id)
    var c:=GameState.affinity_color(affinity)
    var chest:=_mesh("box",Vector3(1.25,.28,1.05),Vector3(0,1.0,0),c)
    chest.material_override=_mat(c,.3,.65)
    var core:=_mesh("sphere",Vector3(.28,.28,.28),Vector3(0,1.05,.62),c.lightened(.2))
    core.material_override.emission_enabled=true
    core.material_override.emission=c
    core.material_override.emission_energy_multiplier=.8

func _make_perfect_resonance(p:Dictionary)->void:
    if int(p.get("perfect_resonance",0))<1 or not _root_visual: return
    var ring:=MeshInstance3D.new(); var tor:=TorusMesh.new(); tor.inner_radius=.98; tor.outer_radius=1.06; ring.mesh=tor; ring.position.y=1.15
    ring.material_override=_mat(Color("f4e6a1"),.15,.9); ring.material_override.emission_enabled=true; ring.material_override.emission=Color("f4e6a1"); ring.material_override.emission_energy_multiplier=1.8; _root_visual.add_child(ring)
    var light:=OmniLight3D.new(); light.light_color=Color("f4e6a1"); light.light_energy=2.8; light.omni_range=5.0; light.position.y=1.2; _root_visual.add_child(light)

func _make_resonance(p:Dictionary)->void:
    var res:=str(p.get("resonance_form",""))
    var dual:=str(p.get("dual_resonance_form",""))
    if res.is_empty() and dual.is_empty(): return
    var light:=OmniLight3D.new()
    light.light_color=GameState.affinity_color(GameState.armor_affinity(str(p.get("current_armor",""))))
    light.light_energy=1.7 if dual.is_empty() else 2.4
    light.omni_range=4.5
    light.position.y=1.2
    _root_visual.add_child(light)

func _color_for(c:Dictionary, f:Dictionary)->Color:
    var key:=str(c.get("archetype",f.get("model_archetype","OTHER")))
    var palette={"QUADRUPED":"d09b4a","BIPED":"8e9fc4","AVIAN":"6e9ac6","BIRD":"6e9ac6","SERPENTINE":"6b9a5c","REPTILE":"6b9a5c","AQUATIC":"4d9eb0","FISH":"4d9eb0","AMPHIBIOUS":"78a77b","AMPHIBIAN":"78a77b","ARTHROPOD":"9b7c44","MOLLUSK":"6d91a8","WINGED":"8d7ac1","HORNED":"8b7657","PRIMATE":"9a735e","ETHEREAL":"8067a9","HUMANOID_FOLKLORE":"a87c9d","MYSTICAL":"5b739c","OTHER":"a48663"}
    return Color(str(palette.get(key,"a48663")))
