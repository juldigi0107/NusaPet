class_name NusaShareCard
extends Node
## Native Godot share-card renderer. Saves only local game information; no personal account data.

func generate(pet:Dictionary, creature:Dictionary, region:String, portrait:Image = null) -> String:
    var vp:=SubViewport.new()
    vp.size=Vector2i(1080,1350)
    vp.transparent_bg=false
    vp.render_target_update_mode=SubViewport.UPDATE_ONCE
    add_child(vp)
    var root:=Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    vp.add_child(root)
    var bg:=ColorRect.new()
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.color=Color("10251f")
    root.add_child(bg)
    var box:=VBoxContainer.new()
    box.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    box.offset_left=90; box.offset_right=-90; box.offset_top=90; box.offset_bottom=-90
    box.add_theme_constant_override("separation",24)
    root.add_child(box)
    var title:=Label.new(); title.text="NUSAPET"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",64); box.add_child(title)
    if portrait != null and not portrait.is_empty():
        var texture:=ImageTexture.create_from_image(portrait)
        var portrait_rect:=TextureRect.new()
        portrait_rect.texture=texture
        portrait_rect.custom_minimum_size=Vector2(720,420)
        portrait_rect.expand_mode=TextureRect.EXPAND_IGNORE_SIZE
        portrait_rect.stretch_mode=TextureRect.STRETCH_KEEP_ASPECT_CENTERED
        portrait_rect.size_flags_horizontal=Control.SIZE_SHRINK_CENTER
        box.add_child(portrait_rect)
    var name:=Label.new(); name.text=str(pet.get("nickname","Nusa")); name.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; name.add_theme_font_size_override("font_size",52); box.add_child(name)
    var form:=Label.new(); form.text=str(creature.get("name_id",creature.get("name_en","Creature")))+"  •  "+str(pet.get("form_id","")); form.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; form.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; form.add_theme_font_size_override("font_size",30); box.add_child(form)
    var evo:=Label.new(); evo.text="Evolution path
"+" → ".join([str(x) for x in pet.get("evolution_history",[])]) ; evo.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; evo.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; evo.add_theme_font_size_override("font_size",24); box.add_child(evo)
    var reg:=Label.new(); reg.text="Region • "+region; reg.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; reg.add_theme_font_size_override("font_size",28); box.add_child(reg)
    await get_tree().process_frame
    await get_tree().process_frame
    var image:=vp.get_texture().get_image()
    var dir:=DirAccess.open("user://save/")
    if dir==null: DirAccess.make_dir_recursive_absolute("user://save/")
    var path:="user://save/share_card_%d.png"%int(Time.get_unix_time_from_system())
    if image.is_empty() or image.save_png(path)!=OK:
        vp.queue_free(); return ""
    vp.queue_free()
    return path
