class_name AuthAdapter
extends RefCounted
## Optional Supabase authentication adapter. Guest mode remains available offline.
signal auth_finished(ok: bool, user: Dictionary)
var authenticated := false
var user:Dictionary={}
var base_url := ""
var anon_key := ""
var access_token := ""

func _init() -> void:
    base_url=OS.get_environment("SUPABASE_URL").strip_edges().trim_suffix("/")
    anon_key=OS.get_environment("SUPABASE_ANON_KEY").strip_edges()

func sign_in(credential: Dictionary) -> bool:
    var email:=str(credential.get("email","")).strip_edges()
    var password:=str(credential.get("password",""))
    if base_url.is_empty() or anon_key.is_empty() or email.is_empty() or password.is_empty(): return false
    var request:=HTTPRequest.new()
    request.request_completed.connect(func(result,code,headers,body):
        var parsed=JSON.parse_string(body.get_string_from_utf8())
        var ok:=result==HTTPRequest.RESULT_SUCCESS and code>=200 and code<300 and typeof(parsed)==TYPE_DICTIONARY
        authenticated=ok
        user=parsed if ok else {}
        access_token=str(parsed.get("access_token", "")) if ok else ""
        auth_finished.emit(ok,user)
        request.queue_free())
    var headers:=PackedStringArray(["apikey: "+anon_key,"Content-Type: application/json"])
    var code:=request.request(base_url+"/auth/v1/token?grant_type=password",headers,HTTPClient.METHOD_POST,JSON.stringify({"email":email,"password":password}))
    if code!=OK: request.queue_free(); return false
    return true

func sign_out() -> void:
    authenticated=false
    user={}
    access_token=""
    auth_finished.emit(false,{})
