class_name NusaCreatureAnimationController
extends Node3D
## Runtime 3D animation layer for NusaPet creature assets.
## Uses a lightweight anatomical state machine so thousands of forms share
## a stable animation architecture while each species keeps its own meshes.

@export var asset_scene: PackedScene
@export var locomotion_profile: String = "WALK"
@export var enable_animated_parts: bool = true

var visual_root: Node3D
var animation_player: AnimationPlayer
var animation_tree: AnimationTree
var state_machine: AnimationNodeStateMachine
var current_state := "Idle"
var _parts: Array[Node3D] = []
var _playback: AnimationNodeStateMachinePlayback

const STATES := ["Idle","Blink","Walk","Run","Eat","Drink","Happy","Sad","Angry","Sleep","Wake","Play","Train","Dirty","Sick","Heal","Interact","Discover","Evolution","SpecialIdle"]

func setup(root: Node3D, profile: Dictionary = {}) -> void:
    visual_root = root
    locomotion_profile = str(profile.get("locomotion", locomotion_profile))
    _collect_parts(visual_root)
    _ensure_animation_nodes()
    _build_animation_library(profile)
    _build_state_machine()
    if animation_tree != null:
        _playback = animation_tree.get("parameters/playback") as AnimationNodeStateMachinePlayback
    play_state("Idle")

func _collect_parts(node: Node) -> void:
    for child in node.get_children():
        if child is Node3D:
            _parts.append(child)
            _collect_parts(child)

func _ensure_animation_nodes() -> void:
    animation_player = visual_root.get_node_or_null("AnimationPlayer") as AnimationPlayer
    if animation_player == null:
        animation_player = AnimationPlayer.new()
        animation_player.name = "AnimationPlayer"
        visual_root.add_child(animation_player)
    animation_tree = visual_root.get_node_or_null("AnimationTree") as AnimationTree
    if animation_tree == null:
        animation_tree = AnimationTree.new()
        animation_tree.name = "AnimationTree"
        visual_root.add_child(animation_tree)

func _build_animation_library(profile: Dictionary) -> void:
    var library := AnimationLibrary.new()
    for state in STATES:
        var anim := Animation.new()
        anim.length = 1.6 if state == "Idle" else 1.0
        anim.loop_mode = Animation.LOOP_LINEAR if state in ["Idle","Blink","Walk","Run","Sleep","SpecialIdle"] else Animation.LOOP_NONE
        _add_root_motion_track(anim, state)
        if enable_animated_parts:
            _add_part_tracks(anim, state)
        library.add_animation(state, anim)
    animation_player.add_animation_library("", library)

func _add_root_motion_track(anim: Animation, state: String) -> void:
    var track := anim.add_track(Animation.TYPE_POSITION_3D)
    anim.track_set_path(track, NodePath("."))
    var base := visual_root.position
    var amp := 0.025
    if state == "Walk": amp = 0.055
    elif state == "Run": amp = 0.10
    elif state == "Happy": amp = 0.08
    elif state == "Evolution": amp = 0.13
    anim.position_track_insert_key(track, 0.0, base)
    anim.position_track_insert_key(track, anim.length * 0.5, base + Vector3(0, amp, 0))
    anim.position_track_insert_key(track, anim.length, base)

func _add_part_tracks(anim: Animation, state: String) -> void:
    var candidates: Array[Node3D] = []
    for p in _parts:
        var n := p.name.to_lower()
        if n.contains("eye") or n.contains("torso") or n.contains("head") or n.contains("wing") or n.contains("fin") or n.contains("tail") or n.contains("leg") or n.contains("arm") or n.contains("marker"):
            candidates.append(p)
    for i in range(min(candidates.size(), 12)):
        var part := candidates[i]
        var track := anim.add_track(Animation.TYPE_ROTATION_3D)
        anim.track_set_path(track, visual_root.get_path_to(part))
        var base := part.rotation
        var phase := float(i % 3) * 0.13
        var amp := 0.025
        if state == "Blink" and part.name.to_lower().contains("eye"): amp = 0.35
        elif state == "Walk" or state == "Run": amp = 0.10
        elif state == "Happy": amp = 0.18
        elif state == "Sad": amp = 0.08
        elif state == "Angry": amp = 0.20
        elif state == "Evolution": amp = 0.32
        anim.rotation_track_insert_key(track, 0.0, base)
        anim.rotation_track_insert_key(track, anim.length * 0.5, base + Vector3(0, amp * sin(phase), amp))
        anim.rotation_track_insert_key(track, anim.length, base)

func _build_state_machine() -> void:
    state_machine = AnimationNodeStateMachine.new()
    for i in range(STATES.size()):
        var state: String = STATES[i]
        var node := AnimationNodeAnimation.new()
        node.animation = state
        state_machine.add_node(state, node, Vector2((i % 5) * 180, (i / 5) * 110))
    # Every authored runtime state is reachable through the same native Godot state machine.
    # This remains valid even when a future species asset replaces the procedural clips.
    for from_state in STATES:
        for to_state in STATES:
            if from_state == to_state:
                continue
            state_machine.add_transition(from_state, to_state, AnimationNodeStateMachineTransition.new())
    animation_tree.tree_root = state_machine
    animation_tree.anim_player = animation_tree.get_path_to(animation_player)
    animation_tree.active = true

func play_state(state: String) -> void:
    if state not in STATES:
        return
    current_state = state
    if _playback != null:
        _playback.travel(state)
    elif animation_player != null and animation_player.has_animation(state):
        animation_player.play(state)
