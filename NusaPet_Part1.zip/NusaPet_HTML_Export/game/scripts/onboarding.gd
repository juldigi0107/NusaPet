extends Control
## First-launch onboarding: language -> premise -> habitat -> mystery egg -> care tutorial.
## No gameplay is hidden here; it only prepares the first native 3D scene.
var step := 0
var title: Label
var body: Label
var actions: VBoxContainer
var preview_container: SubViewportContainer
var preview_root: Node3D
var preview_egg: Node3D

func _ready() -> void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _build()
    _render_step()

func _build() -> void:
    var bg := ColorRect.new()
    bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    bg.color = Color("07120f")
    add_child(bg)
    var margin := MarginContainer.new()
    margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left", 48)
    margin.add_theme_constant_override("margin_right", 48)
    margin.add_theme_constant_override("margin_top", 96)
    margin.add_theme_constant_override("margin_bottom", 96)
    add_child(margin)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 24)
    margin.add_child(box)
    title = Label.new()
    title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    title.add_theme_font_size_override("font_size", 42)
    box.add_child(title)
    preview_container=SubViewportContainer.new()
    preview_container.custom_minimum_size=Vector2(0,250)
    preview_container.stretch=true
    var viewport:=SubViewport.new()
    viewport.size=Vector2i(640,360)
    viewport.render_target_update_mode=SubViewport.UPDATE_ALWAYS
    preview_container.add_child(viewport)
    box.add_child(preview_container)
    _build_3d_preview(viewport)
    body = Label.new()
    body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    body.add_theme_font_size_override("font_size", 21)
    body.size_flags_vertical = Control.SIZE_EXPAND_FILL
    box.add_child(body)
    actions = VBoxContainer.new()
    actions.add_theme_constant_override("separation", 12)
    box.add_child(actions)

func _build_3d_preview(viewport:SubViewport)->void:
    preview_root=Node3D.new()
    viewport.add_child(preview_root)
    var environment:=WorldEnvironment.new()
    var env:=Environment.new()
    env.background_mode=Environment.BG_COLOR
    env.background_color=Color("07120f")
    env.ambient_light_source=Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color=Color("8db7a5")
    env.ambient_light_energy=1.1
    environment.environment=env
    preview_root.add_child(environment)
    var camera:=Camera3D.new()
    camera.position=Vector3(0,0.8,4.8)
    camera.look_at(Vector3(0,0.7,0))
    preview_root.add_child(camera)
    var light:=DirectionalLight3D.new()
    light.rotation_degrees=Vector3(-35,-25,0)
    light.light_energy=1.4
    preview_root.add_child(light)
    preview_egg=Node3D.new()
    preview_root.add_child(preview_egg)
    var egg:=MeshInstance3D.new()
    var sm:=SphereMesh.new(); sm.radius=1.0; sm.height=1.8
    egg.mesh=sm; egg.scale=Vector3(.78,1.18,.78)
    var material:=StandardMaterial3D.new(); material.albedo_color=Color("d6c18d"); material.roughness=.55
    egg.material_override=material
    preview_egg.add_child(egg)
    for i in range(3):
        var ring:=MeshInstance3D.new()
        var tor:=TorusMesh.new(); tor.inner_radius=.48; tor.outer_radius=.54
        ring.mesh=tor; ring.position.y=-.32+float(i)*.32
        var rm:=StandardMaterial3D.new(); rm.albedo_color=Color("7c9b77"); ring.material_override=rm
        preview_egg.add_child(ring)

func _process(delta:float)->void:
    if preview_egg:
        preview_egg.rotation.y+=delta*.28
        preview_egg.position.y=sin(Time.get_ticks_msec()/360.0)*.08

func _button(text: String, callback: Callable) -> void:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = Vector2(0, 68)
    b.pressed.connect(callback)
    actions.add_child(b)

func _render_step() -> void:
    for c in actions.get_children():
        c.queue_free()
    var lang := GameState.lang
    if step == 0:
        title.text = "NUSAPET"
        body.text = "Pilih bahasa / Choose language"
        _button("Bahasa Indonesia", func(): _choose_language("id"))
        _button("English", func(): _choose_language("en"))
        return
    if lang == "en":
        if step == 1:
            title.text = "Living Creatures of the Archipelago"
            body.text = "Care, explore, discover, and grow together in an original 3D Nusantara world."
            _button("Continue", func(): _next_step(2))
        elif step == 2:
            title.text = "Your First Habitat"
            body.text = "Start in a small, safe habitat. Day, night, weather, and your companion's behavior can change over time."
            _button("Enter habitat", func(): _next_step(3))
        elif step == 3:
            title.text = "Mystery Egg"
            body.text = "A living companion is waiting. Its personality and preferences will emerge from the way you care for it."
            _button("Meet the egg", func(): _finish())
        return
    if step == 1:
        title.text = "Living Creatures of the Archipelago"
        body.text = "Rawat, jelajahi, temukan, dan tumbuh bersama di dunia 3D Nusantara yang orisinal."
        _button("Lanjut", func(): _next_step(2))
    elif step == 2:
        title.text = "Habitat Pertama"
        body.text = "Mulai dari habitat kecil yang aman. Siang, malam, cuaca, dan perilaku companion berubah seiring waktu."
        _button("Masuk habitat", func(): _next_step(3))
    elif step == 3:
        title.text = "Telur Misterius"
        body.text = "Satu companion menunggu. Personality dan preferensinya akan tumbuh dari cara kamu merawatnya."
        _button("Temui telur", func(): _finish())

func _choose_language(value:String)->void:
    GameState.set_language(value)
    step=1
    _render_step()

func _next_step(value:int)->void:
    step=value
    _render_step()

func _finish() -> void:
    if not GameState.state.is_empty():
        GameState.state.meta.onboarding_complete = true
        GameState.save_game()
    get_tree().change_scene_to_file("res://scenes/main/Main.tscn")
