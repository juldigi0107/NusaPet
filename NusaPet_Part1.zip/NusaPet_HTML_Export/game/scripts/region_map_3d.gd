class_name NusaRegionMap3D
extends Node3D
## Lightweight stylized Indonesia diorama. Geography is intentionally non-navigational art,
## while authoritative region data remains in data/regions.
var region_nodes: Array[Node3D]=[]
var _clock:=0.0

func _ready()->void:
    _build()

func _build()->void:
    var labels=["SUMATRA","JAVA","KALIMANTAN","SULAWESI","BALI","NUSA TENGGARA","MALUKU","PAPUA","INDONESIAN SEAS"]
    var positions=[Vector3(-5,.0,1),Vector3(-1.8,.1,2),Vector3(1.5,.2,0),Vector3(4,.15,1),Vector3(-.7,.15,3.8),Vector3(1.5,.1,3.6),Vector3(4.2,.1,3.5),Vector3(6.3,.1,2.2),Vector3(0,-.2,-1.5)]
    for i in range(labels.size()):
        var island:=Node3D.new(); island.name=labels[i]
        island.position=positions[i]
        var mesh:=MeshInstance3D.new(); var sphere:=SphereMesh.new(); sphere.radius=.75 if i<8 else 3.8; sphere.height=.35; mesh.mesh=sphere
        mesh.scale=Vector3(1.5,.35,.7) if i<8 else Vector3(1.0,.12,1.0)
        var mat:=StandardMaterial3D.new(); mat.albedo_color=Color("3f705a") if i<8 else Color("315e6d"); mat.roughness=.9; mesh.material_override=mat
        island.add_child(mesh); add_child(island); region_nodes.append(island)

func _process(delta:float)->void:
    _clock+=delta
    for i in range(region_nodes.size()):
        var n:=region_nodes[i]
        n.position.y += sin(_clock*.7+i)*.001
        n.rotation.y += delta*.02 if i<8 else delta*.005
