class_name NusaLocalAnalytics
extends Node
## Privacy-first local analytics. Disabled by default and never transmitted by this service.

const PATH := "user://save/local_analytics.json"
var enabled := false
var events: Array = []
var max_events := 500

func _ready() -> void:
    if not FileAccess.file_exists(PATH):
        return
    var parsed = JSON.parse_string(FileAccess.get_file_as_string(PATH))
    if typeof(parsed) == TYPE_DICTIONARY:
        enabled = bool(parsed.get("enabled", false))
        events = parsed.get("events", []) if typeof(parsed.get("events", [])) == TYPE_ARRAY else []

func set_enabled(value: bool) -> void:
    enabled = value
    _persist()

func record(event_name: String, payload: Dictionary = {}) -> void:
    if not enabled or event_name.strip_edges().is_empty():
        return
    events.append({"event": event_name, "at": int(Time.get_unix_time_from_system()), "payload": payload.duplicate(true)})
    if events.size() > max_events:
        events = events.slice(events.size() - max_events, events.size())
    _persist()

func clear() -> void:
    events.clear()
    _persist()

func export_local() -> Dictionary:
    return {"enabled": enabled, "events": events.duplicate(true)}

func _persist() -> void:
    DirAccess.make_dir_recursive_absolute("user://save")
    var f := FileAccess.open(PATH, FileAccess.WRITE)
    if f != null:
        f.store_string(JSON.stringify(export_local()))
        f.close()
