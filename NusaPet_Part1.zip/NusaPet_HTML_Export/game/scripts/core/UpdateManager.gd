class_name NusaUpdateManager
extends Node
## Safe-point update coordinator. It never interrupts evolution, transformation,
## save transactions, or onboarding. Network/download implementation remains optional.

signal update_available(version: String)
signal update_deferred(version: String)
signal update_ready(version: String)

var current_version := "0.24.0"
var pending_version := ""
var pending_manifest: Dictionary = {}
var safe_point := true

func _ready() -> void:
    var cfg_path := "res://data/system/release_channels.json"
    if FileAccess.file_exists(cfg_path):
        var parsed = JSON.parse_string(FileAccess.get_file_as_string(cfg_path))
        if typeof(parsed) == TYPE_DICTIONARY:
            current_version = str(parsed.get("current_version", current_version))

func mark_gameplay_busy(busy: bool) -> void:
    safe_point = not busy
    if safe_point and not pending_version.is_empty():
        update_ready.emit(pending_version)

func offer_manifest(manifest: Dictionary) -> bool:
    var candidate := str(manifest.get("version", "")).strip_edges()
    if candidate.is_empty() or candidate == current_version:
        return false
    pending_version = candidate
    pending_manifest = manifest.duplicate(true)
    update_available.emit(candidate)
    if safe_point:
        update_ready.emit(candidate)
    else:
        update_deferred.emit(candidate)
    return true

func can_apply() -> bool:
    return safe_point and not pending_version.is_empty()

func pending() -> Dictionary:
    return pending_manifest.duplicate(true)

func acknowledge_applied() -> void:
    if pending_version.is_empty():
        return
    current_version = pending_version
    pending_version = ""
    pending_manifest = {}
