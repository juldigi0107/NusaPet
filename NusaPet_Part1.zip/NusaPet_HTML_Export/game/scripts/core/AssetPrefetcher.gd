class_name NusaAssetPrefetcher
extends Node
## Native threaded prefetch policy. It only requests resources that are already in the
## local project; it never treats a requested resource as approved production art.

var requested: Dictionary = {}
var max_requests := 12

func prefetch_for_current_state() -> void:
    if not is_instance_valid(GameState) or GameState.state.is_empty():
        return
    var p: Dictionary = GameState.state.pet
    var line := str(p.get("current_line_id", p.get("creature_id", "")))
    var stage := int(p.get("stage", 1))
    var paths: Array[String] = []
    for next_stage in [stage + 1, stage + 2]:
        if next_stage > 6:
            continue
        var form_id := "%s_s%d" % [line, next_stage]
        var form := GameState.form_record(form_id)
        var path := str(form.get("asset_manifest", {}).get("path", ""))
        if path.is_empty():
            path = "res://assets/generated/creatures/%s.glb" % form_id
        paths.append(path)
    var armor_id := str(p.get("current_armor", ""))
    if armor_id.is_empty():
        var inventory: Array = p.get("inventory", [])
        if not inventory.is_empty():
            armor_id = str(inventory[0])
    if not armor_id.is_empty():
        paths.append("res://assets/generated/armor/%s.glb" % armor_id)
    var requested_count := 0
    for path in paths:
        if requested_count >= max_requests:
            break
        if path.is_empty() or not ResourceLoader.exists(path) or requested.has(path):
            continue
        var err := ResourceLoader.load_threaded_request(path)
        if err == OK:
            requested[path] = Time.get_ticks_msec()
            requested_count += 1

func clear_completed() -> void:
    var stale: Array[String] = []
    for path in requested.keys():
        var status := ResourceLoader.load_threaded_get_status(str(path))
        if status == ResourceLoader.THREAD_LOAD_LOADED or status == ResourceLoader.THREAD_LOAD_FAILED:
            stale.append(str(path))
    for path in stale:
        requested.erase(path)
