class_name NusaRuntimePerformance
extends Node
## Applies mobile-conscious quality settings without touching gameplay state.

var profile := "BALANCED"
var reduced_motion := false

func apply(profile_name:String, reduced:bool=false)->void:
    profile = profile_name.to_upper()
    reduced_motion = reduced
    var vp := get_viewport()
    if vp == null:
        return
    if vp.has_method("set_scaling_3d_scale"):
        vp.set_scaling_3d_scale(1.0 if profile=="HIGH" else (0.72 if profile=="BATTERY_SAVER" else 0.82))
    if vp.has_method("set_scaling_3d_mode"):
        vp.set_scaling_3d_mode(Viewport.SCALING_3D_MODE_BILINEAR)

func motion_scale()->float:
    return 0.0 if reduced_motion else 1.0
