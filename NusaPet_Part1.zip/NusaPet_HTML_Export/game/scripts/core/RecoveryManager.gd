class_name NusaRecoveryManager
extends Node
## Centralized safe-point/recovery coordinator for critical gameplay transitions.
## It cannot intercept an OS/engine crash; it guarantees a recoverable checkpoint
## before evolution/Armor/Pusaka operations and exposes the recovery state to UI.

var current_operation := ""
var checkpoint_ready := false
var last_recovery_reason := ""

func begin(operation: String) -> void:
    current_operation = operation.to_upper()
    checkpoint_ready = true
    last_recovery_reason = ""

func complete() -> void:
    current_operation = ""
    checkpoint_ready = false

func mark_recovered(reason: String) -> void:
    last_recovery_reason = reason
    current_operation = ""
    checkpoint_ready = false

func status() -> Dictionary:
    return {"operation": current_operation, "checkpoint_ready": checkpoint_ready, "last_recovery_reason": last_recovery_reason}
