extends Control
## Developer-only Master Prompt coverage dashboard. Never referenced by production navigation.
func _ready()->void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    var scroll:=ScrollContainer.new(); scroll.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(scroll)
    var box:=VBoxContainer.new(); box.add_theme_constant_override("separation",8); scroll.add_child(box)
    var title:=Label.new(); title.text="NusaPet — MASTER PROMPT CONTENT AUDIT"; title.add_theme_font_size_override("font_size",28); box.add_child(title)
    var real:=0; var myth:=0; var myst:=0
    for c in GameState.catalog.creatures:
        match str(c.get("category","")):
            "REAL": real+=1
            "MYTHOLOGY": myth+=1
            "MYSTICAL": myst+=1
    var rows=[
        ["REAL",250,real],["MYTHOLOGY/FOLKLORE",50,myth],["MYSTICAL",50,myst],
        ["PRIMARY FORMS",2100,GameState.catalog.forms.size()],
        ["ARMOR",700,GameState.catalog.armor.size()],
        ["CROSS PATHS",350,GameState.catalog.cross.size()],
        ["PUSAKA",15,GameState.catalog.artifacts.size()]
    ]
    for row in rows:
        var l:=Label.new(); l.text="%s: %d/%d %s"%[row[0],int(row[2]),int(row[1]),"PASS" if int(row[2])>=int(row[1]) else "BLOCKED"]; box.add_child(l)
    var blocker:=Label.new(); blocker.text="External gates remain human/native-toolchain gated: scientific publication, cultural review, final art, native exports/devices, performance/visual regression."; blocker.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(blocker)
