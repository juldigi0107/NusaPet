class_name NusaHabitatScene
extends Node3D

var world: WorldBuilder

func _ready() -> void:
    world = WorldBuilder.new()
    add_child(world)
    world.build_habitat()

func set_region(value:String) -> void:
    if world: world.set_region(value)

func set_habitat(value:String) -> void:
    if world: world.set_habitat(value)

func set_weather(value:String) -> void:
    if world: world.set_weather(value)

func update(delta:float) -> void:
    if world: world.update(delta)
