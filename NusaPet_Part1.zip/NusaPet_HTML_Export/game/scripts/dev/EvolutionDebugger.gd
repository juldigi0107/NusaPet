@tool
extends Control
class_name NusaEvolutionDebugger
## Developer-only evolution inspection. Never added to production scenes.
func inspect_pet(pet_state:Dictionary)->Dictionary:
    var gs:=NusaGameState.new()
    gs._load_content()
    gs.state={"pet":pet_state,"player":{"research":0,"selected_region":"sumatra"},"collection":{"cross_paths":[]},"world":{"region":"sumatra","weather":"CLEAR","time_phase":"DAY"}}
    return {"forecast":gs.evolution_forecast(),"hints":gs.evolution_hints()}
