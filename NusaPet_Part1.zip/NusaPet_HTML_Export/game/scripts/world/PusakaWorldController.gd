class_name NusaPusakaWorldController
extends Node3D
## Native 3D Pusaka discovery/pickup layer. Secret artifacts remain discovery-gated.

signal pusaka_discovered(artifact_id: String)
signal pusaka_pickup_rejected(artifact_id: String)

var world: WorldBuilder
var _nodes: Dictionary = {}

func setup(habitat_world: WorldBuilder) -> void:
    world = habitat_world
    _rebuild()

func _rebuild() -> void:
    _nodes.clear()
    for child in get_children():
        child.queue_free()
    if world == null:
        return
    var artifacts: Array = GameState.catalog.artifacts
    var index := 0
    for artifact in artifacts:
        var id := str(artifact.get("id", ""))
        if id.is_empty() or bool(artifact.get("secret", false)):
            continue
        if id in GameState.state.pet.discovered_artifacts:
            continue
        var root := Area3D.new()
        root.name = "Pusaka_%s" % id
        root.position = Vector3(-6.0 + float(index % 4) * 4.0, 0.45, 7.0 - float(index / 4) * 4.0)
        root.collision_layer = 8
        root.collision_mask = 1
        root.input_ray_pickable = true
        var shape := CollisionShape3D.new()
        var sphere := SphereShape3D.new()
        sphere.radius = 0.55
        shape.shape = sphere
        root.add_child(shape)
        var mesh := MeshInstance3D.new()
        var gem := SphereMesh.new()
        gem.radius = 0.24
        gem.height = 0.52
        mesh.mesh = gem
        var material := StandardMaterial3D.new()
        material.albedo_color = Color("d5ad59")
        material.emission_enabled = true
        material.emission = Color("6f5124")
        material.emission_energy_multiplier = 1.0
        mesh.material_override = material
        root.add_child(mesh)
        root.input_event.connect(_on_pusaka_input.bind(id, root))
        add_child(root)
        _nodes[id] = root
        index += 1

func _on_pusaka_input(_camera: Node, event: InputEvent, _position: Vector3, _normal: Vector3, _shape_idx: int, id: String, root: Area3D) -> void:
    if not ((event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT) or (event is InputEventScreenTouch and event.pressed)):
        return
    if _pickup(id):
        pusaka_discovered.emit(id)
        root.queue_free()
        _nodes.erase(id)
    else:
        pusaka_pickup_rejected.emit(id)

func _pickup(id: String) -> bool:
    if not GameState.state.pet.hatched:
        return false
    var artifact := GameState._artifact(id)
    if artifact.is_empty() or bool(artifact.get("secret", false)):
        return false
    if id in GameState.state.pet.discovered_artifacts:
        return false
    GameState.state.pet.discovered_artifacts.append(id)
    GameState.state.pet.inventory.append(id)
    if id not in GameState.state.collection.artifacts:
        GameState.state.collection.artifacts.append(id)
    GameState.state.pet.memories.append("pusaka_discovered_%s" % id)
    GameState._touch()
    GameState._transactional_save("PUSAKA_PICKUP")
    GameState.state_changed.emit()
    return true
