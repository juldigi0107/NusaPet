class_name WorldBuilder
extends Node3D

var sun: DirectionalLight3D
var environment: WorldEnvironment
var weather_particles: GPUParticles3D
var day_clock := 0.30
var weather := "CLEAR"
var region := "JAVA"
var habitat := "Tropical Rainforest"
var _ambient_time := 0.0
var ambient_wildlife: Array[Node3D] = []
var pusaka_nodes: Array[Node3D] = []
var interaction_anchors: Dictionary = {}
var ground_material: StandardMaterial3D
var water_material: StandardMaterial3D
var sky_material: ProceduralSkyMaterial
var performance_profile := "BALANCED"
var _base_wildlife_count := 8

func build_habitat() -> void:
    environment=WorldEnvironment.new(); var e:=Environment.new(); e.background_mode=Environment.BG_SKY
    var sky:=Sky.new(); sky_material=ProceduralSkyMaterial.new(); sky_material.sky_top_color=Color("071b2a"); sky_material.sky_horizon_color=Color("9bb7ad"); sky_material.ground_bottom_color=Color("08140f"); sky_material.ground_horizon_color=Color("6b8d7e"); sky.sky_material=sky_material; e.sky=sky
    e.ambient_light_source=Environment.AMBIENT_SOURCE_SKY; e.ambient_light_energy=.65; e.tonemap_mode=Environment.TONE_MAPPER_FILMIC; environment.environment=e; add_child(environment)
    sun=DirectionalLight3D.new(); sun.rotation_degrees=Vector3(-48,-25,0); sun.light_energy=1.25; sun.shadow_enabled=true; add_child(sun)
    _make_ground(); _make_water(); _make_vegetation(); _make_props(); _make_interaction_anchors(); _make_weather(); _make_ambient_wildlife(); _make_pusaka_nodes()

func _make_ground():
    var ground:=MeshInstance3D.new(); var mesh:=PlaneMesh.new(); mesh.size=Vector2(22,28); ground.mesh=mesh; ground_material=StandardMaterial3D.new(); ground_material.albedo_color=Color("163b2f"); ground_material.roughness=.94; ground.material_override=ground_material; add_child(ground)
    var body:=StaticBody3D.new(); body.name="HabitatGroundCollision"
    var shape:=CollisionShape3D.new(); var box:=BoxShape3D.new(); box.size=Vector3(22,.2,28); shape.shape=box; shape.position.y=-.1; body.add_child(shape); add_child(body)
func _make_water():
    var water:=MeshInstance3D.new(); var mesh:=PlaneMesh.new(); mesh.size=Vector2(7,9); water.mesh=mesh; water.position=Vector3(7,.035,-3); water_material=StandardMaterial3D.new(); water_material.albedo_color=Color("245d68"); water_material.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; water_material.albedo_color.a=.72; water_material.roughness=.2; water.material_override=water_material; add_child(water)
func _make_vegetation():
    for i in range(30):
        var x:=float((i*37)%180)/10.0-9.0; var z:=float((i*61)%240)/10.0-12.0
        if abs(x)<2.5 and abs(z)<2.5: continue
        var trunk:=MeshInstance3D.new(); var cm:=CylinderMesh.new(); cm.top_radius=.14; cm.bottom_radius=.28; cm.height=1.8+float(i%3)*.4; trunk.mesh=cm; trunk.position=Vector3(x,cm.height/2,z); var tm:=StandardMaterial3D.new(); tm.albedo_color=Color("3b2a20"); trunk.material_override=tm; add_child(trunk)
        var crown:=MeshInstance3D.new(); var sm:=SphereMesh.new(); sm.radius=.9+.1*(i%3); sm.height=1.5; crown.mesh=sm; crown.position=Vector3(x,2.1+.2*(i%3),z); var gm:=StandardMaterial3D.new(); gm.albedo_color=Color("2d6b4b"); gm.roughness=.8; crown.material_override=gm; add_child(crown)

func _make_interaction_anchors() -> void:
    var definitions := {
        "water": Vector3(7.0,0.25,-3.0),
        "perch": Vector3(-3.5,2.1,-4.0),
        "hide": Vector3(-5.5,0.6,-6.0),
        "dig": Vector3(2.5,0.08,6.0),
        "climb": Vector3(-7.0,1.0,3.5),
        "rest": Vector3(0.0,0.2,3.8),
        "observe": Vector3(4.0,0.35,-5.5),
        "play": Vector3(0.0,0.25,0.5)
    }
    interaction_anchors.clear()
    for id in definitions.keys():
        var anchor := Node3D.new()
        anchor.name = "HabitatAnchor_%s" % str(id).capitalize()
        anchor.position = definitions[id]
        anchor.set_meta("interaction_id", str(id))
        add_child(anchor)
        interaction_anchors[str(id)] = anchor

func has_interaction_anchor(id:String) -> bool:
    return interaction_anchors.has(id) and is_instance_valid(interaction_anchors[id])

func interaction_anchor(id:String) -> Dictionary:
    if not has_interaction_anchor(id): return {}
    var anchor:Node3D = interaction_anchors[id]
    return {"id":id,"position":anchor.global_position,"node":anchor}

func _make_props():
    for pos in [Vector3(-2,.25,-1),Vector3(3,.25,2),Vector3(-4,.25,4)]:
        var rock:=MeshInstance3D.new(); var sm:=SphereMesh.new(); sm.radius=.45; sm.height=.65; rock.mesh=sm; rock.scale=Vector3(1.4,.7,1.0); rock.position=pos; var m:=StandardMaterial3D.new(); m.albedo_color=Color("6a7169"); m.roughness=1.0; rock.material_override=m; add_child(rock)
func _make_weather():
    weather_particles=GPUParticles3D.new(); weather_particles.amount=180; weather_particles.lifetime=2.5; weather_particles.emitting=false
    var process:=ParticleProcessMaterial.new(); process.direction=Vector3(0,-1,0); process.initial_velocity_min=3; process.initial_velocity_max=6; process.gravity=Vector3(0,-2,0); process.spread=8; weather_particles.process_material=process
    var mesh:=QuadMesh.new(); mesh.size=Vector2(.035,.6); var mm:=StandardMaterial3D.new(); mm.albedo_color=Color("b6d6e0"); mm.transparency=BaseMaterial3D.TRANSPARENCY_ALPHA; mesh.material=mm; weather_particles.draw_pass_1=mesh; weather_particles.position=Vector3(0,7,0); add_child(weather_particles)


func _make_ambient_wildlife() -> void:
    for i in range(8):
        var n:=Node3D.new(); n.position=Vector3(float((i*29)%140)/10.0-7.0,0.35+float(i%2)*.25,float((i*47)%180)/10.0-9.0)
        var body:=MeshInstance3D.new(); var sm:=SphereMesh.new(); sm.radius=.10+.025*(i%3); sm.height=.22; body.mesh=sm
        var mat:=StandardMaterial3D.new(); mat.albedo_color=Color("7f9c74"); mat.roughness=.8; body.material_override=mat; n.add_child(body); add_child(n); ambient_wildlife.append(n)

func _make_pusaka_nodes() -> void:
    for i in range(3):
        var n:=Node3D.new(); n.position=Vector3(-5.0+i*5.0,.22,5.0-float(i%2)*2.0)
        var gem:=MeshInstance3D.new(); var sm:=SphereMesh.new(); sm.radius=.16; sm.height=.36; gem.mesh=sm
        var mat:=StandardMaterial3D.new(); mat.albedo_color=Color("d5ad59"); mat.emission_enabled=true; mat.emission=Color("6f5124"); mat.emission_energy_multiplier=.8; gem.material_override=mat; n.add_child(gem); add_child(n); pusaka_nodes.append(n)

func set_performance_profile(value:String)->void:
    performance_profile = value.to_upper()
    var low := performance_profile in ["BATTERY_SAVER", "LOW_STORAGE"]
    var high := performance_profile == "HIGH"
    if weather_particles:
        weather_particles.amount = 320 if high else (90 if low else 180)
    for i in range(ambient_wildlife.size()):
        ambient_wildlife[i].visible = high or not low or i < 3

func update(delta:float)->void:
    var tick_rate:=0.006 if performance_profile=="HIGH" else (0.0025 if performance_profile in ["BATTERY_SAVER","LOW_STORAGE"] else 0.004)
    _ambient_time+=delta; day_clock=fmod(day_clock+delta*tick_rate,1.0); var angle:=day_clock*TAU
    if sun: sun.rotation_degrees.x=-35+sin(angle)*55; sun.light_energy=.45+max(0.0,sin(angle))*.95
    if environment and environment.environment: environment.environment.ambient_light_energy=.25+max(0.0,sin(angle))*.5
    if weather_particles:
        weather_particles.emitting=(weather=="RAIN" or weather=="STORM" or weather=="WIND")
        weather_particles.amount=280 if weather=="STORM" else (120 if weather in ["RAIN","WIND"] else 0)
    for i in range(ambient_wildlife.size()):
        var n:=ambient_wildlife[i]; n.position.x+=sin(_ambient_time*(.4+float(i%3)*.15)+i)*delta*.05; n.position.z+=cos(_ambient_time*(.35+float(i%2)*.2)+i)*delta*.04
    for i in range(pusaka_nodes.size()):
        var n:=pusaka_nodes[i]; n.position.y=.22+sin(_ambient_time*1.6+i)*.08; n.rotation.y+=delta*(.4+i*.08)

func set_weather(value:String):
    if value in ["CLEAR","RAIN","STORM","FOG","HEAT","WIND"]:
        weather=value
        if environment and environment.environment:
            environment.environment.fog_enabled=(value=="FOG")
            environment.environment.fog_light_color=Color("a7b5ad")
            environment.environment.fog_density=.035 if value=="FOG" else 0.0
        if sun:
            sun.light_energy=1.45 if value=="HEAT" else sun.light_energy
func set_region(value:String):
    region=value.to_upper()
    _apply_region_theme()

func _apply_region_theme()->void:
    var theme={
        "SUMATRA":{"ground":"173f31","water":"245f68","sky":"7fa7a0"},
        "JAVA":{"ground":"4d432b","water":"286777","sky":"b7a98b"},
        "KALIMANTAN":{"ground":"214b35","water":"1f6970","sky":"7fae9b"},
        "SULAWESI":{"ground":"4c5030","water":"236878","sky":"8db3b0"},
        "BALI":{"ground":"4b3c2d","water":"2b6872","sky":"d2b28e"},
        "NUSA TENGGARA":{"ground":"6a5430","water":"2c6c78","sky":"d6b88d"},
        "MALUKU":{"ground":"254d3b","water":"1c7180","sky":"86b6b4"},
        "PAPUA":{"ground":"263f32","water":"1f6870","sky":"86a9a2"},
        "INDONESIAN SEAS":{"ground":"1e3d45","water":"185f70","sky":"7caeb8"}
    }
    var t:Dictionary=theme.get(region,theme["JAVA"])
    if ground_material: ground_material.albedo_color=Color(str(t.ground))
    if water_material: water_material.albedo_color=Color(str(t.water)); water_material.albedo_color.a=.72
    if sky_material:
        sky_material.sky_horizon_color=Color(str(t.sky))
func set_habitat(value:String): habitat=value
func time_label()->String:
    if day_clock<.23: return "NIGHT"
    if day_clock<.30: return "DAWN"
    if day_clock<.72: return "DAY"
    if day_clock<.80: return "SUNSET"
    return "NIGHT"
