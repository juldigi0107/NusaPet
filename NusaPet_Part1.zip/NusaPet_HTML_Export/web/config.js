// Public browser configuration only. Never put service-role or secret keys here.
window.NUSA_CONFIG = { SUPABASE_URL: '', SUPABASE_ANON_KEY: '' };
