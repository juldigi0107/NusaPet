extends Node

var _export_callback: JavaScriptObject
var _import_callback: JavaScriptObject
var _save_callback: JavaScriptObject

func _ready() -> void:
    if not OS.has_feature("web"):
        return
    _export_callback = JavaScriptBridge.create_callback(_export_save)
    _import_callback = JavaScriptBridge.create_callback(_import_save)
    _save_callback = JavaScriptBridge.create_callback(_save_now)
    var bridge = JavaScriptBridge.get_interface("NusaWeb")
    bridge.exportSave = _export_callback
    bridge.importSave = _import_callback
    bridge.saveNow = _save_callback
    bridge.enable()
    if not OS.is_userfs_persistent():
        bridge.notify("Penyimpanan browser tidak persisten. Unduh save sebelum menutup permainan.")

func _export_save(_arguments: Array) -> void:
    var path := "user://save/browser_export.json"
    if GameState.export_save(path):
        JavaScriptBridge.download_buffer(FileAccess.get_file_as_bytes(path), "NusaPet-save.json", "application/json")
        _notify("Save telah disiapkan untuk diunduh.")
    else:
        _notify("Save gagal diekspor.")

func _import_save(arguments: Array) -> void:
    if arguments.is_empty():
        return
    var path := "user://save/browser_import.json"
    var file := FileAccess.open(path, FileAccess.WRITE)
    if file == null:
        _notify("File impor tidak dapat ditulis.")
        return
    file.store_string(str(arguments[0]))
    file.close()
    if GameState.import_save(path):
        _notify("Save berhasil diimpor.")
        get_tree().reload_current_scene()
    else:
        _notify("Impor ditolak: format, checksum, atau data save tidak valid.")

func _save_now(_arguments: Array) -> void:
    GameState.save_game()

func _notify(message: String) -> void:
    JavaScriptBridge.get_interface("NusaWeb").notify(message)
