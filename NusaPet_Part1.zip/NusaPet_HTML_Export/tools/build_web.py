#!/usr/bin/env python3
"""Stage and export original game without editing its preserved source tree."""
import argparse, hashlib, json, pathlib, re, shutil, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--godot',default='godot')
p.add_argument('--prepare-only',action='store_true')
a=p.parse_args()
manifest=json.loads((ROOT/'SOURCE_MANIFEST.json').read_text())
for entry in manifest['files']:
    path=ROOT/'game'/entry['path']
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
        sys.exit('Original source integrity failed: '+entry['path'])
stage=ROOT/'.build'/'game'
if stage.exists(): shutil.rmtree(stage)
shutil.copytree(ROOT/'game',stage)
(stage/'web').mkdir(exist_ok=True)
for name in ['shell.html','WebBridge.gd']:
    shutil.copy2(ROOT/'web'/name,stage/'web'/name)
project=stage/'project.godot'
s=project.read_text()
s=s.replace('[autoload]','[autoload]\nWebBridge="*res://web/WebBridge.gd"',1)
# Bridge needs GameState ready first: append after the existing autoloads.
s=s.replace('WebBridge="*res://web/WebBridge.gd"\n','')
s=s.replace('[display]','WebBridge="*res://web/WebBridge.gd"\n\n[display]',1)
s+='\n[audio]\ngeneral/default_playback_type.web=1\n'
project.write_text(s)
# Generated sound uses streaming playback on web to preserve AudioStreamGenerator.
for name in ['AuthAdapter.gd','CloudSaveAdapter.gd']:
    path=stage/'scripts/adapters'/name
    s=path.read_text()
    marker='    anon_key=OS.get_environment("SUPABASE_ANON_KEY").strip_edges()'
    assert marker in s,name
    s=s.replace(marker,marker+'\n    if OS.has_feature("web"):\n        var config = JavaScriptBridge.get_interface("NUSA_CONFIG")\n        if config != null:\n            base_url = str(config.SUPABASE_URL).strip_edges().trim_suffix("/")\n            anon_key = str(config.SUPABASE_ANON_KEY).strip_edges()',1)
    path.write_text(s)
# Browser downloads in addition to the existing in-game screenshot archive.
for rel,marker in [('scripts/share_card.gd','    vp.queue_free()\n    return path'),('scripts/core/GameState.gd','    if path not in state.pet.screenshot_memory:')]:
    path=stage/rel;s=path.read_text();assert marker in s,rel
    addition='    if OS.has_feature("web"):\n        JavaScriptBridge.download_buffer(image.save_png_to_buffer(), path.get_file(), "image/png")\n'
    s=s.replace(marker,addition+marker,1);path.write_text(s)
with (stage/'export_presets.cfg').open('a') as f:
    f.write('''\n[preset.6]
name="Web Full Content"
platform="Web"
runnable=true
export_filter="all_resources"
include_filter="data/*,assets/*,*.json,*.jsonl,*.csv,*.txt,*.md,*.sql"
exclude_filter=""
export_path="../../dist/index.html"
script_export_mode=1

[preset.6.options]
variant/extensions_support=false
variant/thread_support=false
vram_texture_compression/for_desktop=true
vram_texture_compression/for_mobile=true
html/custom_html_shell="res://web/shell.html"
html/canvas_resize_policy=2
html/focus_canvas_on_start=true
progressive_web_app/enabled=false
''')
print('Staged source: all original content retained; browser compatibility patches applied.')
if a.prepare_only: sys.exit(0)
executable=shutil.which(a.godot)
if not executable: sys.exit('BUILD BLOCKED: Godot executable unavailable. Source staging succeeded; no playable HTML claimed.')
version=subprocess.check_output([executable,'--version'],text=True).strip()
if not version.startswith('4.3.'):
    sys.exit('This build recipe is pinned to Godot 4.3; got '+version)
output=ROOT/'dist';output.mkdir(exist_ok=True)
commands=[['--headless','--editor','--path',str(stage),'--import'],['--headless','--path',str(stage),'--export-release','Web Full Content',str(output/'index.html')]]
for i,command in enumerate(commands):
    run=subprocess.run([executable]+command,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    (ROOT/f'build-step-{i+1}.log').write_text(run.stdout)
    print(run.stdout[-4000:])
    if run.returncode or re.search(r'SCRIPT ERROR:|Parse Error:|Failed to load script',run.stdout):
        sys.exit('Godot build failed. See build-step log. No success claimed.')
for name in ['index.html','index.js','index.wasm','index.pck']:
    file=output/name
    if not file.is_file() or file.stat().st_size==0: sys.exit('Missing export file: '+name)
shutil.copy2(ROOT/'web/config.js',output/'config.js')
(ROOT/'BUILD_STATUS.json').write_text(json.dumps({'status':'EXPORTED_NOT_BROWSER_TESTED','godot':version},indent=2))
print('Web export generated at dist/index.html. Serve the complete dist folder; browser testing is still required.')
