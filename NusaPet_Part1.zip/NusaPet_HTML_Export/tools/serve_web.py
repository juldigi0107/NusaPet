#!/usr/bin/env python3
import functools,http.server,pathlib
root=pathlib.Path(__file__).resolve().parents[1]/'dist'
if not (root/'index.wasm').exists(): raise SystemExit('Build belum selesai. Jalankan tools/build_web.py terlebih dahulu.')
http.server.SimpleHTTPRequestHandler.extensions_map['.wasm']='application/wasm'
print('NusaPet: http://localhost:8080 — Ctrl+C untuk berhenti')
http.server.ThreadingHTTPServer(('127.0.0.1',8080),functools.partial(http.server.SimpleHTTPRequestHandler,directory=str(root))).serve_forever()
