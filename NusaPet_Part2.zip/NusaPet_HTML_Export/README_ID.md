# NusaPet — paket ekspor HTML dengan sumber lengkap

STATUS: PERSIAPAN EKSPOR SELESAI; GAME WEB BELUM DIKOMPILASI.

Paket ini belum berisi index.wasm/index.pck hasil kompilasi dan belum dapat dimainkan. Mesin Godot dan export templates tidak tersedia di lingkungan pembuat; akses unduh terhalang jaringan. Jangan menganggap shell.html sebagai game HTML jadi. Kesetaraan fungsi browser belum dapat dinyatakan sebelum build dan pengujian runtime berhasil.

## Isi yang dipertahankan

Folder game/ memuat 3.364 berkas asli (102.921.056 byte), tanpa perubahan atau penghapusan. SOURCE_MANIFEST.json mencatat SHA-256 setiap berkas. Termasuk 350 makhluk (250 REAL, 50 MYTHOLOGY, 50 MYSTICAL), 2.100 bentuk evolusi dalam enam tahap, 700 armor, 350 cross-path, 15 pusaka, 15 resonance form, 9 region, 16 habitat, 2.800 GLB, seluruh teks ID/EN, quest, achievement, makanan, mainan, dokumentasi, skema SQL, dan seed backend.

## Cara menghasilkan game HTML

Pilihan tanpa instalasi laptop: unggah seluruh ISI folder ini ke satu repository GitHub, termasuk .github/workflows/build-html.yml. Pada Actions, pilih Build NusaPet HTML, lalu Run workflow. Workflow mengunduh Godot 4.3 dan export templates yang cocok, memverifikasi sumber, mengimpor aset, dan mengekspor web. Jika berhasil, unduh artifact NusaPet-HTML. Workflow ini belum dijalankan dalam sesi pembuatan paket; kegagalan kompilasi akan menghentikannya dan menyimpan log, bukan menghasilkan klaim sukses.

Pilihan lokal: pasang Godot 4.3 beserta export templates versi yang sama. Jalankan:

    python3 tools/build_web.py --godot /lokasi/ke/godot
    python3 tools/serve_web.py

Buka http://localhost:8080. Untuk hosting, unggah SELURUH isi dist/ ke hosting statis HTTPS. Jangan hanya mengunggah index.html atau mengganti nama file pendamping. HTML menjalankan mesin WebAssembly dan paket aset PCK, bukan HTML tunggal mandiri.

## Penyesuaian browser

Build menyalin sumber ke .build/game dan menerapkan penyesuaian hanya pada salinan tersebut:
- Preset Web Full Content dengan all_resources dan filter data non-resource.
- Renderer Compatibility asli dipertahankan; thread dimatikan untuk kebutuhan hosting yang lebih sederhana.
- Streaming audio web untuk AudioStreamGenerator asli.
- Shell responsif dengan Mulai bermain, indikator muat, layar penuh, ekspor/impor save.
- Impor memakai validator dan checksum GameState asli, bukan jalur yang melewati validasi.
- Download screenshot dan share card PNG, sementara arsip lokal asli dipertahankan.
- Konfigurasi Supabase opsional melalui web/config.js; hanya URL dan anon/public key. Jangan menaruh service-role key. Tidak ada server/cloud baru yang dibuat atau data backend yang dipindahkan otomatis.

## Verifikasi yang sudah dilakukan

Seluruh hash sumber cocok dengan lampiran ZIP. Enam pemeriksaan Python sumber lolos: konten, graf evolusi, pusaka, lokalisasi, kontrak save, dan kontrak UI. Pemeriksaan save/UI merupakan kontrak statis dan tidak membuktikan runtime browser.

Audit konten menemukan 350 peringatan bawaan: research/cultural review belum berstatus PUBLISHED. Data tetap dipertahankan apa adanya. Tidak ada klaim seluruh pengetahuan sudah diverifikasi ilmiah.

## Verifikasi yang masih harus dilakukan sesudah build

- Godot import/parser dan ekspor Web berhasil tanpa SCRIPT ERROR.
- Onboarding, menetas, perawatan, save/reload dan impor/ekspor.
- Keenam tahap, cross-branch, armor, pusaka, resonance, eksplorasi, quest, koleksi, ensiklopedia, pengaturan, dan legacy.
- Semua model dan data yang dimuat dinamis benar-benar masuk PCK.
- Screenshot/share-card terunduh; audio bekerja sesudah mengetuk Mulai bermain.
- Safari iPhone dan desktop; browser memerlukan WebAssembly/WebGL 2.
- Jika cloud digunakan: konfigurasi, CORS, login, dan sinkronisasi diuji dengan backend asli. Adapter cloud sumber dipertahankan; belum diverifikasi melalui akun nyata.

Kemajuan user:// di web mengandalkan penyimpanan browser; gunakan Unduh save untuk cadangan. Perpindahan perangkat/domain tidak otomatis memindahkan save lokal.

Referensi resmi: https://docs.godotengine.org/en/4.3/tutorials/export/exporting_for_web.html
https://docs.godotengine.org/en/4.3/tutorials/platform/web/customizing_html5_shell.html
