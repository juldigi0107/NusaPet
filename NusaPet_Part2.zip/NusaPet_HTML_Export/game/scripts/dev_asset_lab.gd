extends Node3D
## Developer-only 3D Asset Lab. Never added to production navigation.
## Loads an actual GLB from the asset manifest and exposes the shared animation state layer.

@export var preview_asset: String = "res://assets/generated/creatures/real_001_s5.glb"
var camera: Camera3D
var root: Node3D
var preview: Node3D
var anim: NusaCreatureAnimationController
var state_index := 0
const STATES := ["Idle","Blink","Walk","Run","Eat","Drink","Happy","Sad","Angry","Sleep","Wake","Play","Train","Dirty","Sick","Heal","Interact","Discover","Evolution","SpecialIdle"]

func _ready() -> void:
    camera = Camera3D.new()
    camera.position = Vector3(0, 2.0, 6.0)
    add_child(camera)
    camera.look_at(Vector3(0, 1.0, 0))
    root = Node3D.new()
    root.name = "AssetLabRoot"
    add_child(root)
    _load_preview(preview_asset)

func _load_preview(path: String) -> void:
    if not ResourceLoader.exists(path):
        return
    var packed := load(path) as PackedScene
    if packed == null:
        return
    preview = packed.instantiate() as Node3D
    preview.name = "REAL_GLB_PREVIEW"
    root.add_child(preview)
    anim = NusaCreatureAnimationController.new()
    root.add_child(anim)
    anim.setup(preview, {"locomotion":"WALK"})
    var label := Label3D.new()
    label.text = "%s\n[Asset Lab — Developer Only]" % path.get_file()
    label.position = Vector3(0, 2.4, 0)
    root.add_child(label)

func cycle_state() -> void:
    if anim == null:
        return
    state_index = (state_index + 1) % STATES.size()
    anim.play_state(STATES[state_index])
