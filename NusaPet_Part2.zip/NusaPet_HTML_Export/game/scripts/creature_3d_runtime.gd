class_name NusaCreature3DRuntime
extends Node3D
## Native 3D creature runtime. Loads the real GLB candidate when available and
## falls back to the validated procedural silhouette when a critical asset fails.
@export var creature_id := ""
@export var stage := 1
@export var asset_path := ""
var asset_instance: Node3D
var animation_controller: NusaCreatureAnimationController
var fallback_visual: NusaCreatureVisual
var current_form: Dictionary = {}
var current_state: Dictionary = {}
var collision_body: StaticBody3D
var interaction_area: Area3D
signal creature_interacted(action: String)

func configure(creature: Dictionary, form: Dictionary, pet_state: Dictionary) -> void:
    creature_id = str(creature.get("id", ""))
    stage = int(pet_state.get("stage", form.get("stage", 1)))
    current_form = form.duplicate(true)
    current_state = pet_state.duplicate(true)
    asset_path = str(form.get("asset_manifest", {}).get("path", ""))
    if asset_path.is_empty():
        asset_path = "res://assets/generated/creatures/%s_s%d.glb" % [creature_id, stage]
    _load_or_fallback(creature, form, pet_state)

func _load_or_fallback(creature: Dictionary, form: Dictionary, pet_state: Dictionary) -> void:
    _clear_runtime_children()
    var loaded := false
    if not asset_path.is_empty() and ResourceLoader.exists(asset_path):
        var packed := load(asset_path) as PackedScene
        if packed != null:
            asset_instance = packed.instantiate() as Node3D
            if asset_instance != null:
                asset_instance.name = "SpeciesAsset_%s_S%d" % [creature_id, stage]
                add_child(asset_instance)
                _normalize_asset(asset_instance)
                loaded = true
                _ensure_collision()
                _ensure_interaction_area()
                _ensure_attachment_sockets(form)
                _attach_animation_controller(asset_instance, creature, form)
    if not loaded:
        push_warning("NusaPet: critical creature asset unavailable: %s; using validated fallback." % asset_path)
        fallback_visual = NusaCreatureVisual.new()
        fallback_visual.name = "ValidatedFallback_%s_S%d" % [creature_id, stage]
        add_child(fallback_visual)
        fallback_visual.configure(creature, form, pet_state)
        _ensure_collision()
        _ensure_interaction_area()
        _ensure_attachment_sockets(form)

func _normalize_asset(node: Node3D) -> void:
    var s := 0.72 + stage * 0.08
    node.scale = Vector3.ONE * s
    node.position.y = 0.0

func _attach_animation_controller(root: Node3D, creature: Dictionary, form: Dictionary) -> void:
    animation_controller = NusaCreatureAnimationController.new()
    animation_controller.name = "AnimationController"
    add_child(animation_controller)
    animation_controller.setup(root, {
        "locomotion": str(creature.get("locomotion_profile", ["WALK"])[0]) if creature.get("locomotion_profile", []).size() > 0 else "WALK",
        "animation_profile": form.get("animation_profile", [])
    })

func _ensure_interaction_area() -> void:
    if interaction_area != null and is_instance_valid(interaction_area):
        interaction_area.queue_free()
    interaction_area = Area3D.new()
    interaction_area.name = "CreatureInteractionArea"
    interaction_area.collision_layer = 4
    interaction_area.collision_mask = 1
    interaction_area.input_ray_pickable = true
    var shape := CollisionShape3D.new()
    shape.name = "InteractionShape"
    var sphere := SphereShape3D.new()
    sphere.radius = 1.15
    shape.shape = sphere
    shape.position.y = 0.8
    interaction_area.add_child(shape)
    interaction_area.input_event.connect(_on_interaction_input)
    add_child(interaction_area)

func _on_interaction_input(_camera: Node, event: InputEvent, _position: Vector3, _normal: Vector3, _shape_idx: int) -> void:
    if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
        creature_interacted.emit("tap")
    elif event is InputEventScreenTouch and event.pressed:
        creature_interacted.emit("tap")

func _clear_runtime_children() -> void:
    for child in get_children():
        child.queue_free()
    asset_instance = null
    animation_controller = null
    fallback_visual = null
    interaction_area = null

func _ensure_collision() -> void:
    if collision_body != null and is_instance_valid(collision_body):
        collision_body.queue_free()
    collision_body = StaticBody3D.new()
    collision_body.name = "CreatureCollisionBody"
    collision_body.collision_layer = 2
    collision_body.collision_mask = 0
    var shape := CollisionShape3D.new()
    shape.name = "CreatureCollisionShape"
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.48
    capsule.height = 1.5
    shape.shape = capsule
    shape.position.y = 0.8
    collision_body.add_child(shape)
    add_child(collision_body)

func _ensure_attachment_sockets(form: Dictionary) -> void:
    var slots = form.get("attachment_slots", ["HEAD", "CHEST", "BACK", "FORELIMB", "HINDLIMB", "WING", "TAIL", "HORN", "FIN", "ENERGY_CORE", "ORNAMENT", "AURA", "PARTICLES"])
    for slot in slots:
        var marker := Marker3D.new()
        marker.name = "Socket_%s" % str(slot)
        marker.set_meta("attachment_slot", str(slot))
        add_child(marker)
