class_name NusaAudioManager
extends Node

var players: Dictionary = {}
var enabled := true

func _ready() -> void:
    for bus in ["MASTER","MUSIC","AMBIENT","SFX","CREATURE","UI"]:
        if AudioServer.get_bus_index(bus) < 0: AudioServer.add_bus(); AudioServer.set_bus_name(AudioServer.bus_count-1,bus)
    for bus in ["MUSIC","AMBIENT","SFX","CREATURE","UI"]:
        var p:=AudioStreamPlayer.new(); p.bus=bus; add_child(p); players[bus]=p

func set_enabled(value:bool) -> void:
    enabled=value
    AudioServer.set_bus_mute(AudioServer.get_bus_index("MASTER"),not value)

func set_bus_enabled(bus:String,value:bool)->void:
    var idx:=AudioServer.get_bus_index(bus); if idx>=0: AudioServer.set_bus_mute(idx,not value)

func play_generated_tone(bus:String="UI",frequency:float=440.0,duration:float=.08)->void:
    if not enabled or not players.has(bus): return
    var stream:=AudioStreamGenerator.new(); stream.mix_rate=22050; stream.buffer_length=max(.05,duration+.03)
    var player:AudioStreamPlayer=players[bus]; player.stream=stream; player.play()
    var playback:=player.get_stream_playback() as AudioStreamGeneratorPlayback
    if playback==null: return
    var frames:=int(22050*duration); var phase:=0.0
    for i in range(frames):
        var sample:=sin(phase*TAU)*0.045; playback.push_frame(Vector2(sample,sample)); phase=fmod(phase+frequency/22050.0,1.0)

func identity_for_affinity(affinity:String)->float:
    var h:=abs(hash(affinity)); return 220.0+float(h%440)
