class_name NusaFeatureFlags
extends Node

var flags: Dictionary = {}
var environment := "production"

func _ready() -> void:
    var path := "res://data/system/feature_flags.json"
    if not FileAccess.file_exists(path):
        return
    var f := FileAccess.open(path, FileAccess.READ)
    if f == null:
        return
    var parsed = JSON.parse_string(f.get_as_text())
    if typeof(parsed) == TYPE_DICTIONARY:
        environment = str(parsed.get("environment", "production"))
        flags = parsed.get("flags", {})

func enabled(key: String, default_value: bool = false) -> bool:
    return bool(flags.get(key, default_value))

func production() -> bool:
    return environment.to_lower() == "production"
