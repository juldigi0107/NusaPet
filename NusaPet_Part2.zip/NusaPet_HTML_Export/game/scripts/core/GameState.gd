class_name NusaGameState
extends Node

signal state_changed
signal toast_requested(message: String)
signal save_status_changed(message: String)

const SAVE_DIR := "user://save/"
const SAVE_PATH := SAVE_DIR + "slot_01.json"
const BACKUP_PATH := SAVE_DIR + "slot_01.backup.json"
const SNAPSHOT_PATH := SAVE_DIR + "slot_01.transaction.json"
const VERSION := 9
const CONTENT_VERSION := "2026.09-content-5"
const STAGES := ["EMBRYO", "HATCHLING", "JUVENILE", "MATURE", "PRIME", "LEGEND"]
const AFFINITIES := ["SURYA","RIMBA","SAMUDRA","BADAI","GUNUNG","BULAN","BARA","BATU","ANGIN","HUJAN","PETIR","KABUT","FAJAR","SENJA","NISKALA"]
const PERSONALITIES := ["Playful","Calm","Curious","Brave","Shy","Loyal","Independent","Mischievous","Gentle","Energetic"]
const DURATIONS := [300,900,1800,3600,10800,28800]
const STARTER_POOL := ["real_001","real_026","real_101","mythology_001","mystical_001"]
const RARE_TRAITS := ["SUNMARK","FOREST_FRECKLE","MOON_EYE","TIDAL_GLOW","EMBER_TIP"]
const HABITAT_AFFINITIES := ["RIMBA","GUNUNG","ANGIN","HUJAN","SAMUDRA","KABUT","SENJA","NISKALA","RIMBA"]
var state: Dictionary = {}
var catalog: Dictionary = {}
var lang := "id"
var offline := true
var last_tick: int = 0

func _ready() -> void:
    DirAccess.make_dir_recursive_absolute(SAVE_DIR)
    _load_content()
    if not load_game():
        new_game()
    last_tick = int(Time.get_unix_time_from_system())

func _process(_delta: float) -> void:
    if state.is_empty(): return
    var now := int(Time.get_unix_time_from_system())
    if now - last_tick >= 60:
        advance_time(now - last_tick)
        last_tick = now

func _load_content() -> void:
    catalog.creatures = _read_json("res://data/creatures/creatures.json")
    catalog.forms = _read_json("res://data/evolutions/primary_forms.json")
    catalog.cross = _read_json("res://data/cross-evolutions/cross_paths.json")
    catalog.artifacts = _read_json("res://data/artifacts/pusaka.json")
    catalog.armor = _read_json("res://data/armor-forms/armor_forms.json")
    catalog.dual = _read_json("res://data/artifacts/dual_resonance.json")
    catalog.resonance = _read_json("res://data/resonance/resonance_forms.json")
    catalog.regions = _read_json("res://data/regions/regions.json")
    catalog.habitats = _read_json("res://data/habitats/habitats.json")
    catalog.food = _read_json("res://data/items/food.json")
    catalog.toys = _read_json("res://data/items/toys.json")
    catalog.quests = _read_json("res://data/quests/quests.json")
    catalog.achievements = _read_json("res://data/achievements/achievements.json")
    catalog.localization_id = _read_json("res://data/localization/id/strings.json")
    catalog.localization_en = _read_json("res://data/localization/en/strings.json")

func _read_json(path: String):
    if not FileAccess.file_exists(path): return []
    var f := FileAccess.open(path, FileAccess.READ)
    if f == null: return []
    var parsed = JSON.parse_string(f.get_as_text())
    return parsed if parsed != null else []

func new_game() -> void:
    var now := int(Time.get_unix_time_from_system())
    var starter_id := STARTER_POOL[now % STARTER_POOL.size()]
    var starter: Dictionary = {}
    for candidate in catalog.creatures:
        if str(candidate.get("id","")) == starter_id:
            starter = candidate
            break
    if starter.is_empty():
        starter = catalog.creatures[0]
    state = {
        "version": VERSION, "game_version": "0.24.0", "content_version": CONTENT_VERSION, "schema_version": VERSION,
        "created_at": now, "updated_at": now, "language": "id",
        "player": {"name":"Penjelajah", "rank":"PENJELAJAH", "research":0, "research_level":"DISCOVERED", "research_levels":{starter.id:"DISCOVERED"}, "research_observation_counts":{starter.id:0}, "discoveries":[starter.id], "selected_region":"sumatra", "expeditions":[], "regional_mastery":{}, "knowledge_flags":[]},
        "pet": _new_pet(starter.id),
        "collection": {"species":[starter.id],"forms":[starter.id+"_s1"],"armor":[],"cross_paths":[],"artifacts":[],"regions":["sumatra"],"resonance":[],"dual_resonance":[]},
        "sanctuary": {"companions":[],"active_slot":0,"unlocked_slots":1,"capacity":3},
        "world": {"region":"sumatra","weather":"CLEAR","time_phase":"DAY","habitat":"RAINFOREST"},
        "legacy": {"archive":[],"inheritance":{"nature":0,"mind":0,"knowledge":0,"emblem":""}},
        "quests": {"active":[],"completed":[],"progress":{},"completed_at":{}}, "achievements":[],
        "settings": {"music":true,"sfx":true,"haptic":true,"reduced_motion":false,"text_scale":1.0,"quality":"BALANCED","battery_mode":"BALANCED","notifications":false,"accessible_time_override":true},
        "meta": {"care_streak":0,"total_actions":0,"session_count":1,"offline_progress":0,"deterministic_seed":now,"last_save_operation":"NEW_GAME","pending_operation":"","transaction_id":"","expeditions_completed":0,"rumors":[],"screen_reader":true,"analytics_local":true,"onboarding_complete":false,"observation_count":0,"observation_challenge":{},"daily_action_counts":{}}
    }
    save_game(); state_changed.emit()

func _new_pet(creature_id: String) -> Dictionary:
    return {"creature_id":creature_id,"current_line_id":creature_id,"form_id":creature_id+"_s1","stage":1,"nickname":"Nusa","hatched":false,"birth_time":0,
        "personality":"Curious","base_personality":"Curious","secondary_personality":[],"traits":[],"preferences":{"food":"","toy":"","habitat":"","weather":"CLEAR","time":"DAY"},
        "stats":{"hp":100,"energy":90,"hunger":75,"hydration":80,"happiness":70,"cleanliness":80,"health":90,"discipline":30,"intelligence":20,"affection":20,"stress":10,"curiosity":70,"bond":15,"resonance":0},
        "dna":{"care":20,"strength":10,"mind":15,"bond":15,"adventure":5,"nature":10,"mystic":5,"discipline":5},
        "care_history":{"excellent_days":0,"mistakes":0,"illness":0,"recovery":0,"training":0,"exploration":0,"sleep_quality":0,"feed":0,"play":0,"clean":0,"research":0},
        "memories":[],"pending_evolution_choice":{},"artifact_mastery":{},"artifact_last_use":{},"artifact_fragments":{},"current_armor":"","resonance_form":"","dual_resonance_form":"","perfect_resonance":0,"evolution_signature":{},"discovered_branches":[],"evolution_history":[creature_id+"_s1"],"inventory":[],"discovered_artifacts":[],"status_effects":[],"offline_evolution_pending":false,"habitat_affinity":{"RAINFOREST":0,"MOUNTAIN":0,"SAVANNA":0,"RIVER":0,"OCEAN":0,"MANGROVE":0,"CAVE":0,"VILLAGE":0},"observation_log":[],"screenshot_memory":[],"rare_traits":[]}

func hatch() -> bool:
    if state.pet.hatched: return false
    state.pet.hatched=true; state.pet.birth_time=int(Time.get_unix_time_from_system()); _memory("first_hatch")
    var seed:=_mix_seed(int(state.pet.birth_time))
    state.pet.personality=PERSONALITIES[seed%PERSONALITIES.size()]
    state.pet.base_personality=state.pet.personality
    # Rare traits are deterministic cosmetic variants only; they never alter stats, evolution, or monetization.
    if seed % 100 < 5:
        state.pet.rare_traits=[RARE_TRAITS[seed % RARE_TRAITS.size()]]
    else:
        state.pet.rare_traits=[]
    _delta_dna("care",2); _delta(state.pet,"bond",2); _set_preference_seed(); _touch(); _transactional_save("HATCH")
    _evaluate_progression(); state_changed.emit(); toast_requested.emit(tr("toast_hatch")); return true

func rename_pet(new_name: String) -> bool:
    new_name=new_name.strip_edges(); if new_name.is_empty(): return false
    state.pet.nickname=new_name.left(18); _memory("named_by_player"); _touch(); save_game(); state_changed.emit(); return true

func record_environment_interaction(action: String) -> bool:
    if not state.pet.hatched: return false
    var key:=action.to_upper()
    var allowed=["SWIM","PERCH","HIDE","DIG","CLIMB","REST","SNIFF","OBSERVE","PLAY"]
    if key not in allowed: return false
    var memory_id:="habitat_%s"%key.to_lower()
    _memory(memory_id)
    state.pet.care_history["exploration"] = int(state.pet.care_history.get("exploration",0)) + 1
    _delta_dna("nature",2)
    _delta(state.pet,"happiness",3)
    _reward_mastery_for_meaningful_action("environment_"+key.to_lower(),2)
    _touch(); _transactional_save("ENVIRONMENT_"+key); _evaluate_progression(); state_changed.emit()
    return true

func feed_food(food_id: String) -> bool:
    if not state.pet.hatched or food_id.strip_edges().is_empty(): return false
    if int(state.pet.stats.hunger) >= 98: return false
    var item: Dictionary = {}
    for food in catalog.food:
        if str(food.get("id", "")) == food_id:
            item = food
            break
    if item.is_empty(): return false
    # Explicit GAME FOOD layer. Never convert this into a biological diet claim.
    var c: Dictionary = current_creature()
    state.pet.preferences["food"] = food_id
    state.pet.preferences["food_status"] = "GAME_FOOD_COMPATIBLE" if str(c.get("category", "")) != "REAL" or food_is_diet_compatible(str(c.get("id", "")), food_id) else "GAME_FOOD_UNVERIFIED"
    _delta(state.pet,"hunger",14); _delta(state.pet,"health",2); _delta(state.pet,"happiness",4); _delta(state.pet,"energy",2)
    _delta_dna("care",2); state.pet.care_history.feed+=1
    _memory("first_meal"); _memory("food_"+food_id)
    _touch(); _transactional_save("FEED_FOOD"); _evaluate_progression(); state_changed.emit(); return true

func act(action: String) -> bool:
    if not state.pet.hatched: return false
    var p: Dictionary=state.pet; var ok=true
    match action:
        "feed":
            if p.stats.hunger>=98: ok=false
            else: _delta(p,"hunger",14); _delta(p,"health",2); _delta(p,"happiness",4); _delta(p,"energy",2); _delta_dna("care",2); p.care_history.feed+=1; _memory("first_meal")
        "drink": _delta(p,"hydration",16); _delta(p,"energy",2); _delta_dna("care",1)
        "play": _delta(p,"happiness",10); _delta(p,"energy",-6); _bond_gain("play",4); _delta(p,"stress",-3); _delta_dna("bond",2); _delta_dna("adventure",1); p.care_history.play+=1; _memory("favorite_play")
        "clean": _delta(p,"cleanliness",20); _delta(p,"health",3); _delta(p,"happiness",2); _delta_dna("care",2); p.care_history.clean+=1
        "pet": _delta(p,"affection",5); _bond_gain("pet",3); _delta(p,"stress",-5); _delta_dna("bond",2)
        "train":
            if p.stats.energy<10: ok=false
            else: _delta(p,"discipline",5); _delta(p,"intelligence",3); _delta(p,"energy",-8); _bond_gain("train",2); _delta_dna("discipline",2); _delta_dna("mind",2); p.care_history.training+=1
        "explore": ok=start_expedition(0)
        "heal": _delta(p,"health",18); _delta(p,"stress",-8); p.care_history.recovery+=1; _delta_dna("care",2); _remove_status("SICK")
        "sleep": sleep()
        "learn": research_observation()
        _: ok=false
    if ok and action!="explore":
        state.meta.total_actions+=1
        _update_habitat_affinity(action)
        _reward_mastery_for_meaningful_action(action, 2)
        _clamp_stats(); _update_traits(); _update_personality(); _update_player_rank(); _evaluate_progression(); _touch(); save_game(); state_changed.emit()
    return ok

func sleep() -> bool:
    if not state.pet.hatched: return false
    _delta(state.pet,"energy",35); _delta(state.pet,"stress",-15); _delta(state.pet,"health",5); state.pet.care_history.sleep_quality+=1
    state.world.time_phase="NIGHT"; _memory("rested_together"); _touch(); save_game(); state_changed.emit(); return true

func research_observation(creature_id:String="") -> bool:
    if not state.pet.hatched: return false
    state.player.research+=3; state.pet.care_history.research+=1; _bond_gain("learn",1); _delta_dna("mind",2); _delta(state.pet,"curiosity",3); _memory("field_observation")
    var id:=creature_id if not creature_id.is_empty() else str(state.pet.current_line_id)
    _advance_research_entry(id)
    _update_research_level(); _touch(); save_game(); state_changed.emit(); return true

func _advance_research_entry(creature_id:String)->void:
    if creature_id.is_empty(): return
    if not state.player.has("research_levels"): state.player.research_levels={}
    if not state.player.has("research_observation_counts"): state.player.research_observation_counts={}
    var count:=int(state.player.research_observation_counts.get(creature_id,0))+1
    state.player.research_observation_counts[creature_id]=count
    var level:="MASTERED" if count>=6 else ("RESEARCHED" if count>=3 else ("OBSERVED" if count>=1 else "DISCOVERED"))
    state.player.research_levels[creature_id]=level

func research_level_for(creature_id:String)->String:
    return str(state.player.get("research_levels",{}).get(creature_id,"DISCOVERED"))

func advance_time(seconds: int) -> void:
    if seconds<=0 or state.is_empty(): return
    var capped:int=min(seconds,7*86400); var hours:float=float(capped)/3600.0; var p:Dictionary=state.pet
    if p.hatched:
        _delta(p,"hunger",-int(hours*1.8)); _delta(p,"hydration",-int(hours*2.2)); _delta(p,"energy",int(hours*.7))
        if p.stats.hunger<30: _delta(p,"happiness",-int(hours*.7)); _delta(p,"health",-int(hours*.25))
        if p.stats.cleanliness<25: _delta(p,"health",-int(hours*.15))
        if p.stats.health<35 and "SICK" not in p.status_effects: p.status_effects.append("SICK"); p.care_history.illness+=1
        if p.stats.energy<25: p.care_history.sleep_quality+=int(hours)
    _complete_expeditions()
    if p.hatched:
        care_avg=(int(p.stats.hunger)+int(p.stats.hydration)+int(p.stats.happiness)+int(p.stats.cleanliness)+int(p.stats.health))/5.0
        if care_avg>=80:
            p.care_history.excellent_days+=1
        elif care_avg<35:
            p.care_history.mistakes+=1
    if p.hatched and p.stage<6:
        var offline_need:=100.0+float(p.stage-1)*45.0
        if _evolution_score(p)>=offline_need: p.offline_evolution_pending=true
    state.meta.offline_progress+=capped; _clamp_stats(); _touch(); save_game(); state_changed.emit()

func start_expedition(duration_index: int=0) -> bool:
    if not state.pet.hatched or state.player.expeditions.size()>=2 or state.pet.stats.energy<15: return false
    duration_index=clamp(duration_index,0,DURATIONS.size()-1); var started:=int(Time.get_unix_time_from_system())
    _delta(state.pet,"energy",-15); state.pet.care_history.exploration+=1; _delta_dna("adventure",4)
    state.player.expeditions.append({"started":started,"duration":DURATIONS[duration_index],"region":state.player.selected_region,"seed":_mix_seed(started+duration_index)})
    _memory("first_expedition"); _touch(); save_game(); state_changed.emit(); toast_requested.emit(tr("toast_expedition")); return true

func _complete_expeditions() -> void:
    var now:=int(Time.get_unix_time_from_system()); var done:Array=[]
    for ex in state.player.expeditions:
        if now-int(ex.started)>=int(ex.duration): done.append(ex)
    for ex in done:
        state.player.expeditions.erase(ex); _resolve_expedition(ex)

func _resolve_expedition(ex: Dictionary) -> void:
    var seed:int=int(ex.get("seed",0)); var roll:int=abs(seed)%100; state.player.research+=5; _delta(state.pet,"bond",2); _delta_dna("adventure",2)
    if roll<22:
        for a in catalog.artifacts:
            if a.id in state.pet.discovered_artifacts: continue
            if bool(a.get("secret",false)):
                var fragments:Dictionary=state.pet.artifact_fragments
                var count:=int(fragments.get(str(a.id),0))+1
                fragments[str(a.id)]=count
                state.pet.artifact_fragments=fragments
                if count<int(a.get("fragments_required",5)):
                    _memory("pusaka_fragment_"+str(a.id))
                else:
                    state.pet.discovered_artifacts.append(a.id); state.pet.inventory.append(a.id); state.collection.artifacts.append(a.id); _memory("first_pusaka")
                break
            state.pet.discovered_artifacts.append(a.id); state.pet.inventory.append(a.id); state.collection.artifacts.append(a.id); _memory("first_pusaka"); break
    elif roll<48:
        _discover_next_species()
    elif roll<72:
        state.player.research+=10; state.pet.care_history.research+=1
    else:
        _memory("evolution_hint")
    _update_research_level(); _regional_progress(str(ex.get("region","java")),2); _reward_mastery_for_meaningful_action("exploration",5); _memory("expedition_complete"); state.meta.expeditions_completed=int(state.meta.get("expeditions_completed",0))+1; _evaluate_progression(); toast_requested.emit(tr("toast_expedition_done"))

func _discover_next_species() -> void:
    for c in catalog.creatures:
        if c.id not in state.collection.species:
            state.collection.species.append(c.id); state.player.discoveries.append(c.id)
            state.player.research_levels[c.id]="DISCOVERED"
            state.player.research_observation_counts[c.id]=0
            _memory("discovered_"+c.id); return

func evolve() -> bool:
    var p:Dictionary=state.pet
    if not p.hatched or p.stage>=6: return false
    var next_stage:int=p.stage+1
    var eligible:Array=[]
    if p.stage>=4:
        eligible=_eligible_cross(p.form_id,p.stage)
    var score:=_evolution_score(p); var need:=100.0+float(p.stage-1)*45.0
    if score<need: toast_requested.emit("Perjalanan belum matang untuk evolution."); return false
    if RecoveryManager: RecoveryManager.begin("EVOLUTION")
    _snapshot_before_critical("EVOLUTION")
    var chosen_line:=str(p.current_line_id if p.has("current_line_id") else p.creature_id)
    var chosen:String=chosen_line+"_s"+str(next_stage)
    if p.stage>=4 and not eligible.is_empty():
        var ranked:Array=_rank_cross_candidates(eligible,p)
        var discovered_ranked:Array=[]
        for candidate in ranked:
            if _branch_discovered(candidate.edge):
                discovered_ranked.append(candidate)
        # A close pair becomes a real player-facing Instinct Choice instead of an arbitrary auto-pick.
        if discovered_ranked.size()>=2 and float(discovered_ranked[0].score-discovered_ranked[1].score)<=1.5:
            p.pending_evolution_choice={
                "stage":next_stage,
                "options":[_choice_payload(discovered_ranked[0]),_choice_payload(discovered_ranked[1])],
                "created_at":int(Time.get_unix_time_from_system())
            }
            state.meta.last_save_operation="EVOLUTION_CHOICE_PENDING"
            _touch(); save_game(); state_changed.emit(); toast_requested.emit("Dua jalur evolusi terasa sama kuat. Pilih INSTINCT-mu.")
            return false
        var best:Dictionary=_select_branch(eligible,p)
        if not best.is_empty() and _branch_discovered(best):
            var target_form:=str(best.target)
            chosen_line=target_form.rsplit("_s",1)[0]
            chosen=chosen_line+"_s"+str(next_stage)
            p.current_line_id=chosen_line
            p.discovered_branches.append(chosen_line)
            if best.id not in state.collection.cross_paths: state.collection.cross_paths.append(best.id)
    p.stage=next_stage; p.form_id=chosen; p.offline_evolution_pending=false; p.evolution_history.append(chosen); if chosen not in state.collection.forms: state.collection.forms.append(chosen)
    _delta_dna("care",3); _delta(p,"health",20); _delta(p,"happiness",15); _memory("evolution_"+str(next_stage)); _update_traits(); _record_evolution_signature(); _evaluate_progression(); _touch(); _transactional_save("EVOLUTION")
    if RecoveryManager: RecoveryManager.complete()
    state_changed.emit(); toast_requested.emit(tr("toast_evolution")); return true

func _evolution_score(p:Dictionary)->float:
    var score:=0.0
    score += float(p.dna.care)*1.15 + float(p.dna.bond)*1.25 + float(p.dna.adventure)*1.0
    score += float(p.dna.mind)*1.05 + float(p.dna.discipline)*0.9 + float(p.dna.nature)*0.85
    score += float(p.dna.strength)*0.8 + float(p.dna.mystic)*0.7
    score += float(p.stats.happiness+p.stats.health+p.stats.cleanliness)*0.15
    score += float(state.player.research)*0.05
    score += float(p.evolution_history.size()-1)*3.0
    score += float(p.care_history.sleep_quality)*0.15
    return score

func _eligible_cross(source:String, target_stage:int)->Array:
    var out:Array=[]
    for e in catalog.cross:
        if str(e.get("source"))==source and int(e.get("minimum_stage",4))<=target_stage:
            if _cross_requirements_met(e): out.append(e)
    return out

func _cross_requirements_met(e:Dictionary)->bool:
    var r:Dictionary=e.get("requirements",{})
    var p:Dictionary=state.pet
    if int(r.get("training",0))>int(p.care_history.training): return false
    if int(r.get("bond",0))>int(p.stats.bond): return false
    if int(r.get("adventure",0))>int(p.care_history.exploration): return false
    if int(r.get("research",0))>int(state.player.research): return false
    var req_aff:=str(r.get("habitat_affinity","ANY"))
    if req_aff!="ANY" and _habitat_affinity_value(req_aff)<int(r.get("habitat_affinity_min",1)): return false
    var req_personality:=str(r.get("personality","ANY"))
    if req_personality!="ANY" and p.personality!=req_personality: return false
    var req_region:=str(r.get("region","ANY")).to_lower()
    if req_region!="any" and str(state.world.get("region",state.player.selected_region)).to_lower()!=req_region: return false
    var req_weather:=str(r.get("weather","ANY"))
    if req_weather!="ANY" and str(state.world.get("weather","CLEAR"))!=req_weather:
        if not bool(state.settings.get("accessible_time_override",true)) or int(state.player.research)<20: return false
    var req_time:=str(r.get("time","ANY"))
    if req_time!="ANY" and str(state.world.get("time_phase","DAY"))!=req_time:
        if not bool(state.settings.get("accessible_time_override",true)): return false
    var aid_aff:=str(r.get("pusaka_affinity","ANY"))
    if aid_aff!="ANY" and not _has_mastery_affinity(aid_aff,int(r.get("mastery",0))): return false
    return true

func _rank_cross_candidates(edges:Array,p:Dictionary)->Array:
    var ranked:Array=[]
    for e in edges:
        ranked.append({"edge":e,"score":_cross_branch_score(e,p)})
    ranked.sort_custom(func(a,b): return float(a.score)>float(b.score))
    return ranked

func _cross_branch_score(e:Dictionary,p:Dictionary)->float:
    var r:Dictionary=e.get("requirements",{})
    var score:=float(e.get("priority",1))*2.0
    score += _condition_margin(int(p.care_history.training),int(r.get("training",0)))*0.5
    score += _condition_margin(int(p.stats.bond),int(r.get("bond",0)))*0.7
    score += _condition_margin(int(p.care_history.exploration),int(r.get("adventure",0)))*0.8
    score += _condition_margin(int(state.player.research),int(r.get("research",0)))*0.4
    score += _personality_match_score(p,r)
    score += _habitat_match_score(r)
    score += _pusaka_history_score(r)
    return score

func _choice_payload(candidate:Dictionary)->Dictionary:
    var e:Dictionary=candidate.edge
    var r:Dictionary=e.get("requirements",{})
    var target:=str(e.get("target",""))
    var line:=target.rsplit("_s",1)[0]
    var clue:=str(e.get("choice_clue_id",e.get("rationale","Sebuah jalur baru memanggil.")))
    return {"edge_id":str(e.get("id","")),"target_line":line,"target_stage":int(str(target).get_slice("_s",1)),"clue":clue,"hidden":false}

func evolution_choice_options()->Array:
    return state.pet.get("pending_evolution_choice",{}).get("options",[]).duplicate(true)

func choose_evolution_branch(edge_id:String)->bool:
    var p:Dictionary=state.pet
    var pending:Dictionary=p.get("pending_evolution_choice",{})
    var options:Array=pending.get("options",[])
    var selected:Dictionary={}
    for option in options:
        if str(option.get("edge_id",""))==edge_id:
            selected=option
            break
    if selected.is_empty():
        return false
    var next_stage:=int(pending.get("stage",p.stage+1))
    if next_stage!=p.stage+1:
        return false
    var edge:Dictionary={}
    for e in catalog.cross:
        if str(e.get("id",""))==edge_id:
            edge=e
            break
    if edge.is_empty() or not _cross_requirements_met(edge) or not _branch_discovered(edge):
        return false
    _snapshot_before_critical("EVOLUTION_CHOICE")
    var target:=str(edge.get("target",""))
    var chosen_line:=target.rsplit("_s",1)[0]
    var chosen:=chosen_line+"_s"+str(next_stage)
    p.current_line_id=chosen_line
    p.stage=next_stage
    p.form_id=chosen
    p.pending_evolution_choice={}
    p.offline_evolution_pending=false
    if chosen_line not in p.discovered_branches: p.discovered_branches.append(chosen_line)
    if edge_id not in state.collection.cross_paths: state.collection.cross_paths.append(edge_id)
    p.evolution_history.append(chosen)
    if chosen not in state.collection.forms: state.collection.forms.append(chosen)
    _delta_dna("care",3); _delta(p,"health",20); _delta(p,"happiness",15)
    _memory("evolution_%d"%next_stage); _memory("instinct_choice_%s"%edge_id)
    _update_traits(); _record_evolution_signature(); _evaluate_progression(); _touch(); _transactional_save("EVOLUTION_CHOICE")
    state_changed.emit(); toast_requested.emit(tr("toast_evolution"))
    return true

func _select_branch(edges:Array,p:Dictionary)->Dictionary:
    var best:Dictionary={}; var best_score:float=-INF
    for e in edges:
        var r:Dictionary=e.get("requirements",{})
        var score:=float(e.get("priority",1))*2.0
        score += _condition_margin(int(p.care_history.training),int(r.get("training",0)))*0.5
        score += _condition_margin(int(p.stats.bond),int(r.get("bond",0)))*0.7
        score += _condition_margin(int(p.care_history.exploration),int(r.get("adventure",0)))*0.8
        score += _personality_match_score(p,r)
        score += _habitat_match_score(r)
        score += _pusaka_history_score(r)
        if score>best_score: best=e; best_score=score
    return best

func _condition_margin(actual:int,required:int)->float:
    if required<=0: return 0.0
    return clamp(float(actual-required)/float(required),0.0,2.0)

func _personality_match_score(p:Dictionary,r:Dictionary)->float:
    var req:=str(r.get("personality","ANY"))
    return 4.0 if req==str(p.personality) else (0.0 if req=="ANY" else -2.0)

func _habitat_match_score(r:Dictionary)->float:
    var req:=str(r.get("habitat_affinity","ANY"))
    return 5.0 if req=="ANY" else float(_habitat_affinity_value(req))*0.08

func _pusaka_history_score(r:Dictionary)->float:
    var req:=str(r.get("pusaka_affinity","ANY"))
    if req=="ANY": return 0.0
    return 3.0 if _has_mastery_affinity(req,1) else 0.0

func _has_mastery_affinity(affinity:String,min_mastery:int)->bool:
    for a in catalog.artifacts:
        if str(a.get("affinity",""))==affinity:
            if int(state.pet.artifact_mastery.get(str(a.get("id","")),0))>=min_mastery: return true
    return false

func _branch_discovered(e:Dictionary)->bool:
    var d:=str(e.get("discovery_condition","exploration_or_research"))
    if d=="exploration_or_research": return state.pet.care_history.exploration>0 or state.player.research>=20
    if d=="field_observation": return "field_observation" in state.pet.memories
    return true

func transform(artifact_id:String)->bool:
    var p:Dictionary=state.pet
    if not p.hatched or p.stage<3 or artifact_id not in p.inventory: return false
    var a:Dictionary=_artifact(artifact_id); if a.is_empty(): return false
    var affinity:=str(a.get("affinity","")); if affinity not in compatible_affinities(str(p.get("current_line_id",p.creature_id))): return false
    var now:=int(Time.get_unix_time_from_system()); p.artifact_last_use[artifact_id]=now
    var candidates:Array=[]
    for ar in catalog.armor:
        if str(ar.get("base_creature"))==str(p.get("current_line_id",p.creature_id)) and int(ar.get("minimum_stage",3))<=p.stage and str(ar.get("artifact_affinity"))==affinity: candidates.append(ar.id)
    if candidates.is_empty(): return false
    if RecoveryManager: RecoveryManager.begin("ARMOR")
    _snapshot_before_critical("ARMOR"); p.current_armor=candidates[0]; _delta(p,"resonance",min(12,8+int(p.artifact_mastery[artifact_id]/25))); _memory("armor_"+affinity)
    if p.current_armor not in state.collection.armor: state.collection.armor.append(p.current_armor)
    _evaluate_progression()
    _touch(); _transactional_save("ARMOR"); if RecoveryManager: RecoveryManager.complete(); AudioManager.play_generated_tone("SFX",AudioManager.identity_for_affinity(affinity),.18); state_changed.emit(); toast_requested.emit(tr("toast_armor")); return true

func revert_armor() -> void:
    state.pet.current_armor=""; state.pet.resonance_form=""; state.pet.dual_resonance_form=""; _touch(); save_game(); state_changed.emit(); toast_requested.emit(tr("toast_normal"))

func check_resonance()->bool:
    var p:Dictionary=state.pet
    if p.current_armor.is_empty(): return false
    var affinity:=armor_affinity(p.current_armor); var aid:=_armor_artifact_affinity(affinity); var mastery:=int(p.artifact_mastery.get(aid,0))
    if p.stage<4 or mastery<80 or int(p.stats.bond)<85 or not _has_research_discovery(): return false
    var compatibility_weight:=_compatibility_weight(str(p.get("current_line_id",p.get("creature_id",""))),affinity)
    if compatibility_weight < 0.8: return false
    p.resonance_form="resonance_%s_%s"%[str(p.get("current_line_id",p.creature_id)),affinity]; _delta(p,"resonance",20); _memory("resonance_awakened")
    if p.resonance_form not in state.collection.resonance: state.collection.resonance.append(p.resonance_form)
    _evaluate_progression()
    _touch(); _transactional_save("RESONANCE"); AudioManager.play_generated_tone("CREATURE",AudioManager.identity_for_affinity(affinity)*1.5,.28); state_changed.emit(); toast_requested.emit(tr("toast_resonance")); return true

func try_dual_resonance(a1:String,a2:String)->bool:
    if state.pet.stage<5: return false
    var mastery1:=int(state.pet.artifact_mastery.get(a1,0)); var mastery2:=int(state.pet.artifact_mastery.get(a2,0)); if mastery1<85 or mastery2<85 or state.pet.stats.bond<88: return false
    var af1:=str(_artifact(a1).get("affinity","")); var af2:=str(_artifact(a2).get("affinity",""))
    for d in catalog.dual:
        var aa:Array=d.get("affinities",[]); if af1 in aa and af2 in aa:
            state.pet.dual_resonance_form=str(d.id); if d.id not in state.collection.dual_resonance: state.collection.dual_resonance.append(d.id); _evaluate_progression(); _touch(); _transactional_save("DUAL_RESONANCE"); state_changed.emit(); return true
    return false

func compatible_affinities(creature_id:String)->Array:
    var creature:Dictionary={}
    for c in catalog.creatures:
        if str(c.get("id",""))==creature_id:
            creature=c
            break
    var explicit=creature.get("pusaka_compatibility",{})
    if typeof(explicit)==TYPE_DICTIONARY and not explicit.is_empty():
        var weighted:Array=[]
        for key in explicit.keys():
            weighted.append({"id":str(key),"weight":float(explicit[key])})
        weighted.sort_custom(func(a,b): return a.weight>b.weight)
        return [str(x.id) for x in weighted.slice(0,min(5,weighted.size())) if float(x.weight)>=0.5]
    # Safe data-driven fallback until researched compatibility metadata is published.
    var archetype:=str(creature.get("archetype","OTHER"))
    var map={
        "QUADRUPED":["RIMBA","BATU","SURYA"],
        "BIPED":["SURYA","SENJA","BATU"],
        "AVIAN":["ANGIN","BADAI","FAJAR"],
        "BIRD":["ANGIN","BADAI","FAJAR"],
        "SERPENTINE":["BATU","BARA","KABUT"],
        "REPTILE":["BATU","BARA","RIMBA"],
        "AQUATIC":["SAMUDRA","HUJAN","BULAN"],
        "FISH":["SAMUDRA","HUJAN","BULAN"],
        "AMPHIBIOUS":["HUJAN","RIMBA","KABUT"],
        "AMPHIBIAN":["HUJAN","RIMBA","KABUT"],
        "ARTHROPOD":["RIMBA","KABUT","PETIR"],
        "MOLLUSK":["SAMUDRA","BATU","KABUT"],
        "WINGED":["ANGIN","BADAI","PETIR"],
        "HORNED":["GUNUNG","BATU","SURYA"],
        "PRIMATE":["RIMBA","SURYA","SENJA"],
        "ETHEREAL":["NISKALA","BULAN","KABUT"],
        "HUMANOID_FOLKLORE":["NISKALA","SENJA","FAJAR"],
        "OTHER":["RIMBA","SURYA","NISKALA"]
    }
    return map.get(archetype,map["OTHER"])

func armor_affinity(armor_id:String)->String:
    for ar in catalog.armor:
        if str(ar.id)==armor_id: return str(ar.artifact_affinity)
    return ""

func _armor_artifact_affinity(affinity:String)->String:
    for a in catalog.artifacts:
        if str(a.get("affinity"))==affinity: return str(a.id)
    return ""

func _has_research_discovery()->bool: return int(state.player.research)>=30 or "field_observation" in state.pet.memories
func _selected_habitat_affinity_match()->int: return 1

func _compatibility_weight(creature_id:String, affinity:String)->float:
    for c in catalog.creatures:
        if str(c.get("id",""))==creature_id:
            var weights=c.get("pusaka_compatibility",{})
            if typeof(weights)==TYPE_DICTIONARY and weights.has(affinity): return float(weights[affinity])
    return 1.0 if affinity in compatible_affinities(creature_id) else 0.0

func _update_habitat_affinity(action:String)->void:
    var p:Dictionary=state.pet
    var region:=str(state.world.get("region",state.player.selected_region)).to_lower()
    var habitat_by_region={"sumatra":["RAINFOREST","MANGROVE"],"java":["VILLAGE","MOUNTAIN"],"kalimantan":["RAINFOREST","RIVER"],"sulawesi":["RAINFOREST","SAVANNA"],"bali":["VILLAGE","MOUNTAIN"],"nusa_tenggara":["SAVANNA","OCEAN"],"maluku":["OCEAN","MANGROVE"],"papua":["RAINFOREST","MOUNTAIN"],"indonesian_seas":["OCEAN","RIVER"]}
    var targets:Array=habitat_by_region.get(region,["RAINFOREST"] )
    for h in targets: p.habitat_affinity[h]=min(100,int(p.habitat_affinity.get(h,0))+1)
    if action=="explore":
        for h in targets: p.habitat_affinity[h]=min(100,int(p.habitat_affinity.get(h,0))+2)

func _habitat_affinity_value(key:String)->int:
    return int(state.pet.habitat_affinity.get(key.to_upper(),0))

func _bond_gain(activity:String, amount:int=1)->void:
    var day:=Time.get_date_string_from_system()
    var key:="bond:"+day+":"+activity
    var counts:Dictionary=state.meta.get("daily_action_counts",{})
    var n:=int(counts.get(key,0))
    counts[key]=n+1
    state.meta.daily_action_counts=counts
    # Bond is intentionally non-spammable: first three meaningful interactions/day give full value, then diminishing value.
    var multiplier:=1.0 if n<3 else (0.35 if n<6 else 0.0)
    if multiplier>0.0:
        _delta(state.pet,"bond",max(1,int(round(float(amount)*multiplier))))

func _reward_mastery_for_meaningful_action(activity:String, amount:int=1)->void:
    var p:Dictionary=state.pet
    if p.current_armor.is_empty(): return
    var aid:=_armor_artifact_affinity(armor_affinity(p.current_armor))
    if aid.is_empty(): return
    var day:=Time.get_date_string_from_system()
    var key:=day+":"+activity
    var counts:Dictionary=state.meta.get("daily_action_counts",{})
    var n:=int(counts.get(key,0))
    counts[key]=n+1
    state.meta.daily_action_counts=counts
    # Diminishing returns: first two meaningful instances/day grant mastery.
    if n<2:
        p.artifact_mastery[aid]=min(100,int(p.artifact_mastery.get(aid,0))+amount)

func begin_observation_challenge(creature_id:String="") -> Dictionary:
    if not state.pet.hatched: return {}
    var entry_id:=creature_id if not creature_id.is_empty() else str(state.pet.current_line_id)
    var clues:Array=["TRACKS","CALL","HABITAT","SILHOUETTE"]
    var seed:=_mix_seed(int(state.pet.birth_time)+int(state.meta.get("observation_count",0))+hash(entry_id))
    var answer:=str(clues[abs(seed)%clues.size()])
    var options:=clues.duplicate()
    options.shuffle()
    state.meta.observation_challenge={"creature_id":entry_id,"answer":answer,"options":options,"started_at":int(Time.get_unix_time_from_system())}
    return state.meta.observation_challenge.duplicate(true)

func submit_observation_challenge(answer:String) -> bool:
    var challenge:Dictionary=state.meta.get("observation_challenge",{})
    if challenge.is_empty() or str(answer) not in challenge.get("options",[]): return false
    var correct:=str(answer)==str(challenge.get("answer",""))
    state.meta.observation_challenge={}
    if not correct:
        _memory("observation_miss")
        _touch(); save_game(); state_changed.emit(); return false
    state.meta.observation_count=int(state.meta.get("observation_count",0))+1
    var clue:=str(answer)
    if clue not in state.pet.observation_log: state.pet.observation_log.append(clue)
    state.player.research+=4
    var entry_id:=str(challenge.get("creature_id",state.pet.current_line_id))
    _advance_research_entry(entry_id)
    _delta(state.pet,"curiosity",3); _delta_dna("mind",2)
    _memory("observation_"+clue); _memory("field_observation_completed")
    _update_research_level(); _evaluate_progression(); _touch(); save_game(); state_changed.emit()
    return true

func observe_field_clue(creature_id:String="") -> bool:
    if not state.pet.hatched: return false
    state.meta.observation_count=int(state.meta.get("observation_count",0))+1
    var clues=["TRACKS","CALL","HABITAT","SILHOUETTE"]
    var clue:=clues[(state.meta.observation_count+int(state.pet.birth_time))%clues.size()]
    if clue not in state.pet.observation_log: state.pet.observation_log.append(clue)
    state.player.research+=2
    var entry_id:=creature_id if not creature_id.is_empty() else str(state.pet.current_line_id)
    _advance_research_entry(entry_id)
    _delta(state.pet,"curiosity",2); _delta_dna("mind",1)
    _memory("observation_"+clue)
    _update_research_level(); _evaluate_progression(); _touch(); save_game(); state_changed.emit()
    return true

func save_screenshot_memory() -> String:
    var image:=get_viewport().get_texture().get_image()
    if image.is_empty(): return ""
    var dir:=DirAccess.open("user://save/")
    if dir==null: DirAccess.make_dir_recursive_absolute("user://save/")
    var path:="user://save/memory_%d.png"%int(Time.get_unix_time_from_system())
    if image.save_png(path)!=OK: return ""
    if path not in state.pet.screenshot_memory: state.pet.screenshot_memory.append(path)
    _touch(); save_game()
    return path

func affinity_color(affinity:String)->Color:
    var colors={"SURYA":"f2c66d","RIMBA":"5e9b63","SAMUDRA":"4c9db5","BADAI":"788db8","GUNUNG":"8b7965","BULAN":"9b91c8","BARA":"c95f3e","BATU":"7f8079","ANGIN":"a7c7d1","HUJAN":"6f9fc0","PETIR":"e0c84b","KABUT":"a6b5ad","FAJAR":"e4a76f","SENJA":"b6787f","NISKALA":"9c7bd1"}
    return Color(str(colors.get(affinity,"d09b4a")))

func current_creature()->Dictionary:
    var line_id:=str(state.pet.get("current_line_id",state.pet.get("creature_id","")))
    for c in catalog.creatures:
        if str(c.get("id",""))==line_id: return c
    for c in catalog.creatures:
        if str(c.get("id",""))==str(state.pet.get("creature_id","")): return c
    return catalog.creatures[0] if not catalog.creatures.is_empty() else {}
func form_record(form_id:String)->Dictionary:
    for f in catalog.forms:
        if f.id==form_id: return f
    return {}
func encyclopedia_entry(creature_id:String)->Dictionary:
    for c in catalog.creatures:
        if c.id==creature_id: return c
    return {}

func scientific_name_is_valid(value:String)->bool:
    var parts:=value.strip_edges().split(" ",false)
    if parts.size()!=2: return false
    return parts[0].length()>0 and parts[0][0]==parts[0][0].to_upper() and parts[1].length()>0 and parts[1][0]==parts[1][0].to_lower()

func source_metadata(creature_id:String)->Array:
    var c:=encyclopedia_entry(creature_id)
    var rr:Dictionary=c.get("research_record",{})
    var refs:Array=rr.get("references",c.get("references",[]))
    var out:Array=[]
    for r in refs:
        out.append({"source":str(r.get("source","")),"url":str(r.get("url","")),"purpose":str(r.get("purpose","")),"year":str(r.get("year",rr.get("source_date","")))})
    return out

func set_language(value:String)->void:
    if value not in ["id","en"]: return
    lang=value; state.language=value; _touch(); save_game(); state_changed.emit()
func tr(key:String)->String:
    var pack=catalog.localization_id if lang=="id" else catalog.localization_en
    return str(pack.get(key,key)) if typeof(pack)==TYPE_DICTIONARY else key

func _compute_checksum(payload:Dictionary)->String:
    var copy:Dictionary=payload.duplicate(true)
    copy.erase("checksum")
    var ctx:=HashingContext.new()
    if ctx.start(HashingContext.HASH_SHA256)!=OK: return ""
    ctx.update(JSON.stringify(copy).to_utf8_buffer())
    return ctx.finish().hex_encode()

func _verify_checksum(payload:Dictionary)->bool:
    var expected:=str(payload.get("checksum",""))
    if expected.is_empty(): return true
    return expected==_compute_checksum(payload)

func save_game()->bool:
    if state.is_empty(): return false
    state.updated_at=int(Time.get_unix_time_from_system()); state.version=VERSION; state.game_version="0.24.0"; state.content_version=CONTENT_VERSION; state.schema_version=VERSION; state.language=lang
    state.checksum=""
    state.checksum=_compute_checksum(state)
    var json:=JSON.stringify(state,"  "); var tmp:=SAVE_PATH+".tmp"; var f:=FileAccess.open(tmp,FileAccess.WRITE); if f==null: return false
    f.store_string(json); f.close()
    if FileAccess.file_exists(SAVE_PATH):
        var old:=FileAccess.get_file_as_string(SAVE_PATH); var b:=FileAccess.open(BACKUP_PATH,FileAccess.WRITE); if b!=null: b.store_string(old); b.close()
    var err:=DirAccess.rename_absolute(tmp,SAVE_PATH); if err!=OK: return false
    save_status_changed.emit(tr("save_ok")); return true

func _transactional_save(operation:String)->bool:
    state.meta.last_save_operation=operation
    state.meta.pending_operation=operation
    state.meta.transaction_id=str(_mix_seed(int(Time.get_unix_time_from_system())))
    var snap:=FileAccess.open(SNAPSHOT_PATH,FileAccess.WRITE)
    if snap!=null:
        snap.store_string(JSON.stringify(state))
        snap.close()
    var ok:=save_game()
    if not ok: return false
    state.meta.pending_operation=""
    return save_game()
func _snapshot_before_critical(operation:String)->void:
    state.meta.pending_operation=operation; var snap:=FileAccess.open(SNAPSHOT_PATH,FileAccess.WRITE); if snap!=null: snap.store_string(JSON.stringify(state)); snap.close()

func export_save(path: String) -> bool:
    if state.is_empty(): return false
    var payload:Dictionary=state.duplicate(true)
    payload["exported_at"]=int(Time.get_unix_time_from_system())
    payload["export_format"]="NUSAPET_SAVE_V1"
    payload["export_checksum"]=_compute_checksum(payload)
    var f:=FileAccess.open(path,FileAccess.WRITE); if f==null: return false
    f.store_string(JSON.stringify(payload,"  ")); f.close(); return true

func import_save(path: String) -> bool:
    if not FileAccess.file_exists(path): return false
    var parsed=JSON.parse_string(FileAccess.get_file_as_string(path))
    if typeof(parsed)!=TYPE_DICTIONARY or str(parsed.get("export_format",""))!="NUSAPET_SAVE_V1": return false
    var export_checksum:=str(parsed.get("export_checksum",""))
    var export_copy:Dictionary=parsed.duplicate(true); export_copy.erase("export_checksum")
    if export_checksum.is_empty() or export_checksum!=_compute_checksum(export_copy): return false
    var candidate:Dictionary=_migrate(parsed)
    if not _validate_save_candidate(candidate): return false
    _snapshot_before_critical("IMPORT")
    state=candidate; lang=str(state.get("language","id")); _touch(); var ok:=save_game(); if ok: state_changed.emit()
    return ok

func _validate_save_candidate(candidate:Dictionary)->bool:
    if not candidate.has("pet") or not candidate.has("player") or not candidate.has("collection"): return false
    if str(candidate.pet.get("creature_id",""))=="": return false
    if int(candidate.pet.get("stage",0))<1 or int(candidate.pet.get("stage",0))>6: return false
    if not candidate.pet.has("stats") or not candidate.pet.has("dna"): return false
    return true

func load_game()->bool:
    if not FileAccess.file_exists(SAVE_PATH): return _recover_transaction()
    var parsed=JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
    if typeof(parsed)!=TYPE_DICTIONARY or not _verify_checksum(parsed):
        return _recover_transaction()
    state=_migrate(parsed)
    lang=str(state.get("language","id"))
    if str(state.meta.get("pending_operation",""))!="" and FileAccess.file_exists(SNAPSHOT_PATH):
        return _recover_transaction()
    state.meta.session_count=int(state.meta.get("session_count",0))+1
    _apply_offline_resume()
    save_game()
    return true

func _recover_transaction()->bool:
    if FileAccess.file_exists(SNAPSHOT_PATH):
        var snap=JSON.parse_string(FileAccess.get_file_as_string(SNAPSHOT_PATH))
        if typeof(snap)==TYPE_DICTIONARY:
            state=_migrate(snap)
            state.meta.pending_operation=""
            state.meta.last_save_operation="RECOVERED_TRANSACTION"
            lang=str(state.get("language","id"))
            if save_game():
                save_status_changed.emit(tr("save_recovered"))
                return true
    return _recover_backup()
func _recover_backup()->bool:
    if not FileAccess.file_exists(BACKUP_PATH): return false
    var parsed=JSON.parse_string(FileAccess.get_file_as_string(BACKUP_PATH)); if typeof(parsed)!=TYPE_DICTIONARY or not _verify_checksum(parsed): return false
    state=_migrate(parsed); lang=str(state.get("language","id")); save_status_changed.emit(tr("save_recovered")); return true
func _migrate(old:Dictionary)->Dictionary:
    var s:Dictionary=old.duplicate(true); var base:Dictionary=_new_pet(str(s.get("pet",{}).get("creature_id",catalog.creatures[0].id)))
    if not s.has("player"): s.player={"name":"Penjelajah","research":0,"research_levels":{},"discoveries":[],"selected_region":"sumatra","expeditions":[]}
    elif not s.player.has("research_levels"): s.player.research_levels={}
    if not s.player.has("research_observation_counts"): s.player.research_observation_counts={}
    if not s.has("pet"): s.pet=base
    for k in base.keys(): if not s.pet.has(k): s.pet[k]=base[k]
    if not s.pet.has("offline_evolution_pending"): s.pet.offline_evolution_pending=false
    if not s.pet.has("pending_evolution_choice"): s.pet.pending_evolution_choice={}
    if not s.pet.has("base_personality"): s.pet.base_personality=str(s.pet.get("personality","Curious"))
    if not s.pet.has("secondary_personality"): s.pet.secondary_personality=[]
    var default_habitats={"RAINFOREST":0,"MOUNTAIN":0,"SAVANNA":0,"RIVER":0,"OCEAN":0,"MANGROVE":0,"CAVE":0,"VILLAGE":0}
    if not s.pet.has("habitat_affinity"): s.pet.habitat_affinity=default_habitats
    else:
        for hk in default_habitats.keys():
            if not s.pet.habitat_affinity.has(hk): s.pet.habitat_affinity[hk]=0
    if not s.pet.has("current_line_id"): s.pet.current_line_id=str(s.pet.get("creature_id",catalog.creatures[0].id))
    if not s.has("collection"): s.collection={"species":[],"forms":[],"armor":[],"cross_paths":[],"artifacts":[],"regions":[],"resonance":[],"dual_resonance":[]}
    for k in ["resonance","dual_resonance"]: if not s.collection.has(k): s.collection[k]=[]
    if not s.has("world"): s.world={"region":str(s.player.get("selected_region","sumatra")),"weather":"CLEAR","time_phase":"DAY","habitat":"RAINFOREST"}
    else:
        if not s.world.has("region"): s.world.region=str(s.player.get("selected_region","sumatra"))
        if not s.world.has("weather"): s.world.weather="CLEAR"
        if not s.world.has("time_phase"): s.world.time_phase="DAY"
        if not s.world.has("habitat"): s.world.habitat="RAINFOREST"
    if not s.has("legacy"): s.legacy={"archive":[],"inheritance":{"nature":0,"mind":0,"knowledge":0,"emblem":""}}
    if not s.has("sanctuary"): s.sanctuary={"companions":[],"active_slot":0,"unlocked_slots":1,"capacity":3}
    else:
        s.sanctuary["capacity"]=int(s.sanctuary.get("capacity",3))
    if not s.has("quests"): s.quests={"active":[],"completed":[],"progress":{},"completed_at":{}}
    else: s.quests["completed_at"]=s.quests.get("completed_at",{})
    if not s.has("achievements"): s.achievements=[]
    if not s.has("settings"): s.settings={"music":true,"sfx":true,"haptic":true,"reduced_motion":false,"text_scale":1.0,"quality":"BALANCED","battery_mode":"BALANCED","notifications":false,"accessible_time_override":true}
    if not s.has("meta"): s.meta={"care_streak":0,"total_actions":0,"session_count":0,"offline_progress":0,"deterministic_seed":int(Time.get_unix_time_from_system()),"last_save_operation":"","pending_operation":"","transaction_id":"","expeditions_completed":0,"rumors":[],"screen_reader":true,"analytics_local":true,"onboarding_complete":false,"observation_count":0,"observation_challenge":{},"daily_action_counts":{}}
    else:
        for k in ["last_save_operation","pending_operation","transaction_id","expeditions_completed","rumors","screen_reader","analytics_local","onboarding_complete","observation_count","observation_challenge","daily_action_counts"]:
            if not s.meta.has(k): s.meta[k]=0 if k=="expeditions_completed" else ([] if k=="rumors" else ({} if k=="daily_action_counts" else (true if k in ["screen_reader","analytics_local","onboarding_complete"] else (0 if k=="observation_count" else ({} if k=="observation_challenge" else "")))))
    s.version=VERSION; s.schema_version=VERSION; s.content_version=CONTENT_VERSION; return s

func _apply_offline_resume()->void:
    var last:=int(state.get("updated_at",int(Time.get_unix_time_from_system()))); var now:=int(Time.get_unix_time_from_system()); var gap:=clamp(now-last,0,7*86400)
    if gap>60 and state.pet.hatched: advance_time(gap)
func _touch()->void: state.updated_at=int(Time.get_unix_time_from_system())
func _delta(p:Dictionary,k:String,v:int)->void: p.stats[k]=clamp(int(p.stats.get(k,0))+v,0,100)
func _delta_dna(k:String,v:int)->void: state.pet.dna[k]=clamp(int(state.pet.dna.get(k,0))+v,0,100)
func _clamp_stats()->void:
    for k in state.pet.stats.keys(): state.pet.stats[k]=clamp(int(state.pet.stats[k]),0,100)
func _memory(m:String)->void:
    if m not in state.pet.memories: state.pet.memories.append(m)
func _artifact(id:String)->Dictionary:
    for a in catalog.artifacts:
        if str(a.id)==id: return a
    return {}
func _remove_status(s:String)->void:
    if s in state.pet.status_effects: state.pet.status_effects.erase(s)
func _set_preference_seed()->void:
    var c:Dictionary=current_creature()
    var seed:=_mix_seed(int(state.pet.birth_time)+hash(str(state.pet.get("personality","Curious"))))
    var gp:Dictionary=c.get("game_preference",{})
    state.pet.preferences.food=str(gp.get("food_id","mixed"))
    state.pet.preferences.toy=str(gp.get("toy_id",catalog.toys[seed%catalog.toys.size()].id))
    state.pet.preferences.habitat=str(c.get("factual_data",{}).get("habitat","unknown"))
    state.pet.preferences.weather=["CLEAR","RAIN","STORM","FOG","HEAT","WIND"][seed%6]
    state.pet.preferences.time=["DAWN","DAY","SUNSET","NIGHT"][seed%4]
    state.pet.preferences.preference_status="GAME_PREFERENCE"
func _update_traits()->void:
    var p:Dictionary=state.pet; var t:Array=p.traits
    if p.stats.curiosity>=75 and "Adventurous" not in t: t.append("Adventurous")
    if p.stats.intelligence>=75 and "Observant" not in t: t.append("Observant")
    if p.stats.bond>=80 and "Devoted" not in t: t.append("Devoted")
    if p.stats.discipline>=75 and "Focused" not in t: t.append("Focused")
    p.traits=t
func _update_personality()->void:
    var p:Dictionary=state.pet
    if not p.has("base_personality"): p.base_personality=str(p.get("personality","Curious"))
    var secondary:Array=[]
    if p.stats.happiness>=75 and p.care_history.play>=3: secondary.append("Playful")
    if p.stats.curiosity>=75 and p.care_history.exploration>=3: secondary.append("Adventurous")
    if p.stats.intelligence>=75 and p.care_history.research>=3: secondary.append("Observant")
    if p.stats.bond>=80: secondary.append("Devoted")
    if p.stats.discipline>=75: secondary.append("Focused")
    if p.stats.stress<=20 and p.stats.cleanliness>=70: secondary.append("Calm")
    p.secondary_personality=secondary
    p.personality=p.base_personality

func _update_research_level()->void:
    var r:=int(state.player.research); state.player.research_level="MASTERED" if r>=500 else ("RESEARCHED" if r>=150 else ("OBSERVED" if r>=50 else "DISCOVERED"))
func _update_player_rank()->void:
    var r:=int(state.player.research); state.player.rank="MAESTRO NUSANTARA" if r>=500 else ("PENJAGA" if r>=250 else ("PENELITI" if r>=100 else ("PENGAMAT" if r>=30 else "PENJELAJAH")))
func _regional_progress(region:String,amount:int)->void: state.player.regional_mastery[region]=min(100,int(state.player.regional_mastery.get(region,0))+amount)
func _mix_seed(v:int)->int:
    var x=v ^ 0x9E3779B9; x=int((x*1103515245+12345)&0x7fffffff); return x


# -----------------------------------------------------------------------------
# MASTER SPEC EXPANSION — progression, sanctuary, research, accessibility,
# deterministic systems and release-safe diagnostics.
# -----------------------------------------------------------------------------
func _evaluate_progression() -> void:
    if state.is_empty(): return
    _update_quest_progress()
    _update_achievements()

func _update_quest_progress() -> void:
    var completed:Array=state.quests.get("completed",[])
    for q in catalog.quests:
        var qid:=str(q.get("id",""))
        if qid=="" or qid in completed: continue
        var req:Dictionary=q.get("requirement",{})
        var done:=false
        if req.has("memory"): done=str(req.memory) in state.pet.memories
        elif req.has("expeditions_completed"): done=int(state.meta.get("expeditions_completed",0))>=int(req.expeditions_completed)
        elif req.has("artifact_count"): done=state.collection.artifacts.size()>=int(req.artifact_count)
        elif req.has("cross_paths"): done=state.collection.cross_paths.size()>=int(req.cross_paths)
        elif req.has("research"): done=int(state.player.research)>=int(req.research)
        state.quests.progress[qid]=1 if done else 0
        if done:
            completed.append(qid)
            state.quests.completed_at[qid]=int(Time.get_unix_time_from_system())
            var reward:Dictionary=q.get("reward",{})
            state.player.research+=int(reward.get("research",0))
            _memory("quest_"+qid)
            toast_requested.emit("Quest selesai: "+str(q.get("name_id",qid)))
    state.quests.completed=completed

func _update_achievements() -> void:
    var unlocked:Array=state.achievements
    var c:Dictionary=state.collection
    var mastery_max:=0
    for v in state.pet.artifact_mastery.values(): mastery_max=max(mastery_max,int(v))
    for a in catalog.achievements:
        var aid:=str(a.get("id","")); if aid=="" or aid in unlocked: continue
        var cond:Dictionary=a.get("condition",{}); var ok:=false
        if cond.has("artifacts"): ok=c.artifacts.size()>=int(cond.artifacts)
        elif cond.has("armor"): ok=c.armor.size()>=int(cond.armor)
        elif cond.has("perfect_resonance"): ok=int(state.pet.get("perfect_resonance",0))>=1
        elif cond.has("cross_paths"): ok=c.cross_paths.size()>=int(cond.cross_paths)
        elif cond.has("hidden_branch"): ok="hidden_branch" in state.pet.memories
        elif cond.has("dual_resonance"): ok=c.dual_resonance.size()>=int(cond.dual_resonance)
        elif cond.has("regional_mastery"):
            for v in state.player.regional_mastery.values():
                if int(v)>=int(cond.regional_mastery): ok=true; break
        elif cond.has("species"): ok=c.species.size()>=int(cond.species)
        elif cond.has("forms"): ok=c.forms.size()>=int(cond.forms)
        elif cond.has("mastery"): ok=mastery_max>=int(cond.mastery)
        if ok:
            unlocked.append(aid); toast_requested.emit("Achievement: "+str(a.get("name_id",aid)))
    state.achievements=unlocked

func try_perfect_resonance() -> bool:
    var p:Dictionary=state.pet
    if p.stage<6 or p.resonance_form.is_empty(): return false
    var aid:=_armor_artifact_affinity(armor_affinity(p.current_armor))
    var mastery:=int(p.artifact_mastery.get(aid,0))
    var max_region:=0
    for v in state.player.regional_mastery.values(): max_region=max(max_region,int(v))
    var entry_id:=str(p.get("current_line_id",p.get("creature_id","")))
    var relevant_research_level:=research_level_for(entry_id)
    var ok:=mastery>=100 and int(p.stats.bond)>=95 and int(p.stats.health)>=90 and int(p.stats.happiness)>=90 and max_region>=100 and relevant_research_level=="MASTERED" and "SICK" not in p.status_effects
    if not ok: return false
    p.perfect_resonance=1
    p.evolution_signature["perfect_resonance"]=true
    p.evolution_signature["perfect_resonance_reward"]="SANCTUARY_AURA"
    p.evolution_signature["perfect_resonance_animation"]="SpecialIdle"
    p.evolution_signature["perfect_resonance_codex"]="perfect_resonance_codex"
    if "perfect_resonance_codex" not in p.memories: p.memories.append("perfect_resonance_codex")
    _memory("perfect_resonance")
    _evaluate_progression(); _touch(); _transactional_save("PERFECT_RESONANCE"); if RecoveryManager: RecoveryManager.complete(); state_changed.emit(); toast_requested.emit("Perfect Resonance tercapai."); return true

func _record_evolution_signature() -> void:
    var p:Dictionary=state.pet
    p.evolution_signature={"stage":p.stage,"personality":p.personality,"bond":int(p.stats.bond),"care":int(p.dna.care),"mind":int(p.dna.mind),"adventure":int(p.dna.adventure),"nature":int(p.dna.nature),"discipline":int(p.dna.discipline),"mystic":int(p.dna.mystic),"region":state.world.get("region",state.player.selected_region),"weather":state.world.get("weather","CLEAR"),"time":state.world.get("time_phase","DAY"),"form":p.form_id,"perfect_resonance":bool(p.get("perfect_resonance",false))}

func evolution_forecast() -> Dictionary:
    var p:Dictionary=state.pet; var need:=100.0+float(max(0,p.stage-1))*45.0; var score:=_evolution_score(p)
    return {"stage":p.stage,"next_stage":min(6,p.stage+1),"score":score,"threshold":need,"progress":clamp(score/need,0.0,1.0),"personality":p.personality,"current_line":p.current_line_id,"branch_candidates":_eligible_cross(p.current_line_id,p.stage+1)}

func evolution_journal() -> Array:
    return state.pet.get("evolution_history",[]).duplicate()

func evolution_hints() -> Array:
    var hints:Array=[]; var p:Dictionary=state.pet
    var actions:=int(state.meta.get("total_actions",0))
    # Progressive, spoiler-free hints. The first tier identifies a system; later tiers narrow the action without revealing a branch.
    if p.stats.bond<70:
        hints.append(tr("hint_bond_basic"))
        if actions>=25: hints.append(tr("hint_bond_clear"))
    if p.dna.adventure<30:
        hints.append(tr("hint_explore_basic"))
        if actions>=40: hints.append(tr("hint_explore_clear"))
    var current_research:=research_level_for(str(p.get("current_line_id",p.get("creature_id",""))))
    if current_research!="MASTERED":
        hints.append(tr("hint_research_basic"))
        if actions>=50: hints.append(tr("hint_research_clear"))
    if p.stage>=4 and state.collection.cross_paths.is_empty():
        hints.append(tr("hint_cross_basic"))
        if actions>=70: hints.append(tr("hint_cross_clear"))
    if p.stage>=5 and p.resonance_form.is_empty():
        hints.append(tr("hint_resonance_basic"))
        if actions>=90: hints.append(tr("hint_resonance_clear"))
    if p.stage>=6 and p.resonance_form!="" and int(p.get("perfect_resonance",0))<1:
        hints.append(tr("hint_perfect_basic"))
        if actions>=120: hints.append(tr("hint_perfect_clear"))
    return hints.slice(0,6)

func add_rumor(text:String) -> void:
    if text.strip_edges().is_empty(): return
    var rumors:Array=state.meta.get("rumors",[])
    if text not in rumors: rumors.append(text)
    state.meta.rumors=rumors.slice(max(0,rumors.size()-20),rumors.size())

func age_seconds()->int:
    if not state.pet.hatched: return 0
    return max(0,int(Time.get_unix_time_from_system())-int(state.pet.birth_time))
func age_label()->String:
    var d:=int(age_seconds()/86400); var h:=int(age_seconds()/3600)%24
    return "%d hari %d jam"%[d,h]

func add_companion_from_current() -> bool:
    var s:Dictionary=state.sanctuary
    if s.companions.size()>=int(s.get("capacity",3)): return false
    var p:Dictionary=state.pet.duplicate(true)
    p["legacy_id"]="legacy_%s"%str(_mix_seed(int(Time.get_unix_time_from_system())+s.companions.size()))
    p["archived_at"]=int(Time.get_unix_time_from_system())
    s.companions.append(p); state.sanctuary=s; _touch(); save_game(); state_changed.emit(); return true

func switch_companion(index:int)->bool:
    var comps:Array=state.sanctuary.get("companions",[])
    if index<0 or index>=comps.size(): return false
    var current:Dictionary=state.pet.duplicate(true)
    current["active_snapshot"]=true
    var incoming:Dictionary=comps[index].duplicate(true)
    comps[index]=current; state.pet=incoming; state.sanctuary.companions=comps; state.sanctuary.active_slot=index
    _touch(); _transactional_save("SWITCH_COMPANION"); state_changed.emit(); return true

func archive_current_to_legacy()->bool:
    var entry:Dictionary=state.pet.duplicate(true)
    entry["archived_at"]=int(Time.get_unix_time_from_system())
    entry["legacy_id"]="legacy_%s"%str(_mix_seed(int(entry.archived_at)))
    state.legacy.archive.append(entry)
    var inh:Dictionary=state.legacy.inheritance
    inh.nature=min(100,int(inh.nature)+int(state.pet.dna.nature/5)); inh.mind=min(100,int(inh.mind)+int(state.pet.dna.mind/5)); inh.knowledge=min(100,int(inh.knowledge)+int(state.player.research/25)); inh.emblem=str(state.pet.form_id)
    state.legacy.inheritance=inh; _touch(); _transactional_save("LEGACY_ARCHIVE"); state_changed.emit(); return true

func inheritance_seed()->Dictionary:
    return state.legacy.get("inheritance",{}).duplicate(true)

func can_start_new_generation()->bool:
    return state.pet.hatched and int(state.pet.stage)>=6 and not state.pet.offline_evolution_pending

func start_new_generation(creature_id:String="")->bool:
    if not can_start_new_generation(): return false
    var selected:=creature_id.strip_edges()
    if selected.is_empty():
        selected=str(state.pet.current_line_id)
    var exists:=false
    for c in catalog.creatures:
        if str(c.get("id",""))==selected:
            exists=true; break
    if not exists: return false
    if not archive_current_to_legacy(): return false
    var old_inh:=inheritance_seed()
    var old_pet:Dictionary=state.pet.duplicate(true)
    state.pet=_new_pet(selected)
    state.pet.dna.nature=clamp(int(old_inh.get("nature",0))+int(state.pet.dna.nature),0,100)
    state.pet.dna.mind=clamp(int(old_inh.get("mind",0))+int(state.pet.dna.mind),0,100)
    state.pet.dna.care=clamp(int(state.pet.dna.care)+int(old_pet.dna.care/20),0,100)
    state.pet.dna.bond=clamp(int(state.pet.dna.bond)+int(old_pet.dna.bond/20),0,100)
    if not str(old_inh.get("emblem","")).is_empty():
        state.pet.rare_traits=["LEGACY_ECHO"]
    state.pet.memories.append("inherited_from_legacy")
    state.pet.birth_time=int(Time.get_unix_time_from_system())
    if selected not in state.player.discoveries: state.player.discoveries.append(selected)
    if selected not in state.collection.species: state.collection.species.append(selected)
    if selected+"_s1" not in state.collection.forms: state.collection.forms.append(selected+"_s1")
    _set_preference_seed(); _touch(); _transactional_save("NEW_GENERATION"); state_changed.emit(); return true

func expedition_team_candidates()->Array:
    var out:Array=[state.pet]
    for c in state.sanctuary.get("companions",[]): out.append(c)
    return out

func start_team_expedition(duration_index:int=0)->bool:
    var team:=expedition_team_candidates()
    if team.size()<2 or state.player.expeditions.size()>=2: return false
    if not start_expedition(duration_index): return false
    state.player.expeditions[-1]["team_size"]=min(3,team.size()); state.player.expeditions[-1]["team_roles"]=[str(x.get("personality","Unknown")) for x in team.slice(0,3)]
    _touch(); save_game(); return true

func merge_cloud_state(local:Dictionary, remote:Dictionary)->Dictionary:
    if local.is_empty(): return remote.duplicate(true)
    if remote.is_empty(): return local.duplicate(true)
    var ltime:=int(local.get("updated_at",0)); var rtime:=int(remote.get("updated_at",0))
    var winner:Dictionary=local.duplicate(true) if ltime>=rtime else remote.duplicate(true)
    var other:Dictionary=remote if winner==local else local
    # Monotonic collections and research survive a timestamp conflict.
    winner.player.research=max(int(winner.player.get("research",0)),int(other.get("player",{}).get("research",0)))
    for key in ["species","forms","armor","cross_paths","artifacts","regions","resonance","dual_resonance"]:
        var merged:Array=winner.collection.get(key,[])
        for item in other.get("collection",{}).get(key,[]):
            if item not in merged: merged.append(item)
        winner.collection[key]=merged
    winner.updated_at=max(ltime,rtime); winner.meta.last_save_operation="CLOUD_MERGE"
    return winner

func delete_local_account_data()->bool:
    if FileAccess.file_exists(SAVE_PATH): DirAccess.remove_absolute(SAVE_PATH)
    if FileAccess.file_exists(BACKUP_PATH): DirAccess.remove_absolute(BACKUP_PATH)
    if FileAccess.file_exists(SNAPSHOT_PATH): DirAccess.remove_absolute(SNAPSHOT_PATH)
    state={}; return true

func is_region_unlocked(region_id:String)->bool:
    if region_id==str(state.player.get("selected_region","")): return true
    var regions:Array=state.collection.get("regions",[])
    if region_id in regions: return true
    var mastery_total:=0
    for v in state.player.regional_mastery.values(): mastery_total+=int(v)
    var order:=0
    for r in catalog.regions:
        if str(r.get("id",""))==region_id: order=catalog.regions.find(r); break
    return order==0 or mastery_total>=order*5

func discover_region(region_id:String)->bool:
    if not is_region_unlocked(region_id): return false
    if region_id not in state.collection.regions: state.collection.regions.append(region_id)
    _regional_progress(region_id,1); _memory("region_"+region_id); _evaluate_progression(); _touch(); save_game(); state_changed.emit(); return true

func storage_status()->Dictionary:
    var used:=0
    for path in [SAVE_PATH,BACKUP_PATH,SNAPSHOT_PATH]:
        if FileAccess.file_exists(path): used+=FileAccess.get_file_as_bytes(path).size()
    var optional_bytes:=_directory_bytes("user://cache/assets")
    return {"save_bytes":used,"optional_cache_bytes":optional_bytes,"low_storage_mode":bool(state.get("settings",{}).get("battery_mode","")=="LOW_STORAGE"),"asset_pack":"CORE"}

func _directory_bytes(path:String)->int:
    var total:=0
    var dir:=DirAccess.open(path)
    if dir==null: return 0
    dir.list_dir_begin()
    var name:=dir.get_next()
    while not name.is_empty():
        if name!="." and name!="..":
            var child:=path.rstrip("/")+"/"+name
            if dir.current_is_dir(): total+=_directory_bytes(child)
            elif FileAccess.file_exists(child): total+=FileAccess.get_file_as_bytes(child).size()
        name=dir.get_next()
    dir.list_dir_end()
    return total

func clear_optional_assets()->bool:
    var root_path:="user://cache/assets"
    var dir:=DirAccess.open(root_path)
    if dir==null: return true
    return _clear_directory(root_path)

func _clear_directory(path:String)->bool:
    var dir:=DirAccess.open(path)
    if dir==null: return true
    dir.list_dir_begin()
    var name:=dir.get_next()
    var ok:=true
    while not name.is_empty():
        if name!="." and name!="..":
            var child:=path.rstrip("/")+"/"+name
            if dir.current_is_dir():
                ok=_clear_directory(child) and ok
                DirAccess.remove_absolute(child)
            else:
                ok=DirAccess.remove_absolute(child)==OK and ok
        name=dir.get_next()
    dir.list_dir_end()
    return ok

func set_time_phase(value:String)->void:
    value=value.to_upper()
    if value not in ["DAWN","DAY","SUNSET","NIGHT"]: return
    if str(state.world.get("time_phase","DAY"))==value: return
    state.world.time_phase=value
    _touch(); save_game(); state_changed.emit()

func set_weather(value:String)->void:
    var allowed:= ["CLEAR","RAIN","STORM","FOG","HEAT","WIND"]
    value=value.to_upper()
    if value not in allowed: return
    if str(state.world.get("weather","CLEAR"))==value: return
    state.world.weather=value
    _touch(); save_game(); state_changed.emit()

func set_world_region(region_id:String)->void:
    region_id=region_id.to_lower().strip_edges()
    if region_id.is_empty(): return
    state.world.region=region_id
    state.player.selected_region=region_id
    _touch(); save_game(); state_changed.emit()

func set_world_habitat(value:String)->void:
    value=value.to_upper().strip_edges()
    if value.is_empty(): return
    if str(state.world.get("habitat","RAINFOREST"))==value: return
    state.world.habitat=value
    _touch(); save_game(); state_changed.emit()

func set_accessible_time_override(enabled:bool)->void:
    state.settings.accessible_time_override=enabled
    _touch(); save_game(); state_changed.emit()

func food_is_diet_compatible(creature_id:String, food_id:String)->bool:
    # REAL-species diet data is research-gated. Never infer a biological diet from archetype.
    var c:=encyclopedia_entry(creature_id)
    if c.is_empty() or str(c.get("category",""))!="REAL":
        return true
    var diet:=c.get("research_record",{}).get("diet_tags",[])
    if typeof(diet)!=TYPE_ARRAY or diet.is_empty():
        return false
    var item:Dictionary={}
    for f in catalog.food:
        if str(f.get("id",""))==food_id: item=f; break
    if item.is_empty(): return false
    for tag in item.get("diet_tags",[]):
        if tag in diet: return true
    return false

func set_quality(value:String)->void:
    if value not in ["HIGH","BALANCED","BATTERY_SAVER","LOW_STORAGE"]: return
    state.settings.quality=value; state.settings.battery_mode="LOW_STORAGE" if value=="LOW_STORAGE" else state.settings.battery_mode; _touch(); save_game(); state_changed.emit()

func set_text_scale(value:float)->void:
    state.settings.text_scale=clamp(value,0.85,1.6); _touch(); save_game(); state_changed.emit()

func set_accessibility(reduced:bool, screen_reader:bool=true)->void:
    state.settings.reduced_motion=reduced; state.meta.screen_reader=screen_reader; _touch(); save_game(); state_changed.emit()

func haptic_feedback(duration_ms:int=30, amplitude:float=0.5)->void:
    if not bool(state.get("settings",{}).get("haptic",true)):
        return
    Input.vibrate_handheld(max(1,duration_ms),clamp(amplitude,0.0,1.0))
