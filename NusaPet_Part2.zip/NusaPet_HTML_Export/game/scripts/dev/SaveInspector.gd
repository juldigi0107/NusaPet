@tool
extends Control
class_name NusaSaveInspector
## Developer-only read-only save inspector.
func inspect_payload(payload:Dictionary)->Dictionary:
    var gs:=NusaGameState.new()
    return {"schema_version":payload.get("schema_version",payload.get("version",0)),"content_version":payload.get("content_version",""),"checksum_present":not str(payload.get("checksum","")).is_empty(),"checksum_valid":gs._verify_checksum(payload),"pet_stage":int(payload.get("pet",{}).get("stage",0)),"legacy_count":payload.get("legacy",{}).get("archive",[]).size()}
