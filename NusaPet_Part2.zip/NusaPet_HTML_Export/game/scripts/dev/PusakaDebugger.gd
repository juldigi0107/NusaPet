@tool
extends Control
class_name NusaPusakaDebugger
## Developer-only Pusaka compatibility inspection.
func inspect(creature_id:String, stage:int, affinity:String, mastery:int)->Dictionary:
    var gs:=NusaGameState.new()
    gs._load_content()
    var compatible:=gs._compatibility_weight(creature_id,affinity)>=0.8
    var forms:Array=[]
    for ar in gs.catalog.armor:
        if str(ar.get("base_creature",""))==creature_id and int(ar.get("minimum_stage",3))<=stage and str(ar.get("artifact_affinity",""))==affinity:
            forms.append(str(ar.get("id","")))
    return {"creature":creature_id,"stage":stage,"affinity":affinity,"mastery":mastery,"compatible":compatible,"armor_forms":forms}
