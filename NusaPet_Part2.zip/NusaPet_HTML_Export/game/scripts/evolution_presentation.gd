class_name NusaEvolutionPresentation
extends Node3D
## Native 3D evolution presentation: camera-independent light/ring treatment.
## Uses gameplay state only; no prerecorded video or web UI dependency.

var active := false
var elapsed := 0.0
var duration := 2.4
var ring: MeshInstance3D
var light: OmniLight3D
var target: Node3D
var dominant_affinity := "ANY"

func setup(creature_root: Node3D) -> void:
    target = creature_root
    ring = MeshInstance3D.new()
    ring.name = "EvolutionRing"
    var torus := TorusMesh.new()
    torus.inner_radius = 0.7
    torus.outer_radius = 0.84
    ring.mesh = torus
    ring.position = Vector3(0, 0.12, 0)
    ring.visible = false
    add_child(ring)
    light = OmniLight3D.new()
    light.name = "EvolutionLight"
    light.light_energy = 0.0
    light.omni_range = 5.0
    add_child(light)

func trigger(signature: Dictionary = {}) -> void:
    if target == null:
        return
    dominant_affinity = str(signature.get("affinity", "ANY"))
    active = true
    elapsed = 0.0
    ring.visible = true
    light.light_energy = 0.0

func _process(delta: float) -> void:
    if not active or target == null:
        return
    elapsed += delta
    var t := clamp(elapsed / duration, 0.0, 1.0)
    var pulse := sin(t * PI)
    ring.position = target.position + Vector3(0, 0.12 + pulse * 0.18, 0)
    ring.rotation.y += delta * 2.6
    ring.scale = Vector3.ONE * (0.75 + pulse * 1.2)
    light.position = target.position + Vector3(0, 1.2, 0)
    light.light_energy = pulse * 2.8
    if t >= 1.0:
        active = false
        ring.visible = false
        light.light_energy = 0.0
