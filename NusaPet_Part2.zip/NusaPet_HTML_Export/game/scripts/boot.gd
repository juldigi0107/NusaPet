extends Node

func _ready() -> void:
    if not GameState.state.is_empty() and bool(GameState.state.get("meta", {}).get("onboarding_complete", false)):
        get_tree().change_scene_to_file("res://scenes/main/Main.tscn")
    else:
        get_tree().change_scene_to_file("res://scenes/onboarding/Onboarding.tscn")
