class_name StorageAdapter
extends RefCounted
## Generic local storage adapter used by non-critical services.
## Native GameState save remains authoritative.
func save_state(payload:Dictionary, path:String="user://save/adapter_state.json")->bool:
    var dir:=path.get_base_dir()
    DirAccess.make_dir_recursive_absolute(dir)
    var f:=FileAccess.open(path,FileAccess.WRITE)
    if f==null: return false
    f.store_string(JSON.stringify(payload))
    f.close()
    return true

func load_state(path:String="user://save/adapter_state.json")->Dictionary:
    if not FileAccess.file_exists(path): return {}
    var parsed=JSON.parse_string(FileAccess.get_file_as_string(path))
    return parsed if typeof(parsed)==TYPE_DICTIONARY else {}
