class_name CloudSaveAdapter
extends RefCounted
## Vendor-isolated Supabase adapter. Offline core never calls it per-frame.
signal status(message: String)
signal push_finished(ok: bool, code: int, body: Dictionary)
signal pull_finished(ok: bool, code: int, payload: Dictionary)
var configured := false
var base_url := ""
var anon_key := ""
var access_token := ""

func _init() -> void:
    base_url=OS.get_environment("SUPABASE_URL").strip_edges().trim_suffix("/")
    anon_key=OS.get_environment("SUPABASE_ANON_KEY").strip_edges()
    configured=not base_url.is_empty() and not anon_key.is_empty()

func set_access_token(token:String) -> void:
    access_token=token.strip_edges()

func push(_payload: Dictionary) -> bool:
    if not configured:
        status.emit("Cloud unavailable — local save remains authoritative.")
        return false
    var request:=HTTPRequest.new()
    request.request_completed.connect(func(result,code,headers,body):
        var parsed=JSON.parse_string(body.get_string_from_utf8())
        push_finished.emit(result==HTTPRequest.RESULT_SUCCESS and code>=200 and code<300,code,parsed if typeof(parsed)==TYPE_DICTIONARY else {}))
        request.queue_free())
    if access_token.is_empty():
        status.emit("Cloud sync requires an authenticated session.")
        return false
    var headers:=PackedStringArray(["apikey: "+anon_key,"Authorization: Bearer "+access_token,"Content-Type: application/json"])
    var code:=request.request(base_url+"/rest/v1/cloud_saves",headers,HTTPClient.METHOD_POST,JSON.stringify(_payload))
    if code!=OK:
        request.queue_free()
        status.emit("Cloud request could not start.")
        return false
    status.emit("Cloud sync started.")
    return true

func pull(profile_id:String) -> bool:
    if not configured or profile_id.is_empty():
        status.emit("Cloud unavailable — using local save.")
        return false
    var request:=HTTPRequest.new()
    request.request_completed.connect(func(result,code,headers,body):
        var parsed=JSON.parse_string(body.get_string_from_utf8())
        var payload:Dictionary={}
        if typeof(parsed)==TYPE_ARRAY and not parsed.is_empty() and typeof(parsed[0])==TYPE_DICTIONARY: payload=parsed[0]
        elif typeof(parsed)==TYPE_DICTIONARY: payload=parsed
        pull_finished.emit(result==HTTPRequest.RESULT_SUCCESS and code>=200 and code<300,code,payload)
        request.queue_free())
    if access_token.is_empty():
        status.emit("Cloud pull requires an authenticated session.")
        return false
    var headers:=PackedStringArray(["apikey: "+anon_key,"Authorization: Bearer "+access_token])
    var url:=base_url+"/rest/v1/cloud_saves?profile_id=eq."+profile_id+"&order=updated_at.desc&limit=1"
    var code:=request.request(url,headers,HTTPClient.METHOD_GET)
    if code!=OK: request.queue_free(); return false
    return true

func delete_cloud_data() -> bool:
    if not configured: return false
    var request:=HTTPRequest.new()
    request.request_completed.connect(func(result,code,headers,body): request.queue_free())
    if access_token.is_empty(): return false
    var headers:=PackedStringArray(["apikey: "+anon_key,"Authorization: Bearer "+access_token,"Content-Type: application/json"])
    var code:=request.request(base_url+"/rest/v1/rpc/delete_my_cloud_data",headers,HTTPClient.METHOD_POST,"{}")
    if code!=OK: request.queue_free(); return false
    return true
