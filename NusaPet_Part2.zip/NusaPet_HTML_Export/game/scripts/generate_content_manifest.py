import hashlib,json,pathlib
root=pathlib.Path(__file__).parents[1]
files={}
for p in sorted((root/'data').rglob('*')):
    if p.is_file() and p.suffix.lower() in {'.json','.jsonl'}:
        rel=str(p.relative_to(root)).replace('\\','/')
        b=p.read_bytes(); files[rel]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}

def count(name):
    try:return len(json.loads((root/name).read_text(encoding='utf-8')))
    except:return 0
creatures=json.loads((root/'data/creatures/creatures.json').read_text(encoding='utf-8'))
summary={
 'creatures':len(creatures),
 'real':sum(c.get('category')=='REAL' for c in creatures),
 'mythology':sum(c.get('category')=='MYTHOLOGY' for c in creatures),
 'mystical':sum(c.get('category')=='MYSTICAL' for c in creatures),
 'primary_forms':count('data/evolutions/primary_forms.json'),
 'armor_forms':count('data/armor-forms/armor_forms.json'),
 'cross_paths':count('data/cross-evolutions/cross_paths.json'),
 'pusaka':count('data/artifacts/pusaka.json'),
 'dual_resonance':count('data/artifacts/dual_resonance.json'),
 'asset_manifest':len(json.loads((root/'data/assets/asset_manifest.json').read_text())['items']),
 'art_prompts':len(json.loads((root/'data/assets/art_prompts.json').read_text())['items'])
}
out={'content_version':'2026.09-content-2','summary':summary,'files':files,'generated_by':'scripts/generate_content_manifest.py'}
(root/'data/content_manifest.json').write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(out['summary'],indent=2))
