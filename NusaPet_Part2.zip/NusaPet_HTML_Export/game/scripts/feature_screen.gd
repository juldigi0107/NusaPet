class_name NusaFeatureScreen
extends Control
@export var feature := "NUSAPEDIA"
var body: VBoxContainer

func _ready()->void:
    set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    _build()

func _build()->void:
    var margin:=MarginContainer.new(); margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    margin.add_theme_constant_override("margin_left",24); margin.add_theme_constant_override("margin_right",24); margin.add_theme_constant_override("margin_top",24); margin.add_theme_constant_override("margin_bottom",24)
    add_child(margin)
    body=VBoxContainer.new(); body.add_theme_constant_override("separation",10); margin.add_child(body)
    var title:=Label.new(); title.text=_feature_title(); title.add_theme_font_size_override("font_size",28); body.add_child(title)
    match feature:
        "NUSAPEDIA": _nusapedia()
        "COLLECTION": _collection()
        "PUSAKA": _pusaka()
        "ARMOR": _armor()
        "EVOLUTION": _evolution()
        "RESONANCE": _resonance()
        "EXPLORATION": _exploration()
        "CREATURE_VIEWER": _creature_viewer()
        "HUD": _hud()
        "SETTINGS": _settings()
        "PAUSE": _pause()
        "RECOVERY": _recovery()


func _feature_title()->String:
    var key_map={
        "NUSAPEDIA":"nusapedia", "COLLECTION":"collection", "PUSAKA":"open_pusaka",
        "ARMOR":"armor", "EVOLUTION":"evolve", "RESONANCE":"resonance",
        "EXPLORATION":"explore", "SETTINGS":"settings", "PAUSE":"pause", "RECOVERY":"recovery"
    }
    var key:=str(key_map.get(feature,""))
    return GameState.tr(key) if not key.is_empty() else feature

func _label(t:String)->void:
    var l:=Label.new(); l.text=t; l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; body.add_child(l)

func _button(t:String, cb:Callable)->void:
    var b:=Button.new(); b.text=t; b.custom_minimum_size=Vector2(0,56); b.pressed.connect(cb); body.add_child(b)

func _nusapedia()->void:
    _label("Search and inspect factual/cultural records. Game evolution remains separately labelled.")
    for c in GameState.catalog.creatures.slice(0,12):
        _button("%s • %s"%[str(c.get("name_id","")),str(c.get("category",""))],func(): _label("Scientific: "+str(c.get("scientific_name",""))))

func _collection()->void:
    var c=GameState.state.collection
    _label("Species %d • Forms %d • Cross Branch %d • Armor %d • Pusaka %d"%[c.species.size(),c.forms.size(),c.cross_paths.size(),c.armor.size(),c.artifacts.size()])
    _label("Resonance %d • Dual Resonance %d"%[c.resonance.size(),c.dual_resonance.size()])

func _pusaka()->void:
    _label("Discovered GAME ARTIFACTS only. Secret artifacts are revealed through discovery.")
    for id in GameState.state.pet.inventory:
        var a=GameState._artifact(str(id)); _button("%s • %s"%[str(a.get("affinity","")),str(a.get("rarity",""))],func(): GameState.transform(str(id)))

func _armor()->void:
    _label("Active Armor: "+str(GameState.state.pet.current_armor))
    _button("REVERT",func(): GameState.revert_armor())

func _evolution()->void:
    var f=GameState.evolution_forecast()
    _label("Instinct • progress %.0f%% • next stage %d"%[float(f.progress)*100.0,int(f.next_stage)])
    for h in GameState.evolution_hints(): _label("• "+str(h))
    _button(GameState.tr("evolve"),func(): GameState.evolve())

func _resonance()->void:
    _label("Resonance is distinct from Affection and depends on creature, Pusaka, bond, mastery and discovery.")
    _button(GameState.tr("check_resonance"),func(): GameState.check_resonance())

func _exploration()->void:
    _label("Field research and expeditions use deterministic stored seeds and continue offline.")
    _button("OBSERVE CLUE",func(): GameState.observe_field_clue())
    _button(GameState.tr("start_expedition"),func(): GameState.start_expedition(0))

func _creature_viewer()->void:
    var c=GameState.current_creature(); _label("%s\n%s\n%s"%[str(c.get("name_id","")),str(c.get("name_en","")),str(c.get("scientific_name",""))])

func _hud()->void:
    var p=GameState.state.pet; _label("%s • Stage %d • %s"%[str(p.nickname),int(p.stage),str(p.personality)])

func _settings()->void:
    var reduced:=CheckButton.new(); reduced.text=GameState.tr("reduced_motion"); reduced.button_pressed=bool(GameState.state.settings.reduced_motion); reduced.toggled.connect(func(v): GameState.set_accessibility(v,bool(GameState.state.meta.get("screen_reader",true)))); body.add_child(reduced)

func _pause()->void:
    _label(GameState.tr("pause_body"))

func _recovery()->void:
    _label(GameState.tr("recovery_body"))
