class_name NusaEnvironmentInteractionController
extends Node3D
## Native 3D habitat interaction coordinator.
## Only offers actions supported by the creature profile and available world anchors.

signal interaction_started(action: String)
signal interaction_completed(action: String)
signal interaction_rejected(action: String)

var creature_root: Node3D
var world: WorldBuilder
var creature: Dictionary = {}
var pet_state: Dictionary = {}
var profile: Array[String] = []
var locomotion: Array[String] = []
var busy := false
var current_action := ""
var _target := Vector3.ZERO
var _start := Vector3.ZERO
var _elapsed := 0.0
var _duration := 0.8
var _animation: NusaCreatureAnimationController

const ACTION_ANCHORS := {
    "SWIM":"water", "PERCH":"perch", "HIDE":"hide", "DIG":"dig",
    "CLIMB":"climb", "REST":"rest", "SNIFF":"observe", "OBSERVE":"observe",
    "PLAY":"play"
}

func setup(root: Node3D, habitat_world: WorldBuilder, c: Dictionary, p: Dictionary) -> void:
    creature_root=root; world=habitat_world; creature=c; pet_state=p
    profile=[]; locomotion=[]
    for v in c.get("interaction_profile",[]): profile.append(str(v).to_upper())
    for v in c.get("locomotion_profile",[]): locomotion.append(str(v).to_upper())
    _animation=creature_root.get_node_or_null("AnimationController") as NusaCreatureAnimationController

func available_actions() -> Array[String]:
    var result:Array[String]=[]
    if world == null or busy: return result
    for action in profile:
        var key:=action.to_upper()
        if ACTION_ANCHORS.has(key) and world.has_interaction_anchor(str(ACTION_ANCHORS[key])):
            result.append(key)
    return result

func request(action: String) -> bool:
    var key:=action.to_upper()
    if key not in available_actions():
        interaction_rejected.emit(key); return false
    var anchor:=world.interaction_anchor(str(ACTION_ANCHORS[key]))
    if anchor.is_empty():
        interaction_rejected.emit(key); return false
    busy=true; current_action=key; _elapsed=0.0; _start=creature_root.global_position
    _target=Vector3(anchor.position.x, max(anchor.position.y,0.45), anchor.position.z)
    _duration=1.0 if key in ["SWIM","CLIMB","DIG"] else 0.7
    interaction_started.emit(key)
    if _animation: _animation.play_state("Play" if key=="PLAY" else "Interact")
    return true

func _process(delta: float) -> void:
    if not busy or creature_root == null: return
    _elapsed += delta
    var t:=clamp(_elapsed/_duration,0.0,1.0)
    var eased:=t*t*(3.0-2.0*t)
    creature_root.global_position=_start.lerp(_target,eased)
    if t>=1.0:
        busy=false
        if _animation: _animation.play_state("Happy" if current_action in ["PLAY","OBSERVE","SNIFF"] else "SpecialIdle")
        GameState.record_environment_interaction(current_action)
        interaction_completed.emit(current_action)
        current_action=""
