extends Node3D

var world: WorldBuilder
var habitat_root: Node3D
var creature_root: Node3D
var camera: Camera3D
var ui: Control
var content: VBoxContainer
var title: Label
var subtitle: Label
var status: Label
var world_status: Label
var toast: Label
var nav_buttons: Array[Button]=[]
var active_tab: String="HOME"
var orbit:=0.0
var touch_last:=Vector2.ZERO
var touch_distance:=0.0
var camera_zoom:=11.5
var creature_color:=Color("d09b4a")
var egg_root: Node3D
var name_input: LineEdit
var selected_creature_id: String=""
var accessibility_scale: float=1.0
var camera_mode: String="FOLLOW"
var map_root: Node3D
var camera_pivot: SpringArm3D
var care_prop: Node3D
var camera_tween: Tween
var observation_modal: PanelContainer
var sanctuary_visual_root: Node3D
var pusaka_world_controller: NusaPusakaWorldController
var environment_interactions: NusaEnvironmentInteractionController
var evolution_presentation: NusaEvolutionPresentation
var _last_presented_stage := 0

func _ready()->void:
    habitat_root=preload("res://scenes/habitat/Habitat.tscn").instantiate(); add_child(habitat_root)
    world=habitat_root.world
    pusaka_world_controller=preload("res://scripts/world/PusakaWorldController.gd").new()
    add_child(pusaka_world_controller)
    pusaka_world_controller.setup(world)
    world.set_performance_profile(str(GameState.state.settings.get("quality","BALANCED")))
    world.set_region(str(GameState.state.world.get("region",GameState.state.player.get("selected_region","sumatra"))))
    world.set_weather(str(GameState.state.world.get("weather","CLEAR")))
    evolution_presentation=preload("res://scripts/evolution_presentation.gd").new()
    add_child(evolution_presentation)
    _last_presented_stage=int(GameState.state.pet.get("stage",1))
    camera_pivot=SpringArm3D.new()
    camera_pivot.name="CameraCollisionArm"
    camera_pivot.spring_length=11.5
    camera_pivot.margin=0.35
    camera_pivot.collision_mask=1
    camera_pivot.position=Vector3(0,5.6,0)
    add_child(camera_pivot)
    camera=Camera3D.new()
    camera.name="GameplayCamera"
    camera.current=true
    camera.fov=48.0
    camera_pivot.add_child(camera)
    camera.position=Vector3.ZERO
    map_root=preload("res://scenes/exploration/RegionMap3D.tscn").instantiate(); add_child(map_root); map_root.position=Vector3(0,-1.0,0); map_root.visible=false
    _build_ui(); _build_pet_or_egg()
    if AssetPrefetcher:
        AssetPrefetcher.prefetch_for_current_state()
    if RuntimePerformance:
        RuntimePerformance.apply(str(GameState.state.settings.get("quality","BALANCED")), bool(GameState.state.settings.get("reduced_motion",false)))
    GameState.state_changed.connect(_on_state_changed); GameState.toast_requested.connect(_toast); _refresh()

func _process(delta:float)->void:
    if world: world.update(delta)
    if AssetPrefetcher:
        AssetPrefetcher.clear_completed()
    if creature_root and GameState.state.pet.hatched:
        orbit+=delta*.22
        if not environment_interactions or not environment_interactions.busy:
            creature_root.rotation.y=sin(orbit*.35)*.12; creature_root.position.y=1.0+sin(Time.get_ticks_msec()/420.0)*.045
    if egg_root and not GameState.state.pet.hatched:
        egg_root.rotation.y+=delta*.25; egg_root.position.y=1.2+sin(Time.get_ticks_msec()/360.0)*.06
    if world_status and world:
        var phase:=world.time_label()
        world_status.text="%s  •  %s  •  %s  •  %s"%[world.region,world.habitat,phase,str(GameState.state.world.get("weather","CLEAR"))]
        if GameState.state.pet.hatched and str(GameState.state.world.get("time_phase","DAY"))!=phase:
            GameState.set_time_phase(phase)

func _input(event)->void:
    if event is InputEventScreenTouch:
        if event.pressed:
            touch_last=event.position
        return
    if event is InputEventScreenDrag:
        var d:Vector2=event.position-touch_last
        touch_last=event.position
        orbit=clamp(orbit+d.x*.004,-1.35,1.35)
        _apply_camera_orbit()
    elif event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
        orbit=clamp(orbit+event.relative.x*.004,-1.35,1.35)
        _apply_camera_orbit()
    elif event is InputEventMagnifyGesture:
        camera_zoom=clamp(camera_zoom/ max(event.factor,0.1),5.0,16.0)
        _apply_camera_orbit()
    elif event is InputEventMouseButton and event.pressed:
        if event.button_index==MOUSE_BUTTON_WHEEL_UP: camera_zoom=clamp(camera_zoom-0.6,5.0,16.0); _apply_camera_orbit()
        elif event.button_index==MOUSE_BUTTON_WHEEL_DOWN: camera_zoom=clamp(camera_zoom+0.6,5.0,16.0); _apply_camera_orbit()

func _apply_camera_orbit()->void:
    if not camera: return
    var target:=Vector3(0,1.25,0)
    camera_pivot.spring_length=camera_zoom
    camera_pivot.look_at(target)

func _build_pet_or_egg()->void:
    if GameState.state.pet.hatched: _spawn_creature()
    else: _spawn_egg()
func _spawn_egg()->void:
    if egg_root: egg_root.queue_free()
    egg_root=Node3D.new(); add_child(egg_root); egg_root.position=Vector3(0,1.2,0)
    var egg:=MeshInstance3D.new(); var sm:=SphereMesh.new(); sm.radius=1.05; sm.height=1.8; egg.mesh=sm; egg.scale=Vector3(.82,1.25,.82); var m:=StandardMaterial3D.new(); m.albedo_color=Color("d6c18d"); m.roughness=.55; egg.material_override=m; egg_root.add_child(egg)
    for i in range(3):
        var ring:=MeshInstance3D.new(); var tor:=TorusMesh.new(); tor.inner_radius=.52; tor.outer_radius=.58; ring.mesh=tor; ring.position.y=-.35+i*.35; var rm:=StandardMaterial3D.new(); rm.albedo_color=Color("7c9b77"); ring.material_override=rm; egg_root.add_child(ring)
func _spawn_creature()->void:
    if egg_root:
        egg_root.queue_free()
        egg_root=null
    if creature_root:
        creature_root.queue_free()
    var scene:=preload("res://scenes/creature/Creature.tscn")
    creature_root=scene.instantiate()
    add_child(creature_root)
    creature_root.position=Vector3(0,1,0)
    var c:Dictionary=GameState.current_creature()
    var f:Dictionary=GameState.form_record(str(GameState.state.pet.form_id))
    creature_root.configure(c,f,GameState.state.pet)
    environment_interactions=preload("res://scripts/world/EnvironmentInteractionController.gd").new()
    creature_root.add_child(environment_interactions)
    environment_interactions.setup(creature_root,world,c,GameState.state.pet)
    if creature_root.has_signal("creature_interacted"):
        creature_root.creature_interacted.connect(_on_creature_interacted)
    _set_camera_mode(camera_mode)

func _build_ui()->void:
    ui=Control.new(); ui.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); add_child(ui)
    var top:=PanelContainer.new(); top.set_anchors_preset(Control.PRESET_TOP_WIDE); top.offset_bottom=132; ui.add_child(top)
    var topbox:=VBoxContainer.new(); top.add_child(topbox)
    title=Label.new(); title.text="NUSAPET"; title.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; title.add_theme_font_size_override("font_size",32); topbox.add_child(title)
    subtitle=Label.new(); subtitle.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; subtitle.add_theme_font_size_override("font_size",14); topbox.add_child(subtitle)
    status=Label.new(); status.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; status.add_theme_font_size_override("font_size",13); topbox.add_child(status)
    world_status=Label.new(); world_status.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; world_status.add_theme_font_size_override("font_size",11); topbox.add_child(world_status)
    var scroll:=ScrollContainer.new(); scroll.set_anchors_preset(Control.PRESET_FULL_RECT); scroll.offset_left=20; scroll.offset_top=145; scroll.offset_right=-20; scroll.offset_bottom=-190; ui.add_child(scroll)
    content=VBoxContainer.new(); content.size_flags_horizontal=Control.SIZE_EXPAND_FILL; content.add_theme_constant_override("separation",10); scroll.add_child(content)
    toast=Label.new(); toast.set_anchors_preset(Control.PRESET_BOTTOM_WIDE); toast.offset_top=-175; toast.offset_bottom=-125; toast.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; toast.add_theme_font_size_override("font_size",18); ui.add_child(toast)
    var nav:=HBoxContainer.new(); nav.set_anchors_preset(Control.PRESET_BOTTOM_WIDE); nav.offset_top=-110; nav.offset_bottom=-18; nav.add_theme_constant_override("separation",5); ui.add_child(nav)
    var nav_items=[["HOME","nav_home"],["EXPLORE","nav_explore"],["NUSAPEDIA","nav_nusapedia"],["COLLECTION","nav_collection"],["PROFILE","nav_profile"]]
    for item in nav_items:
        var b:=Button.new(); b.text=GameState.tr(item[1]); b.size_flags_horizontal=Control.SIZE_EXPAND_FILL; b.custom_minimum_size=Vector2(0,68); b.focus_mode=Control.FOCUS_ALL; b.tooltip_text=GameState.tr(item[1]); b.pressed.connect(_nav.bind(item[0])); nav.add_child(b); nav_buttons.append(b)

func _refresh()->void:
    if not ui: return
    _clear(content); var p:Dictionary=GameState.state.pet; var c:Dictionary=GameState.current_creature(); subtitle.text=GameState.tr("tagline")
    status.text=("♥ %s  •  %s  •  STAGE %d/6"%[p.nickname,p.personality,p.stage]) if p.hatched else GameState.tr("egg_status")
    if active_tab=="HOME": _draw_home(c,p)
    elif active_tab=="EXPLORE": _draw_explore()
    elif active_tab=="NUSAPEDIA": _draw_nusapedia()
    elif active_tab=="COLLECTION": _draw_collection()
    else: _draw_profile()
func _draw_home(c:Dictionary,p:Dictionary)->void:
    if not p.hatched:
        _card(GameState.tr("egg_title"),GameState.tr("egg_body"),true)
        name_input=LineEdit.new(); name_input.placeholder_text=GameState.tr("name_placeholder"); name_input.custom_minimum_size=Vector2(0,58); content.add_child(name_input)
        var hatch:=Button.new(); hatch.text=GameState.tr("hatch"); hatch.custom_minimum_size=Vector2(0,70); hatch.pressed.connect(_on_hatch_pressed); content.add_child(hatch)
        return
    _card("%s  •  %s"%[c.get("name_id","Creature"),str(c.get("scientific_name",""))],GameState.tr("home_hint"),false); _text_card("AGE • %s  •  FORM • %s\nEvolution forecast: %.0f%%\n%s"%[GameState.age_label(),str(p.form_id),GameState.evolution_forecast().progress*100.0," • ".join(GameState.evolution_hints())]); _stats_strip(p)
    if bool(p.get("offline_evolution_pending",false)):
        var reveal:=Button.new(); reveal.text=GameState.tr("reveal_evolution"); reveal.tooltip_text="Progress reached while offline. Evolution starts only after you choose to reveal it."; reveal.pressed.connect(_action.bind("evolve")); content.add_child(reveal)
    var actions:=GridContainer.new(); actions.columns=2; actions.add_theme_constant_override("h_separation",8); actions.add_theme_constant_override("v_separation",8); content.add_child(actions)
    for pair in [["FEED","feed"],["PLAY","play"],["CLEAN","clean"],["REST","sleep"]]:
        var b:=Button.new(); b.text=pair[0]; b.custom_minimum_size=Vector2(0,64); b.tooltip_text=pair[0]; b.pressed.connect(_action.bind(pair[1])); actions.add_child(b)
    var more:=Button.new(); more.text=GameState.tr("home_more"); more.custom_minimum_size=Vector2(0,60); more.pressed.connect(_show_advanced_care); content.add_child(more)
    if p.stage>=2:
        var evo:=Button.new(); evo.text="EVOLVE • %d/6"%p.stage; evo.custom_minimum_size=Vector2(0,60); evo.pressed.connect(_action.bind("evolve")); content.add_child(evo)
    if p.stage>=3:
        var network:=Button.new(); network.text=GameState.tr("evolution_network"); network.custom_minimum_size=Vector2(0,60); network.pressed.connect(_show_evolution_network); content.add_child(network)
    if not p.inventory.is_empty() and p.stage>=3:
        var pusaka:=Button.new(); pusaka.text="PUSAKA VAULT"; pusaka.custom_minimum_size=Vector2(0,60); pusaka.pressed.connect(_show_pusaka); content.add_child(pusaka)
    if p.stage>=4 and not p.current_armor.is_empty():
        var resonance:=Button.new(); resonance.text=GameState.tr("check_resonance"); resonance.custom_minimum_size=Vector2(0,60); resonance.pressed.connect(_action.bind("resonance")); content.add_child(resonance)
    var cams:=HBoxContainer.new(); content.add_child(cams)
    for mode in ["FOLLOW","FOCUS","INTERACTION","EXPLORATION","EVOLUTION"]:
        var cb:=Button.new(); cb.text=mode; cb.pressed.connect(_set_camera_mode.bind(mode)); cams.add_child(cb)
    var more:=Label.new(); more.text="Memory: %d  •  Research: %d  •  Rank: %s  •  Achievements: %d/%d"%[p.memories.size(),GameState.state.player.research,GameState.state.player.rank,GameState.state.achievements.size(),GameState.catalog.achievements.size()]; content.add_child(more)
    var quest:=Button.new(); quest.text="QUESTS • %d/%d"%[GameState.state.quests.completed.size(),GameState.catalog.quests.size()]; quest.pressed.connect(_show_quests); content.add_child(quest)
    var observe:=Button.new(); observe.text=GameState.tr("field_observation"); observe.tooltip_text="Tracks • sound • silhouette • habitat clue"; observe.pressed.connect(_on_observe_pressed); content.add_child(observe)
    var memory:=Button.new(); memory.text=GameState.tr("save_game_moment"); memory.pressed.connect(_on_memory_pressed); content.add_child(memory)
    var share:=Button.new(); share.text=GameState.tr("generate_share_card"); share.pressed.connect(_on_share_card_pressed); content.add_child(share)
func _stats_strip(p:Dictionary)->void:
    var box:=GridContainer.new(); box.columns=3; content.add_child(box)
    for k in ["hunger","hydration","happiness"]:
        var l:=Label.new(); l.text="%s\n%d"%[k.to_upper(),int(p.stats[k])]; l.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; l.custom_minimum_size=Vector2(0,50); box.add_child(l)
    var details:=Button.new(); details.text=GameState.tr("view_all_needs"); details.pressed.connect(_show_needs); content.add_child(details)
func _draw_explore()->void:
    _card("INDONESIA • FIELD RESEARCH","Pilih region, habitat dan durasi. Ekspedisi tetap berjalan saat offline.",false)
    var map:=GridContainer.new(); map.columns=3; content.add_child(map)
    for r in GameState.catalog.regions:
        var b:=Button.new(); var rid:=str(r.id); var unlocked:=GameState.is_region_unlocked(rid); b.text=(str(r.name_en) if unlocked else "🔒 "+str(r.name_en)); b.custom_minimum_size=Vector2(0,66); b.disabled=not unlocked; b.tooltip_text="Discovered" if unlocked else "Explore nearby regions to unlock"; b.pressed.connect(_select_region.bind(rid,str(r.name_en))); map.add_child(b)
    var weather:=HBoxContainer.new(); content.add_child(weather)
    for w in ["CLEAR","RAIN","STORM","FOG","HEAT","WIND"]:
        var b:=Button.new(); b.text=w; b.pressed.connect(_on_weather_pressed.bind(w)); weather.add_child(b)
    var duration:=OptionButton.new(); var labels=["5 MIN","15 MIN","30 MIN","1 HOUR","3 HOURS","8 HOURS"]
    for i in range(labels.size()): duration.add_item(labels[i],i)
    content.add_child(duration)
    var team:=Button.new(); team.text=GameState.tr("start_team"); team.pressed.connect(_on_team_expedition_pressed.bind(duration)); content.add_child(team)
    var go:=Button.new(); go.text=GameState.tr("start_expedition"); go.custom_minimum_size=Vector2(0,68); go.pressed.connect(_on_expedition_pressed.bind(duration)); content.add_child(go)
    var ex:Array=GameState.state.player.expeditions; var info:=Label.new(); info.text="Active: %d/2\nResearch: %d • Level: %s\nRegion mastery: %s"%[ex.size(),GameState.state.player.research,GameState.state.player.research_level,str(GameState.state.player.regional_mastery)]; content.add_child(info)
func _draw_nusapedia()->void:
    _card(GameState.tr("nusapedia"),GameState.tr("nusapedia_body"),false)
    var filter:=LineEdit.new(); filter.placeholder_text=GameState.tr("search_placeholder"); content.add_child(filter); var list:=VBoxContainer.new(); list.name="List"; content.add_child(list); filter.text_changed.connect(func(v): _fill_nusapedia_list(list,v)); _fill_nusapedia_list(list,"")
func _fill_nusapedia_list(list:VBoxContainer,q:String)->void:
    for child in list.get_children(): child.queue_free()
    var count:=0; var query:=q.to_lower()
    for c in GameState.catalog.creatures:
        var hay:="%s %s %s %s %s"%[c.get("name_id",""),c.get("name_en",""),c.get("scientific_name",""),c.get("category",""),str(c.get("factual_data",{}).get("region",""))]
        if query!="" and query not in hay.to_lower(): continue
        var b:=Button.new(); b.text="%s  •  %s"%[c.name_id,c.category]; b.alignment=HORIZONTAL_ALIGNMENT_LEFT; b.custom_minimum_size=Vector2(0,54); b.pressed.connect(_show_creature.bind(str(c.id))); list.add_child(b); count+=1
        if count>=60: break
func _show_creature(id:String)->void:
    selected_creature_id=id; var c:Dictionary=GameState.encyclopedia_entry(id); _clear(content)
    _card(str(c.get("name_id","")),"%s\n%s"%[str(c.get("name_en","")),str(c.get("category",""))],false)
    if c.get("category")=="REAL": _draw_real_entry(c)
    else: _draw_cultural_entry(c)
    var back:=Button.new(); back.text=GameState.tr("back_nusapedia"); back.pressed.connect(func(): _nav(GameState.tr("nusapedia"))); content.add_child(back)
func _draw_real_entry(c:Dictionary)->void:
    var t:Dictionary=c.get("factual_data",{}).get("taxonomy",{}); var rr:Dictionary=c.get("research_record",{})
    var scientific:=str(c.get("scientific_name",""))
    var text:="%s\n\n%s\n%s\n\n%s\nKingdom: %s\nPhylum: %s\nClass: %s\nOrder: %s\nFamily: %s\nGenus: %s\nSpecies: %s\nRank: %s\n\nResearch status: %s\n%s: %s\n%s: %s\n%s: %s\n%s: %s"%[GameState.tr("real_species"),GameState.tr("scientific_label")%scientific,GameState.tr("game_forms"),GameState.tr("taxonomy"),t.get("kingdom",""),t.get("phylum",""),t.get("class",""),t.get("order",""),t.get("family",""),t.get("genus",""),t.get("species",""),t.get("rank",""),rr.get("status","REVIEW_REQUIRED"),GameState.tr("source_confidence_label"),rr.get("source_confidence","REVIEW"),GameState.tr("conservation_label"),str(rr.get("conservation_status",GameState.tr("conservation_unverified"))),GameState.tr("distribution_coarse"),str(rr.get("distribution_regions",[])),GameState.tr("habitat_label"),str(rr.get("habitats",[]))]
    _text_card(text)
    if GameState.scientific_name_is_valid(scientific): _scientific_card(scientific)
    _text_card(GameState.tr("research_level")+"\nDISCOVERED → OBSERVED → RESEARCHED → MASTERED\n"+GameState.tr("research_entry")%GameState.research_level_for(str(c.get("id",""))))
    _text_card(GameState.tr("game_forms")+"\n"+GameState.tr("real_vs_game_note"))
    var obs:=Button.new(); obs.text=GameState.tr("observe_clue"); obs.pressed.connect(_start_observation_challenge.bind(str(c.get("id","")))); content.add_child(obs)
    _text_card(GameState.tr("references")+"\n"+_reference_text(c.get("references",[])))
func _draw_cultural_entry(c:Dictionary)->void:
    var cr:Dictionary=c.get("cultural_review",{}); _text_card("TRADITION / FOLKLORE\nRegion: %s\nTradition: %s\nCategory: %s\nFraming: %s\nReview: %s\nConfidence: %s"%[cr.get("region",""),cr.get("tradition",""),cr.get("category",c.get("category","")),cr.get("framing","Folklore / Traditional Belief / Cultural Narrative"),cr.get("status","REVIEW_REQUIRED"),cr.get("source_confidence","REVIEW")]); _text_card("GAME LORE\nThis entry's evolution/Armor/Resonance content is original NusaPet game lore and must not be interpreted as a factual supernatural claim.")
func _reference_text(refs:Array)->String:
    if refs.is_empty(): return GameState.tr("sources_unavailable")
    var out:=""
    for r in refs:
        var year:=str(r.get("year","")); if year.is_empty(): year=GameState.tr("source_date_unavailable")
        out+=str(r.get("source",""))+" — "+GameState.tr("source_purpose")+": "+str(r.get("purpose",""))+" — "+GameState.tr("year")+": "+year+"\n"+str(r.get("url",""))+"\n"
    return out
func _draw_collection()->void:
    var col:Dictionary=GameState.state.collection; _card(GameState.tr("collection"),GameState.tr("collection_body"),false); _text_card("Species %d/350\nPrimary Forms %d/2100\nArmor %d/700\nCross Branch %d/350\nPusaka %d/15\nResonance %d\nDual Resonance %d"%[col.species.size(),col.forms.size(),col.armor.size(),col.cross_paths.size(),col.artifacts.size(),col.resonance.size(),col.dual_resonance.size()]); var b:=Button.new(); b.text=GameState.tr("open_pusaka"); b.pressed.connect(_show_pusaka); content.add_child(b); var archive:=Button.new(); archive.text=GameState.tr("legacy_archive"); archive.pressed.connect(func(): _show_legacy()); content.add_child(archive); var sanctuary:=Button.new(); sanctuary.text=GameState.tr("sanctuary")%[GameState.state.sanctuary.companions.size(),GameState.state.sanctuary.get("capacity",3)]; sanctuary.pressed.connect(_show_sanctuary); content.add_child(sanctuary)
func _show_pusaka()->void:
    _clear(content); _card("PUSAKA VAULT","GAME ARTIFACTS • Temporary transformation • no paid lootbox",false)
    for id in GameState.state.pet.inventory:
        var a:Dictionary=GameState._artifact(str(id)); var mastery:=int(GameState.state.pet.artifact_mastery.get(id,0)); var b:=Button.new(); b.text="%s • %s • Mastery %d"%[str(a.get("affinity","")),str(a.get("rarity","")),mastery]; b.pressed.connect(_on_transform_pressed.bind(str(id))); content.add_child(b)
    if not GameState.state.pet.current_armor.is_empty():
        _text_card("ACTIVE ARMOR\nPusaka: %s\nAffinity: %s\nMastery: %d\nEnergy: %d"%[GameState.state.pet.current_armor,GameState.armor_affinity(GameState.state.pet.current_armor),int(GameState.state.pet.artifact_mastery.get(GameState._armor_artifact_affinity(GameState.armor_affinity(GameState.state.pet.current_armor)),0)),int(GameState.state.pet.stats.resonance)])
        var rev:=Button.new(); rev.text=GameState.tr("armor_revert"); rev.pressed.connect(_on_revert_armor_pressed); content.add_child(rev)
    var back:=Button.new(); back.text=GameState.tr("back_collection"); back.pressed.connect(func(): _nav("COLLECTION")); content.add_child(back)
func _show_legacy()->void:
    _clear(content); _card(GameState.tr("legacy_archive"),"Previous companions become memories, not disposable storage.",false); _text_card("Archived companions: %d\nCurrent companion: %s\nInheritance: %s"%[GameState.state.legacy.archive.size(),GameState.state.pet.nickname,str(GameState.state.legacy.inheritance)])
    if GameState.can_start_new_generation():
        var next:=Button.new(); next.text="START NEW COMPANION • INHERIT LEGACY"; next.pressed.connect(func():
            if GameState.start_new_generation():
                _spawn_creature(); _refresh()
        ); content.add_child(next)
    var back:=Button.new(); back.text=GameState.tr("back_collection"); back.pressed.connect(func(): _nav("COLLECTION")); content.add_child(back)
func _draw_profile()->void:
    var p:Dictionary=GameState.state.pet; _card("PROFILE • %s"%GameState.state.player.name,"Rank: %s • Research: %d • Memories: %d"%[GameState.state.player.rank,GameState.state.player.research,p.memories.size()],false)
    _text_card("Rare visual trait: %s" % (", ".join(p.get("rare_traits",[])) if not p.get("rare_traits",[]).is_empty() else "None"))
    var lang:=OptionButton.new(); lang.add_item("Bahasa Indonesia",0); lang.add_item("English",1); lang.selected=0 if GameState.lang=="id" else 1; lang.item_selected.connect(func(i): GameState.set_language("id" if i==0 else "en")); content.add_child(lang)
    var reduced:=CheckButton.new(); reduced.text=GameState.tr("reduced_motion"); reduced.button_pressed=GameState.state.settings.reduced_motion; reduced.toggled.connect(func(v): GameState.state.settings.reduced_motion=v; RuntimePerformance.apply(str(GameState.state.settings.get("quality","BALANCED")),v); GameState.save_game()); content.add_child(reduced)
    var music:=CheckButton.new(); music.text=GameState.tr("music"); music.button_pressed=bool(GameState.state.settings.music); music.toggled.connect(func(v): GameState.state.settings.music=v; AudioManager.set_bus_enabled("MUSIC",v); GameState.save_game()); content.add_child(music)
    var sfx:=CheckButton.new(); sfx.text=GameState.tr("sfx"); sfx.button_pressed=bool(GameState.state.settings.sfx); sfx.toggled.connect(func(v): GameState.state.settings.sfx=v; AudioManager.set_bus_enabled("SFX",v); GameState.save_game()); content.add_child(sfx)
    var haptic:=CheckButton.new(); haptic.text=GameState.tr("haptic"); haptic.button_pressed=bool(GameState.state.settings.haptic); haptic.toggled.connect(func(v): GameState.state.settings.haptic=v; GameState.save_game()); content.add_child(haptic)
    var quality:=OptionButton.new(); for q in ["HIGH","BALANCED","BATTERY_SAVER","LOW_STORAGE"]: quality.add_item(q); quality.selected=max(0,["HIGH","BALANCED","BATTERY_SAVER","LOW_STORAGE"].find(str(GameState.state.settings.quality))); quality.item_selected.connect(func(i): GameState.set_quality(quality.get_item_text(i)); RuntimePerformance.apply(quality.get_item_text(i),bool(GameState.state.settings.get("reduced_motion",false)))); content.add_child(quality)
    var scale:=HSlider.new(); scale.min_value=.85; scale.max_value=1.6; scale.step=.05; scale.value=float(GameState.state.settings.text_scale); scale.tooltip_text=GameState.tr("text_scale"); scale.value_changed.connect(func(v): GameState.set_text_scale(v)); content.add_child(scale)
    var perfect:=Button.new(); perfect.text=GameState.tr("perfect_resonance"); perfect.pressed.connect(func(): GameState.try_perfect_resonance()); content.add_child(perfect)
    var export_btn:=Button.new(); export_btn.text=GameState.tr("export_save"); export_btn.tooltip_text=GameState.tr("save_path_help"); export_btn.pressed.connect(func(): GameState.export_save("user://save/nusapet_export.json")); content.add_child(export_btn)
    _text_card(GameState.tr("local_first_status")%[GameState.CONTENT_VERSION,GameState.VERSION])
    var storage:=Button.new(); storage.text=GameState.tr("storage_manager"); storage.pressed.connect(_show_storage_manager); content.add_child(storage)
    var save:=Button.new(); save.text=GameState.tr("save_now"); save.pressed.connect(func(): GameState.save_game()); content.add_child(save)


func _show_storage_manager()->void:
    _clear(content)
    var st:Dictionary=GameState.storage_status()
    _card(GameState.tr("storage_manager"),GameState.tr("storage_usage")%[int(st.get("save_bytes",0)),int(st.get("optional_cache_bytes",0)),str(st.get("asset_pack","CORE"))],false)
    _text_card(GameState.tr("downloaded_regions")+"\n"+str(GameState.state.collection.regions))
    _text_card(GameState.tr("audio_quality")+"\n"+str(GameState.state.settings.get("quality","BALANCED")))
    _text_card(GameState.tr("clear_optional_body"))
    var clear:=Button.new(); clear.text=GameState.tr("clear_optional_assets"); clear.pressed.connect(_on_clear_optional_assets_pressed); content.add_child(clear)
    var back:=Button.new(); back.text=GameState.tr("back_home"); back.pressed.connect(_nav.bind("HOME")); content.add_child(back)

func _on_clear_optional_assets_pressed()->void:
    _toast(GameState.tr("optional_cleared") if GameState.clear_optional_assets() else GameState.tr("optional_clear_failed"))
    _show_storage_manager()

func _show_evolution_network()->void:
    _clear(content)
    _card("GAME EVOLUTION NETWORK",GameState.tr("evolution_network_body"),false)
    var graph:=GraphEdit.new()
    graph.custom_minimum_size=Vector2(0,520)
    graph.show_grid=true
    graph.right_disconnects=true
    graph.snapping_enabled=true
    graph.snapping_distance=32
    content.add_child(graph)
    var p:Dictionary=GameState.state.pet
    var line:=str(p.get("current_line_id",p.get("creature_id","")))
    var discovered:Array=p.get("discovered_branches",[])
    var forms:=[]
    for stage in range(1,7): forms.append(line+"_s"+str(stage))
    for i in range(forms.size()):
        var node:=GraphNode.new()
        node.name="Known_%s"%str(forms[i]).replace("-","_")
        node.title=str(forms[i]) if i<=p.stage else "???"
        node.position_offset=Vector2(40+i*150,120)
        node.resizable=false
        graph.add_child(node)
        if i>0: graph.connect_node("Known_%s"%str(forms[i-1]).replace("-","_"),0,node.name,0)
    var branch_index:=0
    for e in GameState.catalog.cross:
        if str(e.get("source",""))!=str(p.form_id): continue
        var target:=str(e.get("target",""))
        var target_line:=target.rsplit("_s",1)[0]
        var known:=target_line in discovered or target_line==line
        var node:=GraphNode.new()
        node.name="Branch_%d"%branch_index
        node.title=target if known else "???"
        node.position_offset=Vector2(180+branch_index*180,330)
        node.resizable=false
        graph.add_child(node)
        graph.connect_node("Known_%s"%str(p.form_id).replace("-","_"),0,node.name,0)
        branch_index+=1
        if branch_index>=6: break
    var hints:=GameState.evolution_hints()
    _text_card("RUMOR / HINT\n"+"\n".join(hints))
    var back:=Button.new(); back.text=GameState.tr("back_home"); back.pressed.connect(_nav.bind("HOME")); content.add_child(back)

func _choose_evolution_option(edge_id:String)->void:
    if GameState.choose_evolution_branch(edge_id):
        GameState.haptic_feedback(80,0.8)
        _spawn_creature(); _refresh()

func _show_food_menu()->void:
    _clear(content)
    var p:Dictionary=GameState.state.pet
    var pref:=str(p.get("preferences",{}).get("food",""))
    _card(GameState.tr("food_menu"),GameState.tr("food_menu_body"),false)
    _text_card("%s: %s"%[GameState.tr("favorite_food"),pref if not pref.is_empty() else "—"])
    var c:Dictionary=GameState.current_creature()
    for food in GameState.catalog.food:
        var id:=str(food.get("id","")); var name:=str(food.get("name_id",id) if GameState.lang=="id" else food.get("name_en",id))
        var b:=Button.new(); b.text=("★ " if id==pref else "")+name; b.custom_minimum_size=Vector2(0,60)
        b.tooltip_text=GameState.tr("food_research_blocked") if str(c.get("category",""))=="REAL" and not GameState.food_is_diet_compatible(str(c.get("id","")),id) else GameState.tr("food_selected")
        b.pressed.connect(_feed_selected_food.bind(id)); content.add_child(b)
    var back:=Button.new(); back.text=GameState.tr("back_home"); back.pressed.connect(_nav.bind("HOME")); content.add_child(back)

func _feed_selected_food(food_id:String)->void:
    if GameState.feed_food(food_id):
        _show_care_prop("feed",food_id)
        GameState.haptic_feedback(35,0.45)
        _toast(GameState.tr("feed_food")+" • "+food_id)
        _nav("HOME")
    else:
        _toast(GameState.tr("food_research_blocked"))

func _show_advanced_care()->void:
    _clear(content)
    _card(GameState.tr("care_training"),GameState.tr("advanced_care_body"),false)
    for pair in [[GameState.tr("advanced_drink"),"drink"],[GameState.tr("advanced_pet"),"pet"],[GameState.tr("advanced_train"),"train"],[GameState.tr("advanced_heal"),"heal"]]:
        var b:=Button.new(); b.text=pair[0]; b.custom_minimum_size=Vector2(0,60); b.pressed.connect(_action.bind(pair[1])); content.add_child(b)
    var observe:=Button.new(); observe.text=GameState.tr("advanced_learn"); observe.pressed.connect(_start_observation_challenge.bind(str(GameState.state.pet.current_line_id))); content.add_child(observe)
    var back:=Button.new(); back.text=GameState.tr("back_home"); back.pressed.connect(_nav.bind("HOME")); content.add_child(back)

func _show_needs()->void:
    _clear(content)
    _card(GameState.tr("creature_needs"),GameState.tr("needs_body"),false)
    _stats_strip_detailed(GameState.state.pet)
    var back:=Button.new(); back.text=GameState.tr("back_home"); back.pressed.connect(_nav.bind("HOME")); content.add_child(back)

func _stats_strip_detailed(p:Dictionary)->void:
    var box:=GridContainer.new(); box.columns=2; content.add_child(box)
    for k in ["hp","energy","hunger","hydration","happiness","health","cleanliness","discipline","intelligence","affection","stress","curiosity","bond","resonance"]:
        var l:=Label.new(); l.text="%s: %d"%[k.to_upper(),int(p.stats.get(k,0))]; l.custom_minimum_size=Vector2(0,44); box.add_child(l)

func _on_weather_pressed(value:String)->void:
    GameState.set_weather(value)
    if world:
        world.set_weather(value)
    _toast(GameState.tr("weather_toast")%value)

func _start_observation_challenge(id:String="")->void:
    var challenge:Dictionary=GameState.begin_observation_challenge(id)
    if challenge.is_empty(): return
    if observation_modal and is_instance_valid(observation_modal): observation_modal.queue_free()
    observation_modal=PanelContainer.new()
    observation_modal.set_anchors_preset(Control.PRESET_CENTER)
    observation_modal.custom_minimum_size=Vector2(420,360)
    ui.add_child(observation_modal)
    var box:=VBoxContainer.new(); box.add_theme_constant_override("separation",12); observation_modal.add_child(box)
    var heading:=Label.new(); heading.text="FIELD OBSERVATION"; heading.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER; heading.add_theme_font_size_override("font_size",24); box.add_child(heading)
    var clue:=Label.new(); clue.text="Perhatikan petunjuk habitat/jejak/suara/siluet. Pilih interpretasi observasi yang paling tepat."; clue.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; box.add_child(clue)
    for option in challenge.get("options",[]):
        var b:=Button.new(); b.text=str(option); b.custom_minimum_size=Vector2(0,56); b.pressed.connect(_submit_observation.bind(str(option))); box.add_child(b)
    var cancel:=Button.new(); cancel.text=GameState.tr("cancel"); cancel.pressed.connect(_cancel_observation); box.add_child(cancel)

func _submit_observation(answer:String)->void:
    var ok:=GameState.submit_observation_challenge(answer)
    if observation_modal and is_instance_valid(observation_modal): observation_modal.queue_free()
    observation_modal=null
    _toast("Observation berhasil • +4 Research" if ok else "Observasi belum tepat • coba lagi saat menemukan petunjuk baru")
    _refresh()

func _cancel_observation()->void:
    GameState.state.meta.observation_challenge={}
    GameState.save_game()
    if observation_modal and is_instance_valid(observation_modal): observation_modal.queue_free()
    observation_modal=null

func _on_observe_entry_pressed(id:String)->void:
    GameState.observe_field_clue(id)
    _show_creature(id)

func _on_revert_armor_pressed()->void:
    GameState.revert_armor()
    _spawn_creature()
    _refresh()

func _on_creature_interacted(action:String)->void:
    if action != "tap" or not GameState.state.pet.hatched:
        return
    _set_camera_mode("FOCUS")
    if GameState.act("pet"):
        var controller:=creature_root.get_node_or_null("AnimationController") as NusaCreatureAnimationController
        if controller:
            controller.play_state("Happy")
        _show_care_prop("pet")
        GameState.haptic_feedback(35,0.45)
        _toast(GameState.tr("creature_interacted"))

func _on_hatch_pressed()->void:
    if not name_input.text.strip_edges().is_empty(): GameState.rename_pet(name_input.text)
    if GameState.hatch():
        _spawn_creature()
        _refresh()

func _on_observe_pressed()->void:
    if GameState.observe_field_clue(): _refresh()

func _on_memory_pressed()->void:
    var path:=GameState.save_screenshot_memory()
    _toast(GameState.tr("memory_saved") if path!="" else GameState.tr("memory_unavailable"))

func _on_share_card_pressed()->void:
    var card:=NusaShareCard.new()
    add_child(card)
    var portrait:=get_viewport().get_texture().get_image()
    if not portrait.is_empty():
        var side:=min(min(portrait.get_width(),portrait.get_height()),640)
        var src:=Rect2i((portrait.get_width()-side)/2,(portrait.get_height()-side)/2,side,side)
        portrait=portrait.get_region(src)
    var path:=await card.generate(GameState.state.pet,GameState.current_creature(),str(GameState.state.player.get("selected_region","")),portrait)
    card.queue_free()
    _toast("Share card saved" if path!="" else "Share card unavailable")

func _on_team_expedition_pressed(duration:OptionButton)->void:
    if GameState.start_team_expedition(duration.get_selected_id()): _refresh()

func _on_expedition_pressed(duration:OptionButton)->void:
    if GameState.start_expedition(duration.get_selected_id()): _refresh()

func _on_transform_pressed(id:String)->void:
    if GameState.transform(id):
        _spawn_creature()
        _refresh()

func _on_store_companion_pressed()->void:
    if GameState.add_companion_from_current(): _refresh()

func _on_switch_companion_pressed(index:int)->void:
    if GameState.switch_companion(index):
        _spawn_creature()
        _refresh()

func _on_archive_pressed()->void:
    if GameState.archive_current_to_legacy(): _toast(GameState.tr("legacy_saved"))

func _on_toast_timeout()->void:
    if is_instance_valid(toast): toast.text=""

func _set_camera_mode(mode:String)->void:
    camera_mode=mode
    var target_zoom:=11.5
    match mode:
        "FOLLOW": target_zoom=11.5
        "FOCUS": target_zoom=7.0
        "INTERACTION": target_zoom=4.8
        "EXPLORATION": target_zoom=15.0
        "EVOLUTION": target_zoom=10.0
    if camera_tween != null and camera_tween.is_valid():
        camera_tween.kill()
    camera_tween=create_tween()
    camera_tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
    camera_tween.tween_property(self,"camera_zoom",target_zoom,0.35)
    camera_tween.tween_callback(_apply_camera_orbit)

func _show_quests()->void:
    _clear(content); _card(GameState.tr("quests"),GameState.tr("progress_summary_body"),false)
    for q in GameState.catalog.quests:
        var qid:=str(q.id); var done:=qid in GameState.state.quests.completed; var name:=str(q.name_id if GameState.lang=="id" else q.name_en); var b:=Button.new(); b.text=("✓ " if done else "○ ")+name; b.disabled=done; b.tooltip_text=str(q.get("type","")); content.add_child(b)
    var a:=Button.new(); a.text="ACHIEVEMENTS %d/%d"%[GameState.state.achievements.size(),GameState.catalog.achievements.size()]; a.pressed.connect(_show_achievements); content.add_child(a)
    var back:=Button.new(); back.text=GameState.tr("back_home"); back.pressed.connect(func(): _nav("HOME")); content.add_child(back)

func _show_achievements()->void:
    _clear(content); _card(GameState.tr("achievements"),GameState.tr("milestones"),false)
    for a in GameState.catalog.achievements:
        var id:=str(a.id); var done:=id in GameState.state.achievements; var name:=str(a.name_id if GameState.lang=="id" else a.name_en); var l:=Label.new(); l.text=("✓ " if done else "○ ")+name; l.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART; content.add_child(l)
    var back:=Button.new(); back.text="← QUESTS"; back.pressed.connect(_show_quests); content.add_child(back)

func _show_sanctuary()->void:
    _build_sanctuary_visuals()
    _clear(content); _card("SANCTUARY","A quiet place for companions, legacy and multi-generation discovery.",false)
    var s:Dictionary=GameState.state.sanctuary; _text_card("Active companion: %s\nStored companions: %d/%d\nLegacy archive: %d"%[GameState.state.pet.nickname,s.companions.size(),s.get("capacity",3),GameState.state.legacy.archive.size()])
    if s.companions.is_empty():
        var add:=Button.new(); add.text=GameState.tr("store_companion"); add.pressed.connect(_on_store_companion_pressed); content.add_child(add)
    else:
        for i in range(s.companions.size()):
            var c:Dictionary=s.companions[i]; var b:=Button.new(); b.text="%d • %s • STAGE %d • %s"%[i+1,str(c.get("nickname","Companion")),int(c.get("stage",1)),str(c.get("personality","Unknown"))]; b.pressed.connect(_on_switch_companion_pressed.bind(i)); content.add_child(b)
    var arch:=Button.new(); arch.text=GameState.tr("archive_current"); arch.pressed.connect(_on_archive_pressed); content.add_child(arch)
    var back:=Button.new(); back.text=GameState.tr("back_collection"); back.pressed.connect(func(): _nav("COLLECTION")); content.add_child(back)

func _build_sanctuary_visuals()->void:
    if sanctuary_visual_root and is_instance_valid(sanctuary_visual_root):
        sanctuary_visual_root.queue_free()
    sanctuary_visual_root=Node3D.new()
    sanctuary_visual_root.name="SanctuaryLivingCompanions"
    add_child(sanctuary_visual_root)
    var companions:Array=GameState.state.sanctuary.get("companions",[])
    var visible_count:=min(3,companions.size())
    for i in range(visible_count):
        var snapshot:Dictionary=companions[i]
        var scene:=preload("res://scenes/creature/Creature.tscn").instantiate()
        sanctuary_visual_root.add_child(scene)
        scene.position=Vector3(-3.2+float(i)*3.2,1.0,2.4+float(i%2)*.8)
        var cid:=str(snapshot.get("creature_id",snapshot.get("current_line_id","")))
        var form_id:=str(snapshot.get("form_id",cid+"_s1"))
        var c:=GameState.encyclopedia_entry(cid)
        var f:=GameState.form_record(form_id)
        scene.configure(c,f,snapshot)
        if scene.has_signal("creature_interacted"):
            scene.creature_interacted.connect(func(_action): pass)

func _text_card(t:String)->void: _card("",t,false)
func _scientific_card(name:String)->void:
    var panel:=PanelContainer.new(); panel.custom_minimum_size=Vector2(0,56); content.add_child(panel)
    var rich:=RichTextLabel.new(); rich.bbcode_enabled=true; rich.fit_content=true; rich.text="[i]"+name+"[/i]"; rich.add_theme_font_size_override("normal_font_size",18); panel.add_child(rich)
func _show_care_prop(action:String, food_id:String="")->void:
    if care_prop: care_prop.queue_free()
    care_prop=Node3D.new()
    care_prop.name="3D_CareInteraction"
    add_child(care_prop)
    care_prop.position=Vector3(0,1.0,2.1)
    var mesh:=MeshInstance3D.new()
    var mat:=StandardMaterial3D.new(); mat.roughness=.55
    if action=="feed":
        if food_id in ["fruit","nectar"]:
            var sphere:=SphereMesh.new(); sphere.radius=.30; sphere.height=.52; mesh.mesh=sphere; mat.albedo_color=Color("d6b36b")
        elif food_id in ["fish","meat"]:
            var capsule:=CapsuleMesh.new(); capsule.radius=.18; capsule.height=.75; mesh.mesh=capsule; mat.albedo_color=Color("b87966")
        elif food_id=="leaf":
            var leaf:=BoxMesh.new(); leaf.size=Vector3(.62,.06,.32); mesh.mesh=leaf; mat.albedo_color=Color("6f9b5f")
        elif food_id=="insect":
            var insect:=SphereMesh.new(); insect.radius=.18; insect.height=.28; mesh.mesh=insect; mat.albedo_color=Color("66594c")
        else:
            var bowl:=CylinderMesh.new(); bowl.top_radius=.30; bowl.bottom_radius=.34; bowl.height=.18; mesh.mesh=bowl; mat.albedo_color=Color("c5a76a")
    else:
        var sphere:=SphereMesh.new(); sphere.radius=.28; sphere.height=.56; mesh.mesh=sphere; mat.albedo_color=Color("d6b36b")
    mesh.material_override=mat; care_prop.add_child(mesh)
    var tween:=create_tween(); tween.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)
    tween.tween_property(care_prop,"position",Vector3(0,1.35,0.9),0.35)
    tween.tween_property(care_prop,"position",Vector3(0,1.0,2.1),0.35)
    tween.tween_callback(care_prop.queue_free)

func _action(a:String)->void:
    if a == "feed":
        _show_food_menu()
        return
    match a:
        "evolve": GameState.evolve()
        "pusaka": _show_pusaka(); return
        "resonance":
            # Resonance is a production system; the experimental flag only gates unfinished variants.
            GameState.check_resonance()
        _: GameState.act(a)
    if a in ["feed","drink","play","clean","pet","train","heal","sleep","learn"]:
        _show_care_prop(a)
        GameState.haptic_feedback(24,0.35)
    _spawn_creature(); _refresh()
func _select_region(id:String,label:String)->void:
    if not GameState.discover_region(id): return
    GameState.set_world_region(id); world.set_region(label); GameState.state.world.habitat=world.habitat; GameState.save_game(); _toast(GameState.tr("region_toast")%label); _refresh()
func _nav(n:String)->void:
    active_tab=n
    if n!="COLLECTION" and sanctuary_visual_root and is_instance_valid(sanctuary_visual_root):
        sanctuary_visual_root.queue_free(); sanctuary_visual_root=null
    if map_root: map_root.visible=(n=="EXPLORE")
    if n=="EXPLORE": _set_camera_mode("EXPLORATION")
    elif n=="HOME": _set_camera_mode("FOLLOW")
    _refresh()
func _on_state_changed()->void:
    var stage_now:=int(GameState.state.pet.get("stage",1))
    if stage_now!=_last_presented_stage and GameState.state.pet.get("hatched",false):
        _last_presented_stage=stage_now
        if evolution_presentation:
            evolution_presentation.setup(creature_root)
            evolution_presentation.trigger(GameState.state.pet.get("evolution_signature",{}))
    _refresh()
    if AssetPrefetcher:
        AssetPrefetcher.prefetch_for_current_state()
func _card(head:String,body:String,centered:bool)->void:
    var panel:=PanelContainer.new()
    panel.custom_minimum_size=Vector2(0,120)
    content.add_child(panel)
    var box:=VBoxContainer.new()
    panel.add_child(box)
    if head!="":
        var h:=Label.new()
        h.text=head
        h.add_theme_font_size_override("font_size",20)
        h.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER if centered else HORIZONTAL_ALIGNMENT_LEFT
        box.add_child(h)
    var b:=Label.new()
    b.text=body
    b.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    b.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER if centered else HORIZONTAL_ALIGNMENT_LEFT
    box.add_child(b)
func _clear(node:Node)->void:
    for child in node.get_children(): child.queue_free()
func _toast(t:String)->void:
    toast.text=t; AudioManager.play_generated_tone("UI",440.0,.06); var timer:=get_tree().create_timer(2.5); timer.timeout.connect(_on_toast_timeout)
