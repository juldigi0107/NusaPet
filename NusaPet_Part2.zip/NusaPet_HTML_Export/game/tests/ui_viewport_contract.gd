extends Node
## Native runtime UI overlap/text-expansion probe. Execute inside a Godot test scene.
const VIEWPORTS := [Vector2i(320,568),Vector2i(375,667),Vector2i(390,844),Vector2i(430,932),Vector2i(768,1024),Vector2i(1080,1920)]

func run_probe(root: Node) -> Dictionary:
    var report := {"passed":true,"viewports":{}}
    for size in VIEWPORTS:
        var result := _probe_tree(root, size)
        report.viewports["%dx%d"%[size.x,size.y]] = result
        if not bool(result.get("passed",false)):
            report.passed=false
    return report

func _probe_tree(root: Node, size: Vector2i) -> Dictionary:
    var failures:Array=[]
    for node in root.find_children("*", "Control", true, false):
        var c:=node as Control
        if c == null or not c.is_visible_in_tree(): continue
        var rect:=c.get_global_rect()
        if rect.position.x < -2 or rect.position.y < -2 or rect.end.x > size.x+2 or rect.end.y > size.y+2:
            failures.append(str(c.get_path()))
    return {"passed":failures.is_empty(),"overflow_nodes":failures}
