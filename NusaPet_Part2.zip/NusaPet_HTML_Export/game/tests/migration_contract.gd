extends SceneTree

func _init() -> void:
    var gs = preload("res://scripts/core/GameState.gd").new()
    gs._load_content()
    var v1 := {"version": 1, "language": "id", "pet": {"creature_id": "real_001", "stage": 1, "stats": {"hunger": 50}, "dna": {"care": 0}}}
    var v2 := {"version": 2, "language": "en", "pet": {"creature_id": "real_001", "stage": 2, "stats": {"hunger": 60}, "dna": {"care": 5}, "personality": "Curious"}, "player": {"research": 4, "selected_region": "sumatra"}}
    for fixture in [v1, v2]:
        var migrated: Dictionary = gs._migrate(fixture)
        assert(migrated.has("world"))
        assert(migrated.has("legacy"))
        assert(migrated.has("sanctuary"))
        assert(migrated.has("pet"))
        assert(migrated.pet.has("pending_evolution_choice"))
        assert(migrated.pet.has("rare_traits"))
        assert(migrated.player.has("research_observation_counts"))
    print("MIGRATION CONTRACT PASS")
    quit(0)
