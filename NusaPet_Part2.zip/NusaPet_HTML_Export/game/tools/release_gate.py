#!/usr/bin/env python3
import json,os,subprocess,sys,shlex
ROOT='.'
checks=[]
def run(name,cmd,blocking=True):
    p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
    checks.append({'name':name,'status':'PASS' if p.returncode==0 else ('BLOCKED' if blocking else 'WARN'),'returncode':p.returncode,'stdout':p.stdout[-3000:],'stderr':p.stderr[-3000:]})
    return p.returncode==0
run('content audit',['python3','tools/content_audit.py'])
run('evolution graph audit',['python3','tools/evolution_graph_audit.py'])
run('pusaka audit',['python3','tools/pusaka_audit.py'])
run('asset audit',['python3','tools/asset_audit.py'])
run('localization gate',['python3','tools/localization_gate.py'])
run('research gate',['python3','tools/research_gate.py'])
run('cultural gate',['python3','tools/cultural_gate.py'])
godot=shlex.split(os.environ.get('GODOT_BIN','godot'))
if subprocess.run(['bash','-lc',f'command -v {godot[0]} >/dev/null 2>&1']).returncode==0:
    run('Godot content validator',godot+['--headless','--path','.','--script','res://tests/validate_content.gd'])
    run('Godot unit tests',godot+['--headless','--path','.','--script','res://tests/run_unit_tests.gd'])
else:
    checks.append({'name':'Godot runtime','status':'BLOCKED','detail':'Godot 4.x executable not present in this environment'})
# Native exports cannot be truthfully marked pass without toolchain/device evidence.
for target in ['Android','iOS','Desktop']:
    checks.append({'name':f'{target} native export/device E2E','status':'BLOCKED','detail':'Requires native toolchain and representative device/CI artifact'})
report={'project':'NusaPet','checks':checks,'release_ready':all(c['status']=='PASS' for c in checks),'policy':'No fake completion; blocked gates remain blocked.'}
json.dump(report,open('data/release_readiness.json','w'),indent=2,ensure_ascii=False)
print(json.dumps(report,indent=2,ensure_ascii=False))
sys.exit(0 if report['release_ready'] else 2)
