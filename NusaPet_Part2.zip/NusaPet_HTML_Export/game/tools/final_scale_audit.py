#!/usr/bin/env python3
import json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
def load(p): return json.loads((ROOT/p).read_text(encoding='utf-8'))
creatures=load('data/creatures/creatures.json')
forms=load('data/evolutions/primary_forms.json')
armor=load('data/armor-forms/armor_forms.json')
assets=load('data/assets/asset_manifest.json')
errors=[]
if len(creatures)!=350: errors.append(f'creatures={len(creatures)}')
if len(forms)!=2100: errors.append(f'primary_forms={len(forms)}')
if len(armor)<700: errors.append(f'armor={len(armor)}')
paths=[str(x.get('resource_path','')) for x in assets.get('items',[])]
if not paths: errors.append('asset manifest empty')
# Scale safety: manifests describe assets; startup code must not instantiate every asset.
main=(ROOT/'scripts/main.gd').read_text(encoding='utf-8')
if 'load(' in main and 'asset_manifest' in main and 'for ' in main: pass
forbidden=['preload("res://assets/generated/creatures/"','preload("res://assets/generated/armor/"']
for f in forbidden:
    if f in main: errors.append('bulk preload pattern '+f)
print(json.dumps({'creatures':len(creatures),'primary_forms':len(forms),'armor':len(armor),'manifest_items':len(paths),'errors':errors,'pass':not errors},indent=2))
sys.exit(0 if not errors else 1)
