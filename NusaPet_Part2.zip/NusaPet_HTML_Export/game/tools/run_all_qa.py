#!/usr/bin/env python3
"""One-command offline QA orchestration. External/native gates remain explicit blockers."""
import subprocess,sys,os,json,datetime
ROOT=os.path.dirname(os.path.dirname(__file__))
steps=[
 ['tools/master_software_audit.py'],
 ['tools/deep_project_audit.py'],
 ['tools/content_audit.py'],
 ['tools/validate_localization.py'],
 ['tools/evolution_graph_audit.py'],
 ['tools/pusaka_audit.py'],
 ['tools/asset_audit.py'],
 ['tools/cultural_gate.py'],
 ['tools/research_gate.py'],
 ['tools/simulate_lifecycles.py'],
 ['tools/release_readiness.py'],
 ['tools/save_torture_contract.py'],
 ['tools/ui_contract_audit.py'],
 ['tools/architecture_contract_audit.py'],
 ['tools/final_scale_audit.py'],
 ['tools/native_source_contract.py'],
]
results=[]
for cmd in steps:
    p=subprocess.run([sys.executable,*cmd],cwd=ROOT,text=True,capture_output=True)
    results.append({'command':' '.join(cmd),'returncode':p.returncode,'stdout_tail':p.stdout[-3000:],'stderr_tail':p.stderr[-1600:]})
report={'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'steps':results,'native_checks':{
 'godot_headless':'NOT RUN — Godot 4.x executable unavailable in this audit environment',
 'native_exports':'NOT RUN — platform toolchains/signing/devices unavailable',
 'device_e2e':'NOT RUN — representative devices/emulators unavailable',
 'visual_regression':'NOT RUN — native production builds unavailable',
 'performance_thermal':'NOT RUN — native representative devices unavailable'
}}
json.dump(report,open(os.path.join(ROOT,'data/qa_report.json'),'w',encoding='utf8'),ensure_ascii=False,indent=2)
print(json.dumps({'steps':[(x['command'],x['returncode']) for x in results],'native_checks':report['native_checks']},indent=2))
# Offline structural gates are allowed to fail only for known external blockers.
unknown=[x for x in results if x['returncode'] not in (0,)]
known_external={'tools/release_readiness.py','tools/cultural_gate.py','tools/research_gate.py'}
if any(x['command'] not in known_external for x in unknown):
    raise SystemExit(2)
