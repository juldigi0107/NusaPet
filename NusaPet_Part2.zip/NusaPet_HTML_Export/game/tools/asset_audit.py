#!/usr/bin/env python3
import json, os, sys
ROOT=os.path.dirname(os.path.dirname(__file__))
manifest=json.load(open(os.path.join(ROOT,'data/assets/asset_manifest.json'),encoding='utf8'))
prompts=json.load(open(os.path.join(ROOT,'data/assets/art_prompts.json'),encoding='utf8'))
items=manifest if isinstance(manifest,list) else manifest.get('items',[])
pitems=prompts if isinstance(prompts,list) else prompts.get('items',[])
pids={str(x.get('asset_id') or x.get('id')) for x in pitems if isinstance(x,dict)}
errors=[]; warnings=[]; missing=0; unapproved=0; structurally_invalid=0
for x in items:
    aid=str(x.get('asset_id') or x.get('id') or '')
    if not aid:
        errors.append('asset missing stable id'); continue
    ref=str(x.get('resource_path') or x.get('path') or x.get('asset_ref') or '')
    required=bool(x.get('required',True))
    if required:
        if not ref or ref.lower() in ['null','none']:
            missing+=1; errors.append(f'{aid}: required final 3D asset has no resource path')
        elif ref.startswith('res://') and not os.path.exists(os.path.join(ROOT,ref[6:])):
            missing+=1; errors.append(f'{aid}: required final 3D asset absent: {ref}')
    structural=x.get('structural_validation',{})
    if structural and not bool(structural.get('structural_valid',False)):
        structurally_invalid+=1; errors.append(f'{aid}: structural geometry validation failed')
    if not bool(x.get('approved',False)):
        unapproved+=1
        if required: warnings.append(f'{aid}: final art approval missing (human review required)')
    if aid not in pids:
        errors.append(f'{aid}: no generated art prompt')
report={'errors':errors,'warnings':warnings,
        'counts':{'manifest_records':len(items),'prompt_records':len(pids),'required_assets_missing':missing,'required_assets_unapproved':unapproved,'structurally_invalid':structurally_invalid},
        'pass':not errors}
json.dump(report,open(os.path.join(ROOT,'data/qa/asset_audit.json'),'w'),indent=2,ensure_ascii=False)
print(json.dumps({'counts':report['counts'],'error_count':len(errors),'warning_count':len(warnings),'pass':report['pass']},indent=2,ensure_ascii=False))
sys.exit(0 if report['pass'] else 2)
