#!/usr/bin/env python3
import json,os
ROOT=os.path.dirname(os.path.dirname(__file__))
creatures=json.load(open(os.path.join(ROOT,'data/creatures/creatures.json'),encoding='utf8'))
forms=json.load(open(os.path.join(ROOT,'data/evolutions/primary_forms.json'),encoding='utf8'))
armor=json.load(open(os.path.join(ROOT,'data/armor-forms/armor_forms.json'),encoding='utf8'))
by={c['id']:c for c in creatures}
lines=[]
for f in forms:
 c=by[f['creature_line']]
 lines.append({'asset_id':f['id'],'prompt':f"Original premium stylized 3D NusaPet creature, {c['name_en']}, archetype {c.get('archetype')}, stage {f['stage']} {f['stage_key']}; preserve species silhouette; expressive but anatomically coherent; Nusantara-inspired habitat context; no franchise references; no text in artwork." ,'provenance':{'creator_tool':'NusaPet internal prompt generator','license':'ORIGINAL_GENERATION','source_reference':c.get('references',[]),'approved':False}})
for a in armor:
 c=by[a['base_creature']]
 lines.append({'asset_id':a['id'],'prompt':f"Original modular Armor Form for {c['name_en']} using {a['artifact_affinity']} affinity; preserve {c.get('archetype')} anatomy and silhouette; armor follows body joints; original Nusantara-inspired material language; no sacred-symbol appropriation; no franchise references; no text." ,'provenance':{'creator_tool':'NusaPet internal prompt generator','license':'ORIGINAL_GENERATION','source_reference':c.get('references',[]),'approved':False}})
json.dump({'version':'1.0','total_prompts':len(lines),'items':lines},open(os.path.join(ROOT,'data/assets/art_prompts.json'),'w',encoding='utf8'),ensure_ascii=False,indent=2)
print('generated',len(lines),'structured art prompts')
