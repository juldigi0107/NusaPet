#!/usr/bin/env python3
"""Produce deterministic JSONL seed batches for Supabase import. No network writes."""
import json,os
ROOT=os.path.dirname(os.path.dirname(__file__)); OUT=os.path.join(ROOT,'supabase','seed')
os.makedirs(OUT,exist_ok=True)
def load(r): return json.load(open(os.path.join(ROOT,r),encoding='utf8'))
for name,rel in [('species','data/creatures/creatures.json'),('evolution_forms','data/evolutions/primary_forms.json'),('cross_paths','data/cross-evolutions/cross_paths.json'),('artifacts','data/artifacts/pusaka.json'),('armor_forms','data/armor-forms/armor_forms.json'),('regions','data/regions/regions.json'),('habitats','data/habitats/habitats.json'),('quests','data/quests/quests.json'),('achievements','data/achievements/achievements.json')]:
 data=load(rel); path=os.path.join(OUT,name+'.jsonl')
 with open(path,'w',encoding='utf8') as f:
  for row in data: f.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
 print(name,len(data))
