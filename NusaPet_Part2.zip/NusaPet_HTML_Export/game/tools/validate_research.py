#!/usr/bin/env python3
"""Online research gate. Queries GBIF for accepted-name/taxonomy matching.
IUCN validation is optional and requires IUCN_TOKEN; no factual field is invented.
"""
import json, urllib.parse, urllib.request, os, datetime, sys
ROOT=os.path.dirname(os.path.dirname(__file__))
CREATURES=os.path.join(ROOT,'data/creatures/creatures.json')
OUT=os.path.join(ROOT,'data/taxonomy/real_species_validation.json')

def get(url, headers=None):
 req=urllib.request.Request(url,headers=headers or {'User-Agent':'NusaPet-ResearchValidator/1.0'})
 with urllib.request.urlopen(req,timeout=20) as r: return json.load(r)

creatures=json.load(open(CREATURES,encoding='utf8'))
real=[c for c in creatures if c.get('category')=='REAL']
results=[]
for i,c in enumerate(real,1):
 name=c['scientific_name']; rec={'creature_id':c['id'],'scientific_name':name,'gbif':None,'iucn':None,'status':'REVIEW_REQUIRED','notes':[]}
 try:
  q=urllib.parse.quote(name)
  data=get(f'https://api.gbif.org/v2/species/match?name={q}')
  rec['gbif']={k:data.get(k) for k in ['usageKey','scientificName','canonicalName','rank','status','matchType','confidence','family','genus','order','class','phylum','kingdom']}
  ok=(data.get('matchType') in ('EXACT','FUZZY') and data.get('rank')=='SPECIES' and data.get('kingdom')=='Animalia')
  if not ok: rec['notes'].append('GBIF match is not a clean Animalia species match')
 except Exception as e: rec['notes'].append('GBIF lookup failed: '+str(e))
 # IUCN API is deliberately not guessed without token.
 token=os.getenv('IUCN_TOKEN')
 if token:
  try:
   q=urllib.parse.quote(name)
   data=get(f'https://apiv3.iucnredlist.org/api/v3/species/{q}',{'Authorization':'Bearer '+token,'User-Agent':'NusaPet-ResearchValidator/1.0'})
   rec['iucn']=data
  except Exception as e: rec['notes'].append('IUCN lookup failed: '+str(e))
 else: rec['notes'].append('IUCN_TOKEN not configured; conservation remains REVIEW_REQUIRED')
 if rec['gbif'] and not rec['notes'][-1].startswith('IUCN_TOKEN') and not any('failed' in n for n in rec['notes']): rec['status']='TAXONOMY_MATCHED'
 results.append(rec)
 print(f'[{i}/{len(real)}] {name}: {rec["status"]}',flush=True)

out={'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'GBIF Species API v2; IUCN optional via token','total':len(results),'results':results,
     'release_gate':'PASS only after accepted-name + distribution + habitat + conservation + references are all independently verified.'}
json.dump(out,open(OUT,'w',encoding='utf8'),ensure_ascii=False,indent=2)
print('WROTE',OUT)
