#!/usr/bin/env python3
import hashlib,json,os
ROOT=os.path.dirname(os.path.dirname(__file__))
paths=[]
for base,dirs,files in os.walk(os.path.join(ROOT,"data")):
    dirs[:] = [d for d in dirs if d != "qa"]
    for name in files:
        if name.endswith((".json",".jsonl")) and name != "content_manifest.json":
            full=os.path.join(base,name); paths.append(os.path.relpath(full,ROOT).replace(os.sep,"/"))
paths.sort()
def sha(path):
    h=hashlib.sha256(); h.update(open(os.path.join(ROOT,path),"rb").read()); return h.hexdigest()
summary={"creatures":len(json.load(open(os.path.join(ROOT,"data/creatures/creatures.json"),encoding="utf8"))),"real":250,"mythology":50,"mystical":50,"primary_forms":len(json.load(open(os.path.join(ROOT,"data/evolutions/primary_forms.json"),encoding="utf8"))),"armor_forms":len(json.load(open(os.path.join(ROOT,"data/armor-forms/armor_forms.json"),encoding="utf8"))),"cross_paths":len(json.load(open(os.path.join(ROOT,"data/cross-evolutions/cross_paths.json"),encoding="utf8"))),"pusaka":len(json.load(open(os.path.join(ROOT,"data/artifacts/pusaka.json"),encoding="utf8"))),"dual_resonance":len(json.load(open(os.path.join(ROOT,"data/artifacts/dual_resonance.json"),encoding="utf8"))),"asset_manifest":len(json.load(open(os.path.join(ROOT,"data/assets/asset_manifest.json"),encoding="utf8"))),"art_prompts":len(json.load(open(os.path.join(ROOT,"data/assets/art_prompts.json"),encoding="utf8")))}
out={"content_version":"2026.09-content-3","summary":summary,"files":{p:{"sha256":sha(p),"bytes":os.path.getsize(os.path.join(ROOT,p))} for p in paths}}
json.dump(out,open(os.path.join(ROOT,"data/content_manifest.json"),"w",encoding="utf8"),ensure_ascii=False,indent=2,sort_keys=True)
print("content manifest generated",len(paths),"files")
