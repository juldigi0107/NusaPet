#!/usr/bin/env python3
import json, pathlib, re, hashlib, sys, collections
ROOT=pathlib.Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
def load(rel):
    p=ROOT/rel
    if not p.exists(): errors.append(f"missing file: {rel}"); return []
    try: return json.loads(p.read_text(encoding="utf8"))
    except Exception as e: errors.append(f"invalid json {rel}: {e}"); return []
creatures=load("data/creatures/creatures.json"); forms=load("data/evolutions/primary_forms.json"); cross=load("data/cross-evolutions/cross_paths.json"); armor=load("data/armor-forms/armor_forms.json"); pusaka=load("data/artifacts/pusaka.json")
ids=[x.get("id") for x in creatures]
if len(creatures)!=350 or len(set(ids))!=350: errors.append("creature scale/id integrity failed")
if sum(x.get("category")=="REAL" for x in creatures)!=250: errors.append("REAL count != 250")
if sum(x.get("category")=="MYTHOLOGY" for x in creatures)!=50: errors.append("MYTHOLOGY count != 50")
if sum(x.get("category")=="MYSTICAL" for x in creatures)!=50: errors.append("MYSTICAL count != 50")
if len(forms)!=2100: errors.append("primary forms != 2100")
if len(armor)<700: errors.append("armor forms < 700")
if len(cross)<350: errors.append("cross paths < 350")
if len(pusaka)<15: errors.append("pusaka < 15")
for c in creatures:
    if c.get("category")=="REAL" and not c.get("scientific_name"): errors.append(f"missing scientific name {c.get('id')}")
    if not isinstance(c.get("pusaka_compatibility"),dict) or len(c["pusaka_compatibility"])<2: errors.append(f"compatibility <2 {c.get('id')}")
    if not c.get("locomotion_profile"): errors.append(f"missing locomotion {c.get('id')}")
for f in forms:
    if not pathlib.Path(ROOT/f.get("asset_manifest",{}).get("path","").replace("res://","" )).exists(): errors.append(f"missing primary asset {f.get('id')}")
for a in armor:
    if not pathlib.Path(ROOT/a.get("asset_manifest",{}).get("path","").replace("res://","" )).exists(): errors.append(f"missing armor asset {a.get('id')}")
for e in cross:
    for k in ["source","target","requirements","rationale","condition_weights"]:
        if k not in e: errors.append(f"cross {e.get('id')} missing {k}")
# scan GDScript for known fatal corruption patterns
for p in ROOT.rglob("*.gd"):
    s=p.read_text(encoding="utf8",errors="replace")
    if "funcfunc " in s: errors.append(f"syntax corruption funcfunc: {p.relative_to(ROOT)}")
    if re.search(r"^\s{1,}var .*\n\s{0,}[^#\s].*",s,re.M): pass
    if p.name not in {"type_audit.gd","static_audit.gd"} and ("<html" in s.lower() or "document." in s or "CanvasRenderingContext2D" in s): errors.append(f"web runtime dependency: {p.relative_to(ROOT)}")
print(json.dumps({"errors":errors,"warnings":warnings,"counts":{"creatures":len(creatures),"forms":len(forms),"armor":len(armor),"cross":len(cross),"pusaka":len(pusaka)},"pass":not errors},ensure_ascii=False,indent=2))
sys.exit(0 if not errors else 1)
