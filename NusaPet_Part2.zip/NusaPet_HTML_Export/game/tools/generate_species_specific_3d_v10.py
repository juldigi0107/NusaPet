#!/usr/bin/env python3
"""NusaPet v10 species-specific 3D candidate generator.
Creates explicit per-creature morphology signatures for all 350 lines x 6 stages and 700 armor forms.
This is structural game-art generation, not scientific/art approval.
"""
from __future__ import annotations
import json, math, hashlib
from pathlib import Path
import numpy as np, trimesh
from trimesh.transformations import rotation_matrix
ROOT=Path(__file__).resolve().parents[1]
CREATURES=json.load(open(ROOT/'data/creatures/creatures.json'))
OUT=ROOT/'assets/generated/creatures'; OUT.mkdir(parents=True,exist_ok=True)
STAGE=[.28,.44,.62,.80,1.0,1.08]

def mat(c,rough=.72,metal=0.0):
 return trimesh.visual.material.PBRMaterial(baseColorFactor=tuple(int(max(0,min(1,x))*255) for x in c)+(255,),roughnessFactor=rough,metallicFactor=metal)
def ell(sc,n,p,s,m,seg=12,rings=8):
 x=trimesh.creation.uv_sphere(radius=1,count=[max(seg,8),max(rings,6)]);x.apply_scale(s);x.apply_translation(p);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def cyl(sc,n,a,b,r,m,sec=10):
 a=np.array(a,float);b=np.array(b,float);v=b-a;L=np.linalg.norm(v)
 if L<1e-5:return
 x=trimesh.creation.cylinder(radius=r,height=L,sections=sec);z=np.array([0,0,1.]);u=v/L;d=np.clip(np.dot(z,u),-1,1)
 if d<.999999:
  ra=np.cross(z,u);ra/=np.linalg.norm(ra);x.apply_transform(rotation_matrix(math.acos(d),ra))
 x.apply_translation((a+b)/2);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def cone(sc,n,p,r,h,m,d=(0,0,1)):
 x=trimesh.creation.cone(radius=r,height=h,sections=10);u=np.array(d,float);u/=np.linalg.norm(u);z=np.array([0,0,1.]);dot=np.clip(np.dot(z,u),-1,1)
 if dot<.999999:
  ra=np.cross(z,u);ra/=np.linalg.norm(ra);x.apply_transform(rotation_matrix(math.acos(dot),ra))
 x.apply_translation(p);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def box(sc,n,p,s,m):
 x=trimesh.creation.box(extents=s);x.apply_translation(p);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)

def family(c):
 t=c.get('factual_data',{}).get('taxonomy',{}); cls=(t.get('class') or '').lower(); order=(t.get('order') or '').lower(); name=(c.get('name_id') or '').lower(); arch=c.get('archetype','')
 if arch=='ETHEREAL':
  if any(k in name for k in ['garuda','burung','elang','rajawali','phoenix']): return 'bird'
  if any(k in name for k in ['naga','ular','dragon','ular']): return 'serpent'
  if any(k in name for k in ['kuda','horse']): return 'horse'
  if any(k in name for k in ['ikan','fish','hiu','shark','pari','ray']): return 'fish'
  if any(k in name for k in ['raksasa','buto','buta','rangda','nyai','jenglot','warak','kala','banaspati','orang']): return 'humanoid'
  return 'mythic'
 if 'aves' in cls:return 'bird'
 if 'actinopterygii' in cls or 'chondrichthyes' in cls:return 'fish'
 if 'amphibia' in cls:return 'amphibian'
 if any(x in cls for x in ('insecta','arachnida','myriapoda')):return 'arthropod'
 if 'mollusca' in cls:return 'cephalopod'
 if 'mammalia' in cls:
  if order in ('cetacea','sirenia'):return 'aquatic_mammal'
  if order=='chiroptera':return 'bat'
  if order=='primates':return 'primate'
  return 'quadruped'
 if 'reptilia' in cls:
  if order=='testudines':return 'turtle'
  return 'reptile'
 return 'quadruped'

def signature(c):
 n=(c.get('name_id') or '').lower(); sci=(c.get('scientific_name') or '').lower(); f=family(c)
 # Explicit morphology token map. Multiple tokens may stack for one species.
 rules=[
  (['komodo','biawak'],'monitor'),(['badak'],'rhino'),(['orangutan'],'great_ape'),(['bekantan'],'proboscis_nose'),(['owa','siamang'],'gibbon'),(['surili','lutung'],'leaf_monkey'),(['kukang'],'loris'),(['tarsius'],'tarsier'),
  (['banteng'],'bovid_horns'),(['anoa'],'compact_horns'),(['rusa','kijang'],'antler'),(['kancil'],'tiny_hoof'),(['babirusa'],'curved_tusks'),(['babi'],'boar_snout'),(['tapir'],'tapir_trunk'),
  (['harimau'],'tiger_stripes'),(['macan dahan'],'cloud_spots'),(['macan tutul'],'leopard_spots'),(['kucing bakau'],'webbed_paws'),(['kucing hutan','kucing batu'],'wildcat'),(['kucing emas'],'golden_cat'),(['musang','linsang'],'civet_mask'),(['binturong'],'prehensile_tail'),(['beruang'],'bear_muzzle'),(['landak'],'quills'),(['trenggiling'],'armor_scales'),
  (['bajing','tupai'],'squirrel_tail'),(['kelinci'],'rabbit_ears'),(['gajah'],'elephant_trunk'),(['pesut','lumba-lumba'],'dolphin_beak'),(['dugong'],'dugong_flipper'),(['paus sperma'],'sperm_head'),(['paus biru'],'blue_whale_fluke'),(['paus bungkuk'],'humpback_pectoral'),(['paus bryde','paus sei','paus sirip','paus pilot'],'whale_fin'),
  (['hiu martil'],'hammerhead'),(['hiu macan'],'tiger_shark'),(['hiu banteng'],'bull_shark'),(['hiu paus'],'whale_shark'),(['hiu zebra'],'zebra_shark'),(['wobbegong'],'wobbegong'),(['pari manta'],'manta_wings'),(['pari elang'],'eagle_ray'),(['pari gitar'],'guitar_ray'),(['pari listrik'],'electric_ray'),(['pari jawa','pari air tawar','pari sungai'],'ray_disc'),
  (['coelacanth'],'coelacanth_fins'),(['arwana'],'dragonfish_jaw'),(['napoleon'],'humphead'),(['kerapu'],'grouper_head'),(['kuda laut'],'seahorse'),(['badut'],'clownfish_bands'),(['kardinal'],'cardinal_bars'),(['belida'],'knifefish_fin'),(['archerfish'],'archer_snout'),(['gabus','toman'],'snakehead'),(['patin'],'catfish_barbels'),(['baung'],'catfish_barbels'),(['jelawat','semah'],'river_fish'),(['belut'],'eel'),(['pelangi'],'rainbow_fish'),(['mandarinfish'],'mandarinfish'),(['ikan terbang'],'flying_fish'),(['buntal'],'puffer'),(['singa'],'lionfish'),
  (['buaya'],'crocodile'),(['biawak'],'monitor'),(['tokek'],'gecko'),(['soa-soa'],'sail_lizard'),(['kura-kura','penyu'],'turtle_shell'),(['katak','kodok'],'frog'),(['salamander','sesilia'],'caecilian'),
  (['elang','rajawali'],'raptor'),(['cenderawasih'],'bird_of_paradise'),(['jalak'],'mynah'),(['kakatua'],'cockatoo'),(['nuri'],'parrot'),(['kasuari'],'cassowary'),(['maleo','gosong'],'megapode'),(['rangkong','enggang','julang'],'hornbill_casque'),(['bangau'],'stork'),(['pelikan'],'pelican_pouch'),(['hantu','serak'],'owl'),(['kuntul'],'heron'),(['ibis'],'ibis_bill'),(['bebek','belibis'],'duck_bill'),(['ayam hutan'],'junglefowl'),(['merak'],'peacock_tail'),(['pipit','bondol'],'finch'),(['poksai'],'thrush'),(['pelanduk'],'insectivore'),(['kacamata'],'white_eye'),(['cucak','murai','anis','layang','walet','kipasan','raja udang','cekakak','dara laut','pecuk','punai','peregam','bubut','kedasi','kowak','puyuh','trulek','mandar','bambangan','kareo','cinenen','prenjak','sikep','alap-alap'],'small_bird'),
  (['kupu-kupu'],'butterfly'),(['kumbang badak'],'rhino_beetle'),(['kumbang herkules'],'hercules_beetle'),(['kumbang gajah'],'elephant_beetle'),(['belalang daun'],'leaf_insect'),(['belalang sembah'],'mantis'),(['tonggeret'],'cicada'),(['kunang'],'firefly'),(['lebah'],'bee'),(['tawon'],'wasp'),(['laba-laba'],'spider'),(['kelabang'],'centipede'),(['kepiting bakau'],'mangrove_crab'),(['kepiting kelapa'],'coconut_crab'),(['udang mantis'],'mantis_shrimp'),(['nautilus'],'nautilus_shell'),(['cumi'],'squid'),(['gurita'],'octopus'),(['kerang raksasa'],'giant_clam'),(['bintang laut'],'starfish'),(['teripang'],'sea_cucumber'),(['bulu babi'],'urchin'),(['karang otak'],'coral'),
 ]
 tokens=[]
 for keys,tok in rules:
  if any(k in n for k in keys): tokens.append(tok)
 if not tokens:
  tokens.append({'bird':'bird','fish':'fish','aquatic_mammal':'aquatic_mammal','arthropod':'arthropod','cephalopod':'cephalopod','turtle':'turtle_shell','amphibian':'frog','reptile':'reptile','serpent':'serpent','horse':'horse','primate':'primate','bat':'bat','humanoid':'mythic_humanoid','mythic':'mythic'}.get(f,'quadruped'))
 # fictional lines receive distinct visual motif from their exact name hash plus semantic keyword.
 if c['id'].startswith(('folklore_','mystical_')):
  if any(k in n for k in ['naga','ular','siluman ular']): tokens.append('fantasy_serpent')
  elif any(k in n for k in ['garuda','burung','buraq','sikep']): tokens.append('fantasy_wing')
  elif any(k in n for k in ['hantu','kuntilanak','pocong','wewe','sundel','kuyang','palasik','penanggalan']): tokens.append('ethereal_veil')
  elif any(k in n for k in ['raksasa','buto','genderuwo','kala','banaspati','leak','barong','rangda']): tokens.append('mythic_silhouette')
  else: tokens.append('original_mystic')
 return list(dict.fromkeys(tokens))

def build(c,stage):
 h=int(hashlib.sha256(c['id'].encode()).hexdigest()[:8],16); f=family(c); toks=signature(c); s=STAGE[stage-1]
 L=.82+(h%10000)/10000*.42; W=.55+((h>>8)%10000)/10000*.31; H=.58+((h>>16)%10000)/10000*.37; head=.28+((h>>4)%10000)/10000*.16
 base=((h&255)/255*.30+.24,((h>>8)&255)/255*.28+.23,((h>>16)&255)/255*.26+.21); body=mat(base); accent=mat(tuple(min(1,x*1.55+.08) for x in base)); dark=mat(tuple(x*.38 for x in base)); light=mat(tuple(min(1,x*1.8+.15) for x in base)); eye=mat((.94,.92,.80),.28)
 sc=trimesh.Scene()
 if stage==1:
  ell(sc,'EmbryoCore',(0,0,.28*s),(L*.45*s,W*.38*s,.40*s),body)
  ell(sc,'SpeciesIdentityBud',(L*.24*s,0,.48*s),(head*.52*s,head*.40*s,.25*s),accent)
  # identity bud markers prevent stage-1 from being an identical generic egg.
  for i,t in enumerate(toks[:2]): ell(sc,f'IdentityMarker_{t}_{i}',(.05*s,(i-.5)*.18*s,.64*s),(.05*s,.05*s,.10*s),light)
 else:
  z=H*s+.35; bl=L*s; bw=W*s; bh=H*s
  if f in ('fish','aquatic_mammal'):
   ell(sc,'Torso',(0,0,z),(bl*(1.15 if f=='fish' else 1.12),bw*.68,bh*.58),body)
   ell(sc,'Head',(bl*.78,0,z+.06*s),(head*(1.05 if f=='fish' else 1.15),bw*.48 if f=='fish' else bw*.60,bh*.55),body)
   if 'hammerhead' in toks: box(sc,'HammerHeadBar',(bl*.98,0,z+.18*s),(bl*.78,bw*1.45,.18*s),accent)
   elif 'manta_wings' in toks or 'eagle_ray' in toks or 'ray_disc' in toks: box(sc,'RayDisc',(0,0,z),(bl*1.9,bw*1.8,.12*s),body)
   elif 'seahorse' in toks: cyl(sc,'SeahorseNeck',(bl*.55,0,z+.10*s),(bl*.65,0,z+.48*s),.11*s,body); cone(sc,'SeahorseCrown',(bl*.72,0,z+.52*s),.08*s,.22*s,accent,(1,0,.2))
   else: cone(sc,'Snout',(bl*1.35,0,z+.02*s),.15*s,.34*s,accent,(1,0,0))
   for side in (-1,1): box(sc,f'PectoralFin_{side}',(.25*s,side*bw*.68,z),(.50*s,.07*s,.32*s),accent)
   if 'flying_fish' in toks: box(sc,'WingFin',(.10*s,0,z+.18*s),(bl*.90,bw*.20,.08*s),light)
   cone(sc,'DorsalFin',(-.05*s,0,z+bh*.72),.14*s,.42*s,accent,(0,0,1)); cone(sc,'CaudalFin',(-bl*1.0,0,z),.28*s,.55*s,accent,(-1,0,.1))
   if 'barbels' in toks:
    for side in (-1,1): cyl(sc,f'Barbel_{side}',(bl*1.05,side*.18*s,z),(bl*1.35,side*.30*s,z-.15*s),.025*s,accent)
   if 'puffer' in toks:
    for i in range(10):
     a=2*math.pi*i/10; cone(sc,f'Spine_{i}',(math.cos(a)*bl*.55,math.sin(a)*bw*.65,z),.025*s,.16*s,accent,(math.cos(a),math.sin(a),.4))
  elif f=='bird':
   ell(sc,'Torso',(0,0,z),(bl*.85,bw*.62,bh*.70),body); ell(sc,'Head',(bl*.72,0,z+.30*s),(head*.70,head*.65,head*.78),body)
   cone(sc,'Beak',(bl*1.28,0,z+.28*s),.12*s,.42*s,accent,(1,0,.15))
   if 'pelican_pouch' in toks: ell(sc,'GularPouch',(bl*1.10,0,z-.05*s),(.26*s,.34*s,.24*s),accent)
   if 'hornbill_casque' in toks: ell(sc,'Casque',(bl*.72,0,z+.70*s),(.24*s,.28*s,.18*s),accent)
   if 'cockatoo' in toks or 'bird_of_paradise' in toks: 
    for i in range(5): cone(sc,f'Crest_{i}',(bl*.40,(i-2)*.10*s,z+.78*s),.045*s,.32*s,light,(0,(i-2)*.12,1))
   for side in (-1,1):
    ell(sc,f'Wing_{side}',(-.05*s,side*bw*.78,z+.15*s),(bl*.72,bw*.24,bh*.40),accent); cyl(sc,f'Leg_{side}',(.22*s,side*.18*s,z-bh*.55),(.20*s,side*.20*s,.18),.055*s,dark)
    ell(sc,f'Foot_{side}',(.30*s,side*.22*s,.13),(.18*s,.08*s,.045*s),dark)
   if 'peacock_tail' in toks or 'bird_of_paradise' in toks:
    for i in range(7): cone(sc,f'TailPlume_{i}',(-bl*.82,(i-3)*.16*s,z+.08*s),.06*s,.65*s,light,(-1,(i-3)*.08,.18))
   else:
    for i in range(3): cone(sc,f'TailFeather_{i}',(-bl*.80,(i-1)*.18*s,z+.10*s),.07*s,.52*s,accent,(-1,(i-1)*.18,.12))
  elif f in ('arthropod','cephalopod'):
   if f=='arthropod':
    segs=3 if 'centipede' not in toks else 6
    for i in range(segs): ell(sc,f'Segment_{i}',(-bl*.35+i*bl*.22,0,z),(bl*.28,bw*(.72-.05*i),bh*(.52-.03*i)),body)
    legs=6 if 'centipede' not in toks else 10
    for i in range(legs):
     side=-1 if i%2==0 else 1; x=-bl*.42+(i//2)*bl*.18; cyl(sc,f'Leg_{i}',(x,side*bw*.45,z),(x-.10*s,side*bw*(1.05 if 'crab' not in toks else .85),z-.25*s),.04*s,dark)
    if 'mantis' in toks:
     for side in (-1,1): cyl(sc,f'RaptorialArm_{side}',(bl*.25,side*bw*.45,z+.12*s),(bl*.65,side*bw*.25,z-.08*s),.06*s,accent)
    if 'rhino_beetle' in toks or 'hercules_beetle' in toks: cone(sc,'MandibleHorn',(bl*.90,0,z+.20*s),.10*s,.55*s,accent,(1,0,.25))
    ell(sc,'Head',(bl*.82,0,z+.05*s),(head*.75,bw*.65,bh*.58),body)
    for side in (-1,1): cyl(sc,f'Antenna_{side}',(bl*1.0,side*.18*s,z+.28*s),(bl*1.25,side*.40*s,z+.55*s),.018*s,accent)
    if 'butterfly' in toks:
     for side in (-1,1):
      box(sc,f'WingUpper_{side}',(-.10*s,side*bw*1.05,z+.22*s),(bl*.70,.06*s,bh*.52),light); box(sc,f'WingLower_{side}',(-.30*s,side*bw*.92,z-.08*s),(bl*.45,.05*s,bh*.38),accent)
   else:
    ell(sc,'Mantle',(0,0,z),(bl*.78,bw*.82,bh*.55),body); ell(sc,'Head',(bl*.55,0,z+.10*s),(head*.78,head*.78,head*.72),body)
    arms=8 if 'octopus' in toks else 10 if 'squid' in toks else 6
    for i in range(arms):
     a=2*math.pi*i/arms; p=(math.cos(a)*bl*.70,math.sin(a)*bw*.80,z-.22*s); cyl(sc,f'Tentacle_{i}',(.18*bl*math.cos(a),.18*bw*math.sin(a),z-.10*s),p,.045*s,accent)
  elif f=='turtle':
   ell(sc,'Shell',(0,0,z),(bl,bw,bh*.65),accent,16,10); ell(sc,'Belly',(bl*.10,0,z-.35*s),(bl*.82,bw*.82,bh*.25),dark); ell(sc,'Head',(bl*.92,0,z+.02*s),(head*.85,head*.70,head*.65),body)
   for side in (-1,1):
    for i in range(2): ell(sc,f'Flipper_{side}_{i}',((.55-i*.35)*s,side*bw*.80,z-.12*s),(.32*s,.12*s,.10*s),accent)
   if 'turtle_shell' in toks:
    for i in range(8): ell(sc,f'ShellScute_{i}',(-bl*.55+i*bl*.16,0,z+.55*s),(.10*s,.08*s,.05*s),light)
   cone(sc,'Tail',(-bl*.95,0,z-.05*s),.10*s,.28*s,dark,(-1,0,0))
  elif f=='bat':
   ell(sc,'Torso',(0,0,z),(bl*.72,bw*.52,bh*.72),body); ell(sc,'Head',(bl*.55,0,z+.32*s),(head*.65,head*.60,head*.70),body)
   for side in (-1,1): box(sc,f'Wing_{side}',(-.05*s,side*bw*.95,z+.28*s),(bl*.95,.06*s,bh*.58),accent); cone(sc,f'Ear_{side}',(bl*.55,side*head*.45,z+.78*s),.07*s,.22*s,accent,(0,side,1))
  elif f=='amphibian':
   ell(sc,'Torso',(0,0,z),(bl*.80,bw*.72,bh*.62),body); ell(sc,'Head',(bl*.70,0,z+.20*s),(head*1.05,head*.88,head*.78),body)
   for side in (-1,1):
    for i,x in enumerate((.42,-.38)): cyl(sc,f'Leg_{side}_{i}',(x*s,side*bw*.48,z),(x*.90*s,side*bw*.82,.18),.07*s,accent)
   for side in (-1,1): ell(sc,f'Eye_{side}',(bl*.86,side*head*.62,z+.48*s),(.07*s,.07*s,.09*s),eye)
   if 'frog' in toks:
    for side in (-1,1): ell(sc,f'Tympanum_{side}',(bl*.82,side*head*.78,z+.22*s),(.07*s,.035*s,.07*s),accent)
  elif f=='serpent':
   pts=[(-bl*.75,0,z),(-bl*.20,.10*s,z+.05*s),(bl*.35,-.08*s,z-.04*s),(bl*.85,0,z+.08*s)]
   for i in range(3): cyl(sc,f'Body_{i}',pts[i],pts[i+1],max(.08*s,(.24-.04*i)*s),body)
   ell(sc,'Head',(bl*.98,0,z+.10*s),(head,head*.72,head*.70),body); cone(sc,'Jaw',(bl*1.35,0,z+.03*s),.10*s,.28*s,accent,(1,0,0))
   if any(t in toks for t in ['reptile','fantasy_serpent']):
    for side in (-1,1): ell(sc,f'Hood_{side}',(bl*.98,side*.18*s,z+.20*s),(.22*s,.06*s,.30*s),accent)
  elif f=='horse':
   ell(sc,'Torso',(0,0,z),(bl,bw*.72,bh*.75),body); ell(sc,'Head',(bl*.92,0,z+.45*s),(head*.72,head*.55,head*1.0),body)
   for side in (-1,1):
    for x in (-.55,.55): cyl(sc,f'Leg_{side}_{x}',(x*bl*.65,side*bw*.55,z-bh*.45),(x*bl*.70,side*bw*.50,.16),.075*s,accent)
   ell(sc,'Mane',(bl*.45,0,z+.88*s),(.22*s,.10*s,.52*s),dark)
  elif f=='humanoid' or f in ('mythic','mythic_humanoid'):
   ell(sc,'Torso',(0,0,z),(bl*.65,bw*.70,bh*.95),body); ell(sc,'Head',(0,0,z+bh*.98),(head*.78,head*.72,head*.88),body)
   for side in (-1,1): cyl(sc,f'Arm_{side}',(0,side*bw*.55,z+.45*s),(0,side*bw*1.02,z-.05*s),.08*s,accent); cyl(sc,f'Leg_{side}',(-.18*s,side*.22*s,z-.65*s),(-.22*s,side*.24*s,.18),.09*s,body)
   if 'mythic_silhouette' in toks or 'original_mystic' in toks:
    for i in range(3): cone(sc,f'CrownShard_{i}',(0,(i-1)*.12*s,z+bh*1.82),.07*s,.28*s,accent,(0,(i-1)*.15,1))
  else:
   ell(sc,'Torso',(0,0,z),(bl,bw,bh*.75),body); ell(sc,'Head',(bl*.86,0,z+.20*s),(head*.90,head*.72,head*.80),body)
   for side in (-1,1):
    for i,x in enumerate((.55,-.55)):
     hip=(x*bl*.70,side*bw*.58,z-bh*.35); foot=(x*bl*.74,side*bw*.55,.17); cyl(sc,f'Leg_{side}_{i}_upper',hip,((hip[0]+foot[0])/2,(hip[1]+foot[1])/2,(hip[2]+foot[2])/2),.085*s,accent); cyl(sc,f'Leg_{side}_{i}_lower',((hip[0]+foot[0])/2,(hip[1]+foot[1])/2,(hip[2]+foot[2])/2),foot,.06*s,body)
   cyl(sc,'TailBase',(-bl*.72,0,z),(-bl*1.25,0,z-.20*s),.10*s,accent)
  # universal eyes
  for side in (-1,1): ell(sc,f'Eye_{side}',(bl*.98,side*head*.60,z+.38*s),(.055*s,.055*s,.065*s),eye,10,6)
  # species identity overlays / markings, deterministic and stage-aware.
  if 'rhino' in toks or 'bovid_horns' in toks or 'compact_horns' in toks:
   count=2 if 'compact_horns' in toks or 'bovid_horns' in toks else 1
   for i in range(count): cone(sc,f'Horn_{i}',(bl*.98-i*.18*s,(-.12+.24*i)*s,z+.48*s),.10*s,.34*s,accent,(1,0,.25))
  if 'antler' in toks:
   for side in (-1,1):
    cyl(sc,f'Antler_{side}_main',(bl*.55,side*head*.45,z+.58*s),(bl*.52,side*head*.72,z+1.0*s),.045*s,accent)
    for j in range(2): cyl(sc,f'Antler_{side}_branch_{j}',(bl*.52,side*(head*.60+j*.05*s),z+.80*s),(bl*.35,side*(head*.75+j*.07*s),z+.98*s),.028*s,accent)
  if 'curved_tusks' in toks:
   for side in (-1,1): cyl(sc,f'Tusk_{side}',(bl*1.10,side*.18*s,z+.12*s),(bl*1.30,side*.30*s,z-.20*s),.055*s,light)
  if 'elephant_trunk' in toks: cyl(sc,'Trunk',(bl*.96,0,z+.18*s),(bl*1.55,0,z-.12*s),.12*s,accent,14)
  if 'quills' in toks:
   for i in range(9):
    x=-bl*.45+i*bl*.11; cone(sc,f'Quill_{i}',(x,0,z+bh*.55),.035*s,.32*s,light,(0,0,1))
  if 'armor_scales' in toks or 'monitor' in toks:
   for i in range(9): box(sc,f'DorsalScale_{i}',(-bl*.55+i*bl*.13,0,z+bh*.62),(.10*s,.12*s,.10*s),accent)
  if any(t in toks for t in ['tiger_stripes','cloud_spots','leopard_spots','clownfish_bands','zebra_shark']):
   count=7 if 'tiger_stripes' in toks else 9
   for i in range(count): box(sc,f'Marking_{i}',(-bl*.55+i*bl*(1.0/max(1,count-1)),(-1 if i%2 else 1)*bw*.68,z+.05*s),(.07*s,.03*s,.32*s if 'tiger_stripes' in toks else .12*s),dark)
  if 'squirrel_tail' in toks or 'prehensile_tail' in toks:
   cyl(sc,'SignatureTail',(-bl*.65,0,z),(-bl*1.55,.18*s,z+.45*s),.12*s,accent)
  if 'rabbit_ears' in toks or 'loris' in toks or 'tarsier' in toks:
   for side in (-1,1): cone(sc,f'LongEar_{side}',(bl*.70,side*head*.45,z+.72*s),.07*s,.36*s,accent,(0,side,1))
  if 'proboscis_nose' in toks: ell(sc,'Proboscis',(bl*1.15,0,z+.25*s),(.20*s,.14*s,.32*s),accent)
  if 'tapir_trunk' in toks: ell(sc,'ShortTrunk',(bl*1.10,0,z+.05*s),(.28*s,.20*s,.22*s),accent)
  if 'sail_lizard' in toks:
   box(sc,'DorsalSail',(-bl*.10,0,z+.62*s),(.75*s,.08*s,.75*s),accent)
  if 'gecko' in toks:
   for side in (-1,1): ell(sc,f'ToePad_{side}',(bl*.55,side*bw*.75,.18),(.15*s,.10*s,.05*s),light)
  if 'hammerhead' in toks: ell(sc,'HammerEyeL',(bl*.90,-bw*.70,z+.20*s),(.07*s,.07*s,.07*s),light); ell(sc,'HammerEyeR',(bl*.90,bw*.70,z+.20*s),(.07*s,.07*s,.07*s),light)
  if 'seahorse' in toks:
   for i in range(5): ell(sc,f'KeelPlate_{i}',(-bl*.15+i*.10*s,0,z+.18*s),(.08*s,.12*s,.06*s),accent)
  if 'humphead' in toks: ell(sc,'ForeheadBulge',(bl*.72,0,z+.40*s),(.30*s,.28*s,.18*s),accent)
  if 'snakehead' in toks or 'crocodile' in toks: box(sc,'JawPlate',(bl*1.12,0,z-.02*s),(.35*s,.22*s,.12*s),dark)
  if stage>=4:
   for i in range(4):
    a=2*math.pi*i/4; ell(sc,f'StageMark_{i}',(math.cos(a)*bl*.45,math.sin(a)*bw*.55,z+bh*.55),(.045*s,.045*s,.16*s),accent,8,6)
  if stage>=5:
   for i in range(6):
    a=2*math.pi*i/6; ell(sc,f'Resonance_{i}',(math.cos(a)*bl*.58,math.sin(a)*bw*.72,z+bh*.25),(.032*s,.032*s,.12*s),light,8,6)
 sc.metadata.update({'asset_id':f'{c["id"]}_s{stage}','creature_id':c['id'],'stage':stage,'morphology_family':f,'morphology_signature':toks,'scientific_name':c.get('scientific_name'),'name_id':c.get('name_id'),'generator':'NusaPet species-specific morphology generator v10','approval':'UNAPPROVED_CANDIDATE','fallback':'NONE_ASSET_PRESENT_PENDING_ART_QA'})
 return sc

def main():
 manifest=json.load(open(ROOT/'data/assets/asset_manifest.json')); by={x['asset_id']:x for x in manifest['items']}
 profiles={}; batch_reports=[]
 for b in range(7):
  chunk=CREATURES[b*50:(b+1)*50]; generated=0; sigset=set()
  for c in chunk:
   toks=signature(c); profiles[c['id']]={'name_id':c.get('name_id'),'scientific_name':c.get('scientific_name'),'family':family(c),'signature':toks}
   sigset.add('|'.join(toks))
   for stage in range(1,7):
    aid=f'{c["id"]}_s{stage}'; p=OUT/f'{aid}.glb'; build(c,stage).export(p,file_type='glb'); generated+=1
    by[aid]['resource_path']=f'res://assets/generated/creatures/{aid}.glb'; by[aid]['approved']=False; by[aid]['fallback']='NONE_ASSET_PRESENT_PENDING_ART_QA'; by[aid]['morphology_family']=family(c); by[aid]['morphology_signature']=toks; by[aid]['source_identity']=c.get('scientific_name') or c.get('name_id')
  batch_reports.append({'batch':f'PRIMARY-{b+1:02d}','creature_lines':len(chunk),'assets':generated,'unique_morphology_signatures':len(sigset),'status':'CANDIDATE_REVIEW','approval_required':True})
  print('completed',batch_reports[-1])
 json.dump(profiles,open(ROOT/'data/creatures/creature_3d_profiles_v10.json','w'),ensure_ascii=False,indent=2)
 json.dump({'generator':'v10','batches':batch_reports,'total_assets':sum(x['assets'] for x in batch_reports),'status':'CANDIDATE_REVIEW','approval_required':True},open(ROOT/'data/qa/primary_asset_generation_v10.json','w'),ensure_ascii=False,indent=2)
 manifest.setdefault('asset_generation_batches',[]).append({'batch':'PRIMARY_SPECIES_SPECIFIC_V10','scope':'350 creature lines x 6 stages','created':2100,'status':'CANDIDATE_REVIEW','approval_required':True,'contains_empty_assets':False,'batch_size':50})
 json.dump(manifest,open(ROOT/'data/assets/asset_manifest.json','w'),ensure_ascii=False,indent=2)
if __name__=='__main__': main()
