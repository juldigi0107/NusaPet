#!/usr/bin/env python3
import json,os,shutil
ROOT=os.path.dirname(os.path.dirname(__file__))
def load(r): return json.load(open(os.path.join(ROOT,r),encoding='utf8'))
c=load('data/creatures/creatures.json'); f=load('data/evolutions/primary_forms.json'); a=load('data/armor-forms/armor_forms.json'); x=load('data/cross-evolutions/cross_paths.json'); p=load('data/artifacts/pusaka.json')
real=[z for z in c if z.get('category')=='REAL']; myth=[z for z in c if z.get('category')=='MYTHOLOGY']; myst=[z for z in c if z.get('category')=='MYSTICAL']
checks=[]
def chk(name,ok,detail): checks.append({'name':name,'status':'PASS' if ok else 'BLOCKED','detail':detail})
chk('Content counts',len(c)==350 and len(real)==250 and len(myth)==50 and len(myst)==50,f'{len(c)} total / {len(real)} REAL / {len(myth)} mythology / {len(myst)} mystical')
chk('Primary forms',len(f)==2100,'2100 required')
chk('Armor forms',len(a)>=700,f'{len(a)} available')
chk('Cross paths',len(x)==350,'350 required')
chk('Pusaka',len(p)>=15,f'{len(p)} available')
chk('REAL taxonomy structure',all(all(z.get('factual_data',{}).get('taxonomy',{}).get(k) for k in ['kingdom','phylum','class','order','family','genus','species','rank']) for z in real),'All 250 have structured taxonomy fields')
chk('REAL factual publication',all(z.get('research_record',{}).get('status')=='PUBLISHED' for z in real),'Blocked until external accepted-name/distribution/habitat/conservation/reference review')
chk('Cultural publication',all(z.get('cultural_review',{}).get('status')=='PUBLISHED' for z in myth+myst),'Blocked until cultural-source review')
chk('Godot executable',shutil.which('godot') is not None or shutil.which('godot4') is not None,'Local environment must provide Godot 4.x')
chk('Native SDKs/devices',False,'Not verifiable in this environment; Android/iOS/desktop toolchains and representative device E2E must be executed externally')
report={'project':'NusaPet','generated':'local audit','checks':checks,'release_ready':all(x['status']=='PASS' for x in checks) and shutil.which('godot') is not None}
json.dump(report,open(os.path.join(ROOT,'data/release_readiness.json'),'w',encoding='utf8'),ensure_ascii=False,indent=2)
for x in checks: print(x['status'],x['name'],'—',x['detail'])
print('RELEASE_READY =',report['release_ready'])
