#!/usr/bin/env python3
import json,sys,re
idp=json.load(open('data/localization/id/strings.json')); en=json.load(open('data/localization/en/strings.json'))
errors=[]; warnings=[]
for k in sorted(set(idp)|set(en)):
    if k not in idp or k not in en: errors.append(f'missing translation: {k}'); continue
    for lang,d in [('id',idp),('en',en)]:
        v=str(d[k])
        if not v.strip(): errors.append(f'empty {lang}: {k}')
        if '{{' in v or '}}' in v: warnings.append(f'raw template token {lang}: {k}')
        if len(v)>280: warnings.append(f'long string {lang}: {k}')
report={'errors':errors,'warnings':warnings,'keys_id':len(idp),'keys_en':len(en),'pass':not errors}
json.dump(report,open('data/qa/localization_gate.json','w'),indent=2,ensure_ascii=False)
print(json.dumps(report,indent=2,ensure_ascii=False)); sys.exit(0 if not errors else 1)
