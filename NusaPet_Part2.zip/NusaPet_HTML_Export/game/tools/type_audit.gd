extends SceneTree
func _init():
    var source:=FileAccess.get_file_as_string("res://scripts/creature_visual.gd")
    var main:=FileAccess.get_file_as_string("res://scripts/main.gd")
    var world:=FileAccess.get_file_as_string("res://scripts/world/WorldBuilder.gd")
    var required=["Node3D","Control","Camera3D","MeshInstance3D","GPUParticles3D","StandardMaterial3D"]
    var errors:Array=[]
    for t in required:
        if t not in source and t not in main and t not in world: errors.append("missing native type reference "+t)
    for forbidden in ["HTMLElement","CanvasRenderingContext2D","document.","window.","<html"]:
        if forbidden.to_lower() in (source+main+world).to_lower(): errors.append("web runtime dependency "+forbidden)
    print("TYPE AUDIT: %d errors"%errors.size())
    for e in errors: print("ERROR: "+e)
    if errors.size()>0: quit(1)
    quit(0)
