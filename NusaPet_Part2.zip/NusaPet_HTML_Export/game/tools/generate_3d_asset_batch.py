#!/usr/bin/env python3
"""Generate non-empty, species-differentiated GLB production candidates for a controlled batch.

This is an offline geometry generator, not a biological validation system. Generated files are
marked candidate/unapproved until art + research QA approves them.
"""
from __future__ import annotations
import json, math, os, hashlib
from pathlib import Path
import numpy as np
import trimesh
from trimesh.transformations import translation_matrix, rotation_matrix, scale_matrix

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'assets' / 'generated' / 'creatures'
OUT.mkdir(parents=True, exist_ok=True)

# Batch 1: first 10 REAL species, chosen as a contiguous reviewable unit.
PROFILES = {
 'real_001': dict(body=(1.35,.55,.52), head=(.48,.34,.32), head_pos=(1.15,.02,.15),
                  leg=.62, tail=.95, tail_taper=.20, neck=.32, ears=0, horns=0, crest='scales',
                  snout=1.25, color=(0.32,0.38,0.20), accent=(0.52,0.48,0.25), eye=.075),
 'real_002': dict(body=(1.55,.72,.72), head=(.52,.44,.48), head_pos=(1.28,.02,.22),
                  leg=.65, tail=.50, tail_taper=.12, neck=.38, ears=0, horns=1, crest='folds',
                  snout=.95, color=(0.32,0.31,0.28), accent=(0.50,0.45,0.40), eye=.065),
 'real_003': dict(body=(1.48,.68,.68), head=(.50,.43,.45), head_pos=(1.20,.02,.20),
                  leg=.62, tail=.46, tail_taper=.12, neck=.34, ears=0, horns=2, crest='folds',
                  snout=.98, color=(0.26,0.27,0.23), accent=(0.43,0.38,0.32), eye=.065),
 'real_004': dict(body=(1.12,.48,.58), head=(.46,.36,.40), head_pos=(.82,.02,.35),
                  leg=.72, tail=1.10, tail_taper=.18, neck=.48, ears=0, horns=0, crest='cheek',
                  snout=.80, color=(0.45,0.24,0.12), accent=(0.72,0.43,0.20), eye=.085),
 'real_005': dict(body=(1.14,.49,.60), head=(.47,.37,.41), head_pos=(.84,.02,.36),
                  leg=.74, tail=1.12, tail_taper=.18, neck=.48, ears=0, horns=0, crest='cheek',
                  snout=.82, color=(0.50,0.30,0.15), accent=(0.75,0.48,0.23), eye=.085),
 'real_006': dict(body=(1.02,.48,.56), head=(.46,.39,.40), head_pos=(.78,.02,.40),
                  leg=.68, tail=.82, tail_taper=.15, neck=.52, ears=0, horns=0, crest='nose',
                  snout=1.15, color=(0.38,0.25,0.16), accent=(0.64,0.43,0.27), eye=.075),
 'real_007': dict(body=(.95,.42,.48), head=(.40,.34,.38), head_pos=(.76,.02,.48),
                  leg=.92, tail=1.05, tail_taper=.16, neck=.56, ears=0, horns=0, crest='hands',
                  snout=.78, color=(0.42,0.30,0.18), accent=(0.65,0.48,0.30), eye=.08),
 'real_008': dict(body=(.82,.39,.44), head=(.38,.32,.36), head_pos=(.67,.02,.38),
                  leg=.72, tail=.95, tail_taper=.14, neck=.44, ears=0, horns=0, crest='cheek',
                  snout=.75, color=(0.28,0.22,0.18), accent=(0.55,0.40,0.26), eye=.075),
 'real_009': dict(body=(.88,.40,.46), head=(.39,.32,.36), head_pos=(.72,.02,.40),
                  leg=.70, tail=1.00, tail_taper=.15, neck=.46, ears=0, horns=0, crest='tail',
                  snout=.77, color=(0.26,0.21,0.17), accent=(0.50,0.35,0.22), eye=.075),
 'real_010': dict(body=(1.00,.43,.50), head=(.42,.34,.38), head_pos=(.79,.02,.44),
                  leg=.80, tail=1.20, tail_taper=.16, neck=.58, ears=0, horns=0, crest='throat',
                  snout=.78, color=(0.30,0.25,0.20), accent=(0.62,0.45,0.28), eye=.08),
}
NAMES = {
 'real_001':'Komodo','real_002':'Badak_Jawa','real_003':'Badak_Sumatra','real_004':'Orangutan_Sumatra',
 'real_005':'Orangutan_Kalimantan','real_006':'Bekantan','real_007':'Owa_Jawa','real_008':'Surili_Jawa',
 'real_009':'Lutung_Jawa','real_010':'Siamang'
}
STAGE_SCALE = [0.26,0.42,0.62,0.82,1.0,1.06]

def mat(color, rough=.72, metallic=0.0):
    m = trimesh.visual.material.PBRMaterial(
        baseColorFactor=tuple(int(max(0,min(1,c))*255) for c in color)+(255,),
        metallicFactor=metallic, roughnessFactor=rough)
    return m

def add_ellipsoid(scene, name, pos, scale, material, seg=18, rings=10):
    seg=max(int(seg),8); rings=max(int(rings),6)
    mesh = trimesh.creation.uv_sphere(radius=1.0, count=[seg,rings])
    mesh.apply_scale(scale)
    mesh.apply_translation(pos)
    mesh.visual.material = material
    scene.add_geometry(mesh, geom_name=name, node_name=name, transform=trimesh.transformations.identity_matrix())

def add_cyl(scene, name, a, b, radius, material, sections=12):
    a,b=np.array(a,float),np.array(b,float); v=b-a; L=np.linalg.norm(v)
    if L < 1e-5: return
    mesh=trimesh.creation.cylinder(radius=radius, height=L, sections=sections)
    z=np.array([0,0,1.]); axis=v/L; dot=np.clip(np.dot(z,axis),-1,1)
    if dot < .999999:
        rot_axis=np.cross(z,axis); rot_axis/=np.linalg.norm(rot_axis)
        ang=math.acos(dot); mesh.apply_transform(rotation_matrix(ang,rot_axis))
    mesh.apply_translation((a+b)/2)
    mesh.visual.material = material
    scene.add_geometry(mesh, geom_name=name, node_name=name)

def add_cone(scene, name, pos, radius, height, material, direction=(1,0,0)):
    mesh=trimesh.creation.cone(radius=radius, height=height, sections=14)
    axis=np.array(direction,float); axis/=np.linalg.norm(axis); z=np.array([0,0,1.])
    dot=np.clip(np.dot(z,axis),-1,1)
    if dot < .999999:
        ra=np.cross(z,axis); ra/=np.linalg.norm(ra); mesh.apply_transform(rotation_matrix(math.acos(dot),ra))
    mesh.apply_translation(pos)
    mesh.visual.material = material
    scene.add_geometry(mesh, geom_name=name, node_name=name)

def build(creature, stage):
    p=PROFILES[creature]; s=STAGE_SCALE[stage-1]
    scene=trimesh.Scene()
    base=mat(p['color']); accent=mat(p['accent']); dark=mat(tuple(max(0,c*.32) for c in p['color']))
    # stage 1 is an embryonic, curled silhouette with species-specific head/tail/horn buds.
    if stage == 1:
        add_ellipsoid(scene,'EmbryoCore',(0,0,.25),(p['body'][0]*.65,p['body'][1]*.75,p['body'][2]*.65),base)
        add_ellipsoid(scene,'EmbryoHead',(p['head_pos'][0]*.55,0,.42),(p['head'][0]*.55,p['head'][1]*.60,p['head'][2]*.60),accent)
        add_cyl(scene,'EmbryoTail',(0,0,.18),(-p['tail']*.45,0,.12),max(.045,p['tail_taper']*.55),dark)
        if p['horns']: add_cone(scene,'HornBud',(p['head_pos'][0]*.52,-.20,.62),.07,.18,accent,(0,-1,.3))
    else:
        bs=[x*s for x in p['body']]
        add_ellipsoid(scene,'Body',(0,0,bs[2]+.18),bs,base)
        hp=np.array(p['head_pos'])*s; hs=np.array(p['head'])*s
        add_ellipsoid(scene,'Head',hp,hs,base)
        # muzzle / snout is species-specific in length and position
        sn=.20*p['snout']*s
        add_ellipsoid(scene,'Muzzle',(hp[0]+hs[0]*.62,0,hp[2]-hs[2]*.08),(sn,hs[1]*.60,hs[2]*.55),accent)
        # eyes + pupils, mirrored
        for side in (-1,1):
            add_ellipsoid(scene,f'Eye_{side}',(hp[0]+hs[0]*.38,side*hs[1]*.83,hp[2]+hs[2]*.18),(p['eye']*s,p['eye']*.75*s,p['eye']*s),mat((.92,.92,.82),.3))
            add_ellipsoid(scene,f'Pupil_{side}',(hp[0]+hs[0]*.43,side*hs[1]*.94,hp[2]+hs[2]*.18),(p['eye']*.42*s,p['eye']*.20*s,p['eye']*.48*s),dark)
        # legs, with primate forelimbs deliberately longer for species 004-010
        leg=p['leg']*s
        fore_long = creature in {'real_004','real_005','real_006','real_007','real_008','real_009','real_010'}
        for i,(x,y) in enumerate([(bs[0]*.55,-bs[1]*.72),(bs[0]*.55,bs[1]*.72),(-bs[0]*.55,-bs[1]*.72),(-bs[0]*.55,bs[1]*.72)]):
            L=leg*(1.18 if fore_long and i<2 else 1.0)
            hip=np.array([x,y,bs[2]*.75+.18]); foot=np.array([x*(.72 if i<2 else 1.0),y*.78,.16])
            add_cyl(scene,f'Leg_{i}_upper',hip,hip+(foot-hip)*.55,.10*s,accent)
            add_cyl(scene,f'Leg_{i}_lower',hip+(foot-hip)*.55,foot,.075*s,base)
            add_ellipsoid(scene,f'Foot_{i}',foot,(.18*s,.11*s,.07*s),dark)
        # tail: segmented, tapered, curved
        tail=p['tail']*s
        if tail>.2:
            pts=[(-bs[0]*.75,0,bs[2]+.20),(-bs[0]-tail*.28,-.02,bs[2]+.12),(-bs[0]-tail*.60,.04,bs[2]*.75),(-bs[0]-tail,0,.55)]
            for j in range(3): add_cyl(scene,f'Tail_{j}',pts[j],pts[j+1],max(.045,(.15-j*.035)*s),accent if j==0 else base)
        # species identifiers
        crest=p['crest']
        if creature=='real_001':
            # dorsal scute line for Komodo
            for i in range(7): add_cone(scene,f'Scute_{i}',(-bs[0]*.45+i*bs[0]*.13,0,bs[2]*1.02+.20),.075*s,.16*s,accent,(0,0,1))
        elif creature in {'real_002','real_003'}:
            # rhino horn(s) + ear folds
            add_cone(scene,'NasalHorn',(hp[0]+hs[0]*.72,0,hp[2]+.02),.13*s,.38*s,accent,(1,0,.25))
            if creature=='real_003': add_cone(scene,'SecondHorn',(hp[0]+hs[0]*.50,0,hp[2]+hs[2]*.35),.08*s,.20*s,accent,(1,0,.35))
            for side in (-1,1): add_ellipsoid(scene,f'Ear_{side}',(hp[0]-.05*s,side*hs[1]*.78,hp[2]+hs[2]*.68),(.13*s,.07*s,.18*s),accent)
        elif creature in {'real_004','real_005'}:
            # long arms + cheek fur panels
            for side in (-1,1): add_ellipsoid(scene,f'Cheek_{side}',(hp[0]+.02*s,side*hs[1]*.72,hp[2]),(.18*s,.12*s,.28*s),accent)
        elif creature=='real_006':
            # very pronounced primate nose
            add_ellipsoid(scene,'Nose',(hp[0]+hs[0]*.75,0,hp[2]-.02*s),(.18*s,.17*s,.22*s),accent)
        elif creature=='real_007':
            # long arms and pale facial disc
            add_ellipsoid(scene,'FaceDisc',(hp[0]+.02*s,0,hp[2]+.02*s),(hs[0]*.78,hs[1]*.92,hs[2]*.80),accent)
        elif creature in {'real_008','real_009'}:
            for side in (-1,1): add_ellipsoid(scene,f'FaceMark_{side}',(hp[0]+.02*s,side*hs[1]*.72,hp[2]+.02*s),(.20*s,.05*s,.24*s),accent)
        elif creature=='real_010':
            # throat pouch for Siamang
            add_ellipsoid(scene,'ThroatPouch',(hp[0]-.02*s,0,hp[2]-.30*s),(.22*s,.22*s,.30*s),accent)
        # stage 5-6 game-form resonance details, without replacing species anatomy
        if stage >= 5:
            ring_r=max(bs[1]*1.55,.65*s)
            for k in range(8):
                a=2*math.pi*k/8
                pos=(0,math.cos(a)*ring_r,bs[2]+.18+math.sin(a)*.10)
                add_ellipsoid(scene,f'Resonance_{k}',pos,(.035*s,.035*s,.14*s),accent,.10,6)
        # metadata as scene extras for traceability
    scene.metadata.update({'asset_id':f'{creature}_s{stage}','creature_id':creature,'stage':stage,'generator':'NusaPet offline asset batch generator v1','approval':'UNAPPROVED_CANDIDATE'})
    return scene

def main():
    creatures=json.load(open(ROOT/'data/creatures/creatures.json'))
    selected=[x for x in creatures if x['id'] in PROFILES]
    manifest=json.load(open(ROOT/'data/assets/asset_manifest.json'))
    by={x['asset_id']:x for x in manifest['items']}
    report=[]
    for c in selected:
        for stage in range(1,7):
            aid=f"{c['id']}_s{stage}"; path=OUT/f'{aid}.glb'
            scene=build(c['id'],stage)
            scene.export(path, file_type='glb')
            sha=hashlib.sha256(path.read_bytes()).hexdigest()
            by[aid]['resource_path']=f'res://assets/generated/creatures/{aid}.glb'
            by[aid]['approved']=False
            by[aid]['fallback']='NONE_ASSET_PRESENT_PENDING_ART_QA'
            report.append({'asset_id':aid,'path':by[aid]['resource_path'],'sha256':sha,'size_bytes':path.stat().st_size,'status':'CANDIDATE_REVIEW'})
    # Add explicit candidate provenance and batch record.
    manifest['asset_generation_batches']=manifest.get('asset_generation_batches',[])
    manifest['asset_generation_batches'].append({'batch':'B01','scope':'real_001..real_010, stages 1-6','status':'CANDIDATE_REVIEW','tool':'offline_trimesh_generator_v1','approval_required':True})
    with open(ROOT/'data/assets/asset_manifest.json','w') as f: json.dump(manifest,f,ensure_ascii=False,indent=2)
    out=ROOT/'data/qa/asset_batch_B01.json'; json.dump({'batch':'B01','count':len(report),'assets':report,'status':'CANDIDATE_REVIEW','note':'Geometry is non-empty and species-differentiated, but biological/art approval is still required.'},open(out,'w'),ensure_ascii=False,indent=2)
    print(f'Generated {len(report)} GLBs -> {OUT}')
    print(f'Report -> {out}')

if __name__=='__main__': main()
