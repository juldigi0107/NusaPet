#!/usr/bin/env python3
"""Static UI contract gate for the native Control layout.

Runtime viewport overlap still requires Godot/device execution; this gate checks that
production UI uses adaptive containers, scrolling, text expansion and accessible sizing.
"""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'scripts/main.gd').read_text()
onboard=(ROOT/'scripts/onboarding.gd').read_text()
checks={
 'main_scroll_container':'ScrollContainer.new()' in main,
 'main_adaptive_content':'SIZE_EXPAND_FILL' in main,
 'bottom_navigation':'PRESET_BOTTOM_WIDE' in main,
 'touch_input':'InputEventScreenTouch' in main,
 'pinch_zoom':'InputEventMagnifyGesture' in main,
 'text_scale_setting':'set_text_scale' in main,
 'button_minimum_size':'custom_minimum_size=Vector2(0,64)' in main,
 'onboarding_autowrap':'AUTOWRAP_WORD_SMART' in onboard,
 'onboarding_button_size':'custom_minimum_size = Vector2(0, 68)' in onboard,
}
print(json.dumps({'pass':all(checks.values()),'checks':checks,'native_runtime_required':True},indent=2))
raise SystemExit(0 if all(checks.values()) else 2)
