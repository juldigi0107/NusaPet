#!/usr/bin/env python3
import json,re,pathlib,datetime,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
MASTER=ROOT.parent.parent/'NusaPet_MASTER_PROMPT_GODOT_3D_FULL_UNABRIDGED.txt'
if not MASTER.exists():
    MASTER=pathlib.Path('/mnt/data/NusaPet_MASTER_PROMPT_GODOT_3D_FULL_UNABRIDGED.txt')
text=MASTER.read_text(encoding='utf-8')
heads=[]
for m in re.finditer(r'^#\s+(\d+)\.\s+(.+)$',text,re.M):
    n=int(m.group(1)); title=m.group(2).strip()
    if 0 <= n <= 305: heads.append((n,title))
files={str(p.relative_to(ROOT)):p.read_text(errors='ignore') for p in ROOT.rglob('*') if p.is_file() and p.suffix in {'.gd','.py','.json','.md','.cfg','.tscn'}}
joined='\n'.join(files.values()).lower()
keywords={
 'QA':'audit','save':'save','evolution':'evolution','pusaka':'pusaka','armor':'armor','resonance':'resonance',
 'nusapedia':'nusapedia','localization':'localization','mobile':'android','performance':'performance','3d':'meshinstance3d',
 'privacy':'privacy','analytics':'analytics','legacy':'legacy','sanctuary':'sanctuary','research':'research','cultural':'cultural'
}
rows=[]
for n,title in heads:
    low=title.lower(); hits=[]
    for key,token in keywords.items():
        if key in low and token in joined: hits.append(key)
    rows.append({'section':n,'title':title,'evidence_tokens':hits,'status':'TRACEABLE' if hits else 'REVIEW'})
# This report is traceability, not a completion gate.
out={'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'master_sections':len(rows),'sections':rows,'policy':'Traceability only; no section is declared complete from keyword evidence.'}
path=ROOT/'data/qa/master_traceability_audit.json'; path.write_text(json.dumps(out,indent=2,ensure_ascii=False),encoding='utf-8')
print(f'TRACEABILITY sections={len(rows)} review={sum(r["status"]=="REVIEW" for r in rows)}')
