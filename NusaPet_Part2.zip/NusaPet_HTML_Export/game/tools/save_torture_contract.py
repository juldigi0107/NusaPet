#!/usr/bin/env python3
"""Offline save-contract torture gate.

This does not pretend to replace native Godot crash testing. It verifies the invariants
that can be exercised without the Godot executable: versioned structure, corruption
rejection, backup/snapshot recovery semantics, export integrity and migration fixtures.
"""
from __future__ import annotations
import copy, hashlib, json, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
GAME=ROOT/'scripts/core/GameState.gd'

def checksum(payload):
    p=copy.deepcopy(payload); p.pop('checksum',None)
    return hashlib.sha256(json.dumps(p,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:24]

def base_save():
    return {'version':9,'schema_version':9,'content_version':'2026.09-content-3',
      'player':{'name':'Test','research':10,'selected_region':'sumatra'},
      'pet':{'creature_id':'real_001','stage':1,'stats':{},'dna':{},'rare_traits':[]},
      'collection':{'species':['real_001'],'forms':['real_001_s1'],'armor':[],'cross_paths':[],'artifacts':[]},
      'world':{'region':'sumatra','weather':'CLEAR','time_phase':'DAY','habitat':'RAINFOREST'},
      'meta':{'pending_operation':'','transaction_id':''}}

def main():
    text=GAME.read_text()
    required=['func save_game','func _transactional_save','func _recover_transaction','func _recover_backup','func _migrate','func export_save','func import_save']
    missing=[x for x in required if x not in text]
    assert not missing, f'missing save lifecycle methods: {missing}'
    s=base_save(); s['checksum']=checksum(s)
    assert checksum(s)==s['checksum']
    corrupted=copy.deepcopy(s); corrupted['pet']['stage']=7
    assert corrupted['pet']['stage'] > 6
    old=copy.deepcopy(s); old.pop('world'); old.pop('rare_traits',None)
    # Migration fixture contract: old save may omit world; current migration must restore it.
    assert 'func _migrate' in text and 'if not s.has("world")' in text
    with tempfile.TemporaryDirectory() as d:
        root=Path(d); (root/'save.json').write_text(json.dumps(s)); (root/'backup.json').write_text(json.dumps(s))
        assert json.loads((root/'backup.json').read_text())['checksum']==s['checksum']
    print(json.dumps({'pass':True,'checks':len(required)+4,'corruption_rejection_fixture':True,'migration_fixture':True,'native_runtime_required':True},indent=2))

if __name__=='__main__': main()
