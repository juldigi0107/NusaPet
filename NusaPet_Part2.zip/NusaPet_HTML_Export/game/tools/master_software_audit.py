#!/usr/bin/env python3
"""Static implementation gate for software-addressable Master Prompt requirements."""
import json, os, re, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
errors=[]; warnings=[]
def exists(p):
    if not (ROOT/p).exists(): errors.append(f"missing {p}")
required=[
 "project.godot","export_presets.cfg","scripts/core/GameState.gd","scripts/main.gd","scripts/creature_3d_runtime.gd","scripts/creature_animation_controller.gd","scripts/world/WorldBuilder.gd","scripts/share_card.gd",
 "scripts/adapters/AuthAdapter.gd","scripts/adapters/CloudSaveAdapter.gd","scripts/adapters/StorageAdapter.gd","tools/static_audit.gd","tools/type_audit.gd","tests/run_unit_tests.gd","tests/validate_content.gd",
 "data/artifacts/pusaka.json","data/artifacts/dual_resonance.json","data/resonance/resonance_forms.json","data/items/food.json","data/system/feature_flags.json","data/system/asset_packs.json","data/privacy/privacy_policy.json"]
for p in required: exists(p)
proj=(ROOT/"project.godot").read_text()
if 'Node3D' not in (ROOT/'scripts/main.gd').read_text(): errors.append('main runtime lacks Node3D')
if 'RuntimePerformance=' not in proj: errors.append('runtime performance autoload missing')
# content counts
load=lambda p: json.loads((ROOT/p).read_text())
creatures=load('data/creatures/creatures.json'); forms=load('data/evolutions/primary_forms.json'); armor=load('data/armor-forms/armor_forms.json'); cross=load('data/cross-evolutions/cross_paths.json'); pusaka=load('data/artifacts/pusaka.json')
if len(creatures)!=350: errors.append('creatures != 350')
if len(forms)!=2100: errors.append('forms != 2100')
if len(armor)<700: errors.append('armor < 700')
if len(cross)!=350: errors.append('cross != 350')
if len(pusaka)!=15: errors.append('pusaka != 15')
# explicit master capabilities
checks={
 'interaction':'CreatureInteractionArea', 'animation':'AnimationNodeStateMachine', 'weather':'set_weather', 'performance':'set_performance_profile', 'offline':'offline_evolution_pending', 'transactions':'_transactional_save', 'snapshot':'_snapshot_before_critical', 'cloud_conflict':'merge_cloud_state', 'storage':'storage_status', 'accessibility':'set_accessibility', 'share_card':'NusaShareCard', 'research_levels':'research_levels', 'sanctuary':'add_companion_from_current', 'legacy':'archive_current_to_legacy', 'generation':'start_new_generation', 'rare_traits':'rare_traits', 'world_state':'state.world', 'ui_probe':'run_probe', 'team':'start_team_expedition', 'dual':'try_dual_resonance', 'perfect_resonance':'try_perfect_resonance', 'feature_flags':'feature_flags.json'}
alltext=''.join((ROOT/p).read_text(errors='ignore') for p in ['scripts/main.gd','scripts/core/GameState.gd','scripts/creature_3d_runtime.gd','scripts/creature_animation_controller.gd','scripts/world/WorldBuilder.gd','scripts/share_card.gd','scripts/core/FeatureFlags.gd','tests/ui_viewport_contract.gd'])
for name,needle in checks.items():
    if needle not in alltext and needle not in proj and (ROOT/'data/system/feature_flags.json').exists() and name=='feature_flags':
        continue
    if needle not in alltext and needle not in proj: errors.append(f'missing software capability: {name}')
# no obvious web core
for bad in ['document.','window.','CanvasRenderingContext2D','<html']:
    if bad.lower() in alltext.lower(): errors.append('web runtime dependency '+bad)
report={'errors':errors,'warnings':warnings,'counts':{'creatures':len(creatures),'forms':len(forms),'armor':len(armor),'cross':len(cross),'pusaka':len(pusaka)},'software_gate_pass':not errors,'external_gates':['native Godot execution','native platform builds/devices','scientific publication','cultural publication','final art approval','final production audio','visual/performance regression']}
(ROOT/'data/qa/master_software_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(report,indent=2)); sys.exit(0 if not errors else 2)
