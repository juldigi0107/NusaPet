#!/usr/bin/env python3
"""Generate structured 3D art prompts from NusaPet creature data and Art Bible."""
import argparse,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def main():
 p=argparse.ArgumentParser();p.add_argument('--creature',required=True);p.add_argument('--stage',type=int,default=1);p.add_argument('--armor',default='');p.add_argument('--affinity',default='');a=p.parse_args()
 data=json.load(open(ROOT/'data/creatures/creatures.json')); c=next(x for x in data if x['id']==a.creature)
 profile=json.load(open(ROOT/'data/creatures/creature_3d_profiles_v10.json'))[a.creature]
 return print(json.dumps({'asset_id':f"{a.creature}_s{a.stage}",'species':c.get('name_id'),'scientific_name':c.get('scientific_name'),'stage':a.stage,'taxonomy':c.get('factual_data',{}).get('taxonomy',{}),'archetype':c.get('archetype'),'morphology_signature':profile.get('signature',[]),'habitat':c.get('habitat'),'affinity':a.affinity,'armor':a.armor,'style':'NusaPet premium stylized 3D; readable silhouette; original design; subtle PBR; species-specific anatomy; Nusantara-inspired restraint','negative':['generic creature','photorealism','franchise imitation','humanoid robot armor','anatomically impossible limbs','floating armor']},indent=2,ensure_ascii=False))
if __name__=='__main__':main()
