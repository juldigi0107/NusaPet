#!/usr/bin/env python3
import json, os, re, hashlib, pathlib, datetime
ROOT=pathlib.Path(__file__).resolve().parents[1]
def load(rel): return json.loads((ROOT/rel).read_text(encoding="utf8"))
c=load("data/creatures/creatures.json"); f=load("data/evolutions/primary_forms.json")
a=load("data/armor-forms/armor_forms.json"); x=load("data/cross-evolutions/cross_paths.json"); p=load("data/artifacts/pusaka.json")
real=[z for z in c if z.get("category")=="REAL"]; myth=[z for z in c if z.get("category")=="MYTHOLOGY"]; myst=[z for z in c if z.get("category")=="MYSTICAL"]
def files(ext):
    return [q for q in ROOT.rglob("*") if q.is_file() and q.suffix.lower() in ext]
scenes=files({".tscn"})
empty_scenes=[]
for q in scenes:
    t=q.read_text(errors="replace")
    if t.count("[node ")<=1 and "script =" not in t: empty_scenes.append(str(q.relative_to(ROOT)))
manifest=load("data/assets/asset_manifest.json")
asset_refs=[r.get("resource_path") for r in manifest.get("items",[])]
physical_3d=[q for q in ROOT.rglob("*") if q.is_file() and q.suffix.lower() in {".glb",".gltf",".fbx",".obj",".blend",".tscn"} and "scenes" not in q.parts]
research_unpublished=sum(z.get("research_record",{}).get("status")!="PUBLISHED" for z in real)
cultural_unpublished=sum(z.get("cultural_review",{}).get("status")!="PUBLISHED" for z in myth+myst)
report={
 "generated_at":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "content":{"creatures":len(c),"real":len(real),"mythology":len(myth),"mystical":len(myst),"primary":len(f),"armor":len(a),"cross_paths":len(x),"pusaka":len(p)},
 "runtime":{"godot_project":(ROOT/"project.godot").exists(),"physical_3d_assets":len(physical_3d),"empty_scenes":empty_scenes},
 "research":{"real_unpublished":research_unpublished,"cultural_unpublished":cultural_unpublished},
 "architecture_findings":{
   "web_core_dependency":False,
   "native_scene_architecture":True,
   "procedural_fallback_present":True,
   "final_asset_paths_missing":sum(1 for r in asset_refs if not r),
   "final_asset_paths_present":sum(1 for r in asset_refs if r),
   "final_asset_unapproved":sum(1 for r in manifest.get("items",[]) if not r.get("approved",False)),
   "release_blocker":"Final production 3D assets and external factual/cultural review remain incomplete."
 },
 "status":"NOT_RELEASE_READY"
}
out=ROOT/"data/qa/deep_audit.json"; out.write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf8")
print(json.dumps(report,indent=2,ensure_ascii=False))
