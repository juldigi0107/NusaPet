extends SceneTree
func _init():
    var required=[
        "res://scenes/boot/Boot.tscn","res://scenes/main/Main.tscn","res://scenes/habitat/Habitat.tscn",
        "res://scenes/creature/Creature.tscn","res://scenes/exploration/ExplorationWorld.tscn",
        "res://scenes/exploration/RegionMap3D.tscn","res://scenes/evolution/EvolutionScene.tscn",
        "res://scenes/evolution/EvolutionNetwork.tscn","res://scenes/pusaka/PusakaVault.tscn",
        "res://scenes/armor/ArmorTransformation.tscn","res://scenes/resonance/ResonanceScene.tscn",
        "res://scenes/encyclopedia/Nusapedia.tscn","res://scenes/collection/Collection.tscn",
        "res://scenes/ui/HUD.tscn","res://scenes/ui/PauseMenu.tscn","res://scenes/ui/Settings.tscn",
        "res://scenes/onboarding/Onboarding.tscn","res://scenes/recovery/RecoveryScene.tscn","res://scenes/dev/ContentAuditDashboard.tscn"
    ]
    var errors:Array=[]
    for p in required:
        if not FileAccess.file_exists(p): errors.append("missing scene "+p)
    for p in ["res://scripts/core/GameState.gd","res://scripts/main.gd","res://scripts/world/WorldBuilder.gd","res://scripts/creature_visual.gd","res://scripts/habitat.gd","res://scripts/region_map_3d.gd","res://scripts/dev_content_audit.gd"]:
        if not FileAccess.file_exists(p): errors.append("missing source "+p)
    if not FileAccess.file_exists("res://data/system/feature_flags.json"): errors.append("missing feature flags")
    var project=ProjectSettings.get_setting("application/config/features",PackedStringArray())
    if "4.3" not in project: errors.append("Godot 4.x feature marker missing")
    print("STATIC AUDIT: %d errors"%errors.size())
    for e in errors: print("ERROR: "+e)
    if errors.size()>0: quit(1)
    quit(0)
