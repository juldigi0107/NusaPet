#!/usr/bin/env python3
"""Deterministic virtual-player simulation for Master Prompt sections 217-219/294-295."""
import json, os, random, statistics
ROOT=os.path.dirname(os.path.dirname(__file__))
cross=json.load(open(os.path.join(ROOT,"data/cross-evolutions/cross_paths.json"),encoding="utf8"))
armor=json.load(open(os.path.join(ROOT,"data/armor-forms/armor_forms.json"),encoding="utf8"))
styles=["perfect","poor","explorer","researcher","trainer","balanced","pusaka"]
N=2000

def run(seed,style):
    r=random.Random(seed); dna={k:v for k,v in {"care":20,"strength":10,"mind":15,"bond":15,"adventure":5,"nature":10,"mystic":5,"discipline":5}.items()}
    bond=15; research=0; explored=0; stage=1; branch=None; branch_id=None; pusaka_mastery={}; habitats={h:0 for h in ["RAINFOREST","MOUNTAIN","SAVANNA","RIVER","OCEAN","MANGROVE","CAVE","VILLAGE","MYSTICAL"]}
    for day in range(240):
        if style in ("perfect","balanced"): dna["care"]=min(100,dna["care"]+2); bond=min(100,bond+2)
        if style in ("explorer","balanced","pusaka"): dna["adventure"]=min(100,dna["adventure"]+3); explored+=1
        if style=="researcher": dna["mind"]=min(100,dna["mind"]+4); research+=3
        if style=="trainer": dna["discipline"]=min(100,dna["discipline"]+4); dna["strength"]=min(100,dna["strength"]+2)
        if style=="pusaka": pusaka_mastery["x"]=min(100,pusaka_mastery.get("x",0)+1)
        if style=="poor": dna["care"]=max(0,dna["care"]-1); bond=max(0,bond-1)
        habitats["RAINFOREST"]+=1 if day%2==0 else 0
        score=sum(dna.values())+bond+research*.05+explored*.15
        need=100+(stage-1)*45
        if score>=need and stage<6:
            stage+=1
            if stage==5 and not branch:
                eligible=[e for e in cross if int(e.get("minimum_stage",4))<=4]
                if eligible and (research>=20 or explored>0):
                    e=eligible[(seed+explored+bond+int(dna["adventure"]))%len(eligible)]
                    branch=e["target"].rsplit("_s",1)[0]; branch_id=e["id"]
    return {"stage":stage,"branch_id":branch_id,"mastery":max(pusaka_mastery.values(),default=0)}

summary={}; branch_counts={}
for style in styles:
    vals=[run(i,style) for i in range(N)]
    summary[style]={"mean_stage":statistics.mean(v["stage"] for v in vals),"stage6_rate":sum(v["stage"]>=6 for v in vals)/N,"cross_rate":sum(bool(v["branch_id"]) for v in vals)/N,"mastery_mean":statistics.mean(v["mastery"] for v in vals)}
    for v in vals:
        if v["branch_id"]: branch_counts[v["branch_id"]]=branch_counts.get(v["branch_id"],0)+1
max_share=max(branch_counts.values(),default=0)/N
out={"runs":N,"styles":summary,"cross_total":len(cross),"armor_total":len(armor),"branch_distribution":{"unique_branches_hit":len(branch_counts),"max_single_branch_share":max_share,"pass_under_80_percent":max_share<=0.80},"requirements":["perfect care","poor care","explorer","researcher","trainer","balanced","Pusaka-focused"]}
json.dump(out,open(os.path.join(ROOT,"data/simulation_report.json"),"w"),ensure_ascii=False,indent=2)
print(json.dumps(out,indent=2))
raise SystemExit(0 if max_share<=0.80 else 2)
