#!/usr/bin/env python3
"""Generate anatomy-aware armor candidates for every armor form."""
import json,math,hashlib
from pathlib import Path
import numpy as np,trimesh
from trimesh.transformations import rotation_matrix
ROOT=Path(__file__).resolve().parents[1]; OUT=ROOT/'assets/generated/armor'; OUT.mkdir(parents=True,exist_ok=True)
AFF={'RIMBA':((.20,.42,.16),(.48,.72,.24)),'SAMUDRA':((.10,.32,.46),(.25,.62,.82)),'BARA':((.48,.14,.05),(.95,.30,.06)),'PETIR':((.16,.23,.48),(.48,.68,1.0)),'SURYA':((.55,.36,.04),(.98,.72,.16)),'ANGIN':((.42,.58,.70),(.72,.88,1.0)),'HUJAN':((.08,.27,.36),(.22,.62,.74)),'BULAN':((.28,.24,.46),(.68,.58,.98)),'NISKALA':((.30,.22,.46),(.62,.48,.96))}
def mat(c,metal=.45,rough=.35): return trimesh.visual.material.PBRMaterial(baseColorFactor=tuple(int(x*255) for x in c)+(255,),metallicFactor=metal,roughnessFactor=rough)
def ell(sc,n,p,s,m):
 x=trimesh.creation.uv_sphere(radius=1,count=[12,8]);x.apply_scale(s);x.apply_translation(p);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def cyl(sc,n,a,b,r,m):
 a=np.array(a,float);b=np.array(b,float);v=b-a;L=np.linalg.norm(v);x=trimesh.creation.cylinder(radius=r,height=L,sections=10);z=np.array([0,0,1]);u=v/L;d=np.clip(np.dot(z,u),-1,1)
 if d<.999999:
  ra=np.cross(z,u);ra/=np.linalg.norm(ra);x.apply_transform(rotation_matrix(math.acos(d),ra))
 x.apply_translation((a+b)/2);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def box(sc,n,p,s,m):
 x=trimesh.creation.box(extents=s);x.apply_translation(p);x.visual.material=m;sc.add_geometry(x,geom_name=n,node_name=n)
def family(c):
 t=c.get('factual_data',{}).get('taxonomy',{}); cls=(t.get('class') or '').lower(); order=(t.get('order') or '').lower()
 if 'aves' in cls:return 'bird'
 if 'actinopterygii' in cls or 'chondrichthyes' in cls:return 'fish'
 if 'amphibia' in cls:return 'amphibian'
 if any(x in cls for x in ('insecta','arachnida','myriapoda')):return 'arthropod'
 if 'mollusca' in cls:return 'cephalopod'
 if 'mammalia' in cls and order in ('cetacea','sirenia'):return 'aquatic_mammal'
 if 'mammalia' in cls and order=='chiroptera':return 'bat'
 if 'mammalia' in cls and order=='primates':return 'primate'
 if 'reptilia' in cls and order=='testudines':return 'turtle'
 if 'reptilia' in cls:return 'reptile'
 return 'quadruped'
def build(a,c):
 h=int(hashlib.sha256(a['id'].encode()).hexdigest()[:8],16); f=family(c); base,glow=AFF.get(a['artifact_affinity'],((.3,.3,.3),(.7,.7,.7))); ma=mat(base); gm=mat(glow,.72,.24); dark=mat(tuple(x*.38 for x in base),.55,.45)
 s=.82+(h%1000)/1000*.34; sc=trimesh.Scene()
 # anchor plate follows morphology family rather than one generic chest block
 if f in ('fish','aquatic_mammal','cephalopod'):
  ell(sc,'CoreHarness',(0,0,1.15),(1.05*s,.55*s,.30*s),ma); box(sc,'VentralGuard',(-.12*s,0,.86),(1.10*s,.40*s,.12*s),dark)
 elif f=='bird' or f=='bat':
  ell(sc,'KeelHarness',(0,0,1.22),(.55*s,.42*s,.62*s),ma); box(sc,'WingRootGuard',(0,.62*s,1.18),(.72*s,.10*s,.22*s),gm); box(sc,'WingRootGuard_L',(0,-.62*s,1.18),(.72*s,.10*s,.22*s),gm)
 elif f in ('arthropod','turtle','reptile'):
  ell(sc,'CarapacePlate',(0,0,1.30),(.92*s,.68*s,.42*s),ma); box(sc,'VentralLock',(0,0,.93),(.90*s,.36*s,.12*s),dark)
 else:
  ell(sc,'ChestPlate',(0,0,1.22),(.82*s,.58*s,.55*s),ma); box(sc,'SpineGuard',(-.18*s,0,1.52),(.65*s,.30*s,.14*s),dark)
 ell(sc,'EnergyCore',(.55*s,-.55*s,1.22),(.13*s,.07*s,.13*s),gm)
 # affinity signature geometry
 if a['artifact_affinity'] in ('ANGIN','PETIR','BADAI'):
  for side in (-1,1):
   box(sc,f'VectorFin_{side}',(-.05*s,side*.78*s,1.32),(1.05*s,.07*s,.20*s),gm)
 elif a['artifact_affinity'] in ('RIMBA','GUNUNG','BATU'):
  for i in range(5): ell(sc,f'NaturalRivet_{i}',(-.45*s+i*.22*s,0,1.58),(.06*s,.08*s,.09*s),gm)
 elif a['artifact_affinity'] in ('SAMUDRA','HUJAN'):
  for i in range(4): ell(sc,f'WaterScale_{i}',(-.30*s+i*.20*s,0,.88),(.08*s,.08*s,.13*s),gm)
 else:
  for i in range(6):
   a0=2*math.pi*i/6; ell(sc,f'AuraShard_{i}',(math.cos(a0)*.78*s,math.sin(a0)*.58*s,1.18),(.045*s,.045*s,.18*s),gm)
 # anatomy-specific limb attachments
 if f in ('quadruped','primate','reptile','amphibian'):
  for side in (-1,1):
   for x in (-.50,.50): cyl(sc,f'LimbGuard_{side}_{x}',(x*s,side*.55*s,1.05),(x*s,side*.57*s,.45),.075*s,ma)
 elif f=='bird' or f=='bat':
  for side in (-1,1): box(sc,f'WingEdge_{side}',(-.28*s,side*1.02*s,1.25),(.82*s,.055*s,.09*s),gm)
 elif f=='fish':
  for side in (-1,1): box(sc,f'FinBrace_{side}',(.05*s,side*.75*s,1.12),(.48*s,.05*s,.16*s),gm)
 elif f=='arthropod':
  for i in range(6): cyl(sc,f'LegSegment_{i}',(-.25*s+(i%3)*.25*s,(-1 if i%2==0 else 1)*.72*s,1.0),(-.35*s+(i%3)*.25*s,(-1 if i%2==0 else 1)*1.0*s,.72),.04*s,ma)
 elif f=='turtle':
  for i in range(6): ell(sc,f'ShellRivet_{i}',(-.50*s+i*.20*s,0,1.58),(.055*s,.055*s,.055*s),gm)
 # transformation anchors
 for i,p in enumerate([(-.55,-.38,.38),(.55,-.38,.38),(-.55,.38,.38),(.55,.38,.38)]): ell(sc,f'Anchor_{i}',p,(.05*s,.05*s,.05*s),dark)
 sc.metadata.update({'asset_id':a['id'],'base_creature':c['id'],'affinity':a['artifact_affinity'],'morphology_family':f,'generator':'NusaPet anatomy-aware armor generator v2','approval':'UNAPPROVED_CANDIDATE'})
 return sc
def main():
 arm=json.load(open(ROOT/'data/armor-forms/armor_forms.json')); manifest=json.load(open(ROOT/'data/assets/asset_manifest.json')); by={x['asset_id']:x for x in manifest['items']}; creatures={x['id']:x for x in json.load(open(ROOT/'data/creatures/creatures.json'))}; created=0
 for idx,a in enumerate(arm,1):
  p=OUT/f"{a['id']}.glb"; build(a,creatures[a['base_creature']]).export(p,file_type='glb'); created+=1
  by[a['id']]['resource_path']=f'res://assets/generated/armor/{a["id"]}.glb';by[a['id']]['approved']=False;by[a['id']]['fallback']='NONE_ASSET_PRESENT_PENDING_ART_QA';by[a['id']]['morphology_family']=family(creatures[a['base_creature']])
  if idx%100==0: print('armor batch',idx//100,'forms',idx)
 manifest['asset_generation_batches']=manifest.get('asset_generation_batches',[]);manifest['asset_generation_batches'].append({'batch':'ARMOR_MORPHOLOGY_V2_ALL','scope':'700 armor forms','created':created,'status':'CANDIDATE_REVIEW','approval_required':True,'contains_empty_assets':False,'batch_size':100})
 json.dump(manifest,open(ROOT/'data/assets/asset_manifest.json','w'),ensure_ascii=False,indent=2);json.dump({'created':created,'total_present':created,'status':'CANDIDATE_REVIEW','generator':'v2','batches':7},open(ROOT/'data/qa/armor_asset_generation_v2.json','w'),ensure_ascii=False,indent=2)
 print('created',created)
if __name__=='__main__':main()
