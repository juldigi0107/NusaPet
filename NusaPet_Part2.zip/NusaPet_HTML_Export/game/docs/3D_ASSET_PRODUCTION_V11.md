# NusaPet 3D Asset Production — v11

## Coverage
- 350 creature lines
- 6 primary stages per line = 2,100 primary forms
- 700 Armor Forms
- 2,800 physical GLB resources
- 350 species-specific morphology profiles
- 350 rig/animation profiles
- 2,100 provenance records
- 14 resumable structural QA batches

## Runtime architecture
Each creature is loaded lazily from its manifest path. The runtime creates:
- Skeleton3D anatomical scaffold
- AnimationPlayer
- AnimationTree state-machine equivalent
- collision shape
- attachment sockets
- species-specific GLB instance

The shared animation layer is intentionally anatomical-profile driven. It does not claim that the current generated GLBs have production skin weights; final skinning/animation art QA remains an explicit gate.

## Animation contract
Primary: Idle, Blink, Walk, Run, Eat, Drink, Happy, Sad, Angry, Sleep, Wake, Play, Train, Dirty, Sick, Heal, Interact, Discover, Evolution, Special Idle.

Armor: Idle, Walk, Action, Special, Transform In, Transform Out.

## Asset Lab
`res://scenes/dev/AssetLab.tscn` is developer-only. It loads a real GLB and drives the animation layer for QA. It must never be added to production navigation.

## Approval policy
No generated asset is marked approved. Approval requires visual/art review for silhouette, anatomy, clipping, socket alignment, animation clipping, scale, material/palette, and cultural/provenance checks where applicable.
