# NusaPet Native E2E Plan

## Required builds
- Android development APK
- Android release AAB
- iOS Xcode export
- Windows executable
- macOS app
- Linux executable

## Representative journeys
1. New Player: boot -> language -> habitat -> egg -> hatch -> nickname -> feed/play/clean/rest.
2. Returning Player: load save -> active companion -> camera -> care -> save/reload.
3. Explorer: map -> region -> weather -> expedition -> offline completion -> deterministic reward.
4. Researcher: Nusapedia -> search -> observe clue -> research level -> sources.
5. Evolution Hunter: care -> forecast -> cross branch -> close-score Instinct Choice -> history -> network fog.
6. Pusaka Player: discover -> fragment progression -> Pusaka -> Armor -> revert -> mastery -> Resonance.
7. Collector: multiple companions -> Sanctuary -> switch active -> Legacy Archive -> inheritance.
8. Recovery: interrupt critical save/transform -> relaunch -> transaction/backup recovery -> pet retained.
9. Accessibility: reduced motion, text scale, haptic toggle, accessible time override, low-storage/battery profile.
10. Network failure: cloud unavailable -> Home remains playable -> local save remains authoritative.

## Release evidence
Record device, OS, build hash, Godot version, FPS/memory, screenshots, logs and pass/fail for each journey. A browser screenshot is not accepted as proof of native game completion.
