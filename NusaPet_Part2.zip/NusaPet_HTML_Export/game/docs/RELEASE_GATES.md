# NusaPet Release Gates

## Automated / offline-capable
- 350 creature lines exactly: 250 REAL + 50 MYTHOLOGY/FOLKLORE + 50 MYSTICAL.
- 2,100 primary forms.
- >=700 Armor Forms, with >=2 per creature line.
- 350 Cross-Branch edges with no orphan/self-loop/duplicate edge and an original-lore rationale.
- 15 Pusaka and curated Dual Resonance records.
- Every REAL record has structured taxonomy fields and unique scientific name.
- Every REAL record has a research record that blocks publication until verified.
- Every cultural record has a review record that blocks publication until reviewed.
- Bilingual localization key parity.
- Deterministic lifecycle simulation.
- Content hashes / version manifest.

## Native gates — cannot be honestly passed without Godot/platform tooling
- Godot headless content/static/type/unit tests.
- Native export: Android APK/AAB, iOS/iPadOS Xcode, Windows, macOS, Linux.
- Representative device testing on iPhone/iPad, Android low/mid/high, desktop.
- 60 FPS target / graceful 30 FPS fallback.
- Memory/thermal/battery profiling.
- Crash/recovery and save torture testing.
- Touch, haptics, audio, reduced-motion and accessibility verification.
- Visual regression screenshots from running native builds.

## Scientific / cultural publication gates
REAL factual pages require accepted-name matching, taxonomy, distribution, habitat, conservation status and references from authoritative sources. Sensitive species locations must remain coarse.

Mythology/mystical pages require region, tradition, variants, source and respectful framing. Traditional narrative and original game lore are separate layers.

## No fake completion
A count passing is not equivalent to content quality passing. Procedural fallback geometry is a validated development fallback, not a claim that thousands of final production 3D assets already exist.
