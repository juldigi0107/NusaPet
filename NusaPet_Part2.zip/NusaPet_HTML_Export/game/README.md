
## Engine and release channels

- Engine: Godot 4.x native; validation target: **Godot 4.7.2**.
- Release channels: development, staging, production.
- Production disables incomplete experimental features.
- Native local save remains authoritative offline.
- Updates are deferred while evolution/transformation/save-critical operations are active.

# NusaPet — Living Creatures of the Archipelago

**Rawat. Jelajah. Berevolusi. Kenali Nusantara.**

Native Godot 4.x 3D virtual-creature game architecture derived from the supplied NusaPet v2/v3 master specification.

## Current implementation
- Native Godot scene/node runtime; no browser framework dependency.
- Living 3D habitat with day/night, weather, region context and procedural development geometry.
- 350 creature lines: 250 REAL, 50 MYTHOLOGY/FOLKLORE, 50 MYSTICAL.
- 2,100 primary evolution records (6 stages each).
- 700 curated Armor Forms (minimum 2 per creature line).
- 350 Cross-Branch paths with explicit ORIGINAL GAME LORE rationale and scientific disclaimer.
- 15 Pusaka affinities plus curated Dual Resonance records.
- Care, bond, personality, traits, preferences, Evolution DNA, research and exploration systems.
- Local-first save with atomic writes, backup, migration and critical-operation snapshots.
- Deterministic expedition reward seeds and offline progression.
- Nusapedia with taxonomy tree, research status, factual/game-lore separation and references.
- Bilingual ID/EN UI architecture.
- Sanctuary/Legacy data model and collection progression.
- Supabase schema and deterministic seed export without making cloud services a gameplay dependency.
- Content hashes, research queues, cultural review queue, art prompt generator and QA simulation.
- GitHub Actions CI definition for Python gates and Godot headless gates.

## Scientific data status
All 250 REAL entries now have **structured taxonomy fields** and 250 unique scientific names. This is not the same as external publication verification. Each REAL entry deliberately remains `REVIEW_REQUIRED` until accepted-name matching, distribution, habitat, conservation and references have been independently verified. The online tool `tools/validate_research.py` performs GBIF Species API matching and can optionally use an IUCN token; it never invents missing facts.

## Cultural data status
All 100 mythology/mystical entries have a dedicated cultural review record. They are deliberately `REVIEW_REQUIRED` until region, tradition, variants, sources and respectful framing are reviewed. Supernatural claims are never represented as scientific fact.

## Art status
The project contains 2,800 generated 3D GLB candidates (2,100 primary + 700 Armor) with structural geometry validation, plus prompts/provenance records. They are loadable native assets, but remain `REVIEW_REQUIRED` for species-specific anatomy, clipping, animation, cultural design and final art approval. Procedural fallback remains available as a safety path; it is not counted as final production art.

## QA commands
- `python3 tools/master_software_audit.py` is the software-addressable Master Prompt gate.
- `python3 tools/simulate_lifecycles.py` runs 2,000 lifecycles per player style.
```bash
python3 tools/run_all_qa.py
python3 tools/content_audit.py
python3 tools/validate_localization.py
python3 tools/simulate_lifecycles.py
python3 tools/art_prompt_generator.py
python3 tools/seed_supabase.py
python3 tools/validate_research.py
python3 tools/release_readiness.py
```

With Godot 4.x installed:
```bash
godot --headless --path . --script res://tests/validate_content.gd
godot --headless --path . --script res://tools/static_audit.gd
godot --headless --path . --script res://tools/type_audit.gd
godot --headless --path . --script res://tests/run_unit_tests.gd
```

## Native release matrix
Required release candidates: Android APK/AAB, iOS/iPadOS Xcode export, Windows, macOS and Linux. The current repository documents the matrix but cannot claim those exports passed until the corresponding platform toolchains and devices are actually run.

## Release gate
NusaPet is **not marked complete** until content, scientific/cultural publication, native export, device E2E, performance, accessibility, localization, crash/recovery, save torture and visual regression gates pass. This repository intentionally exposes blocked gates instead of hiding them behind placeholder success states.


## v6 engineering expansion

This iteration adds quest/achievement progression, Perfect Resonance, multiple companions/Sanctuary/Legacy inheritance, expedition-team support, age and evolution forecast/journal/hints, progressive region discovery, cloud conflict merge logic, storage/asset-pack policy, accessibility controls, native audio service architecture, ambient wildlife and world Pusaka objects, plus a reproducible master-spec audit.

Release remains blocked until real Godot runtime/device/export, scientific/cultural review, production 3D art and final audio gates are externally verified. Software-addressable requirements are audited separately; external gates are never converted to PASS without evidence.
