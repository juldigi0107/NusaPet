# NusaPet REAL Species Taxonomy

This directory contains the taxonomy layer required by the NusaPet master specification.

## Coverage

- 250 REAL creature lines
- 250 unique scientific names
- Every REAL line has: Kingdom, Phylum, Class, Order, Family, Genus, Species, Rank
- `real_species_taxonomy.json` is the compact taxonomy index.
- `taxonomy_audit.json` is the structural audit.

## Source policy

The game data does **not** treat an invented hierarchy as scientific proof. The structured hierarchy is a content layer that must be source-matched before a public release.

Primary external matching sources:

1. GBIF Backbone Taxonomy / Species API
2. Catalogue of Life
3. WoRMS for marine taxa where applicable

`tools/validate_taxonomy.py` performs the online GBIF name-match gate in a network-enabled CI/research environment. The core game remains offline and does not call these services frame-by-frame.

## Important distinction

- `taxonomy_complete` = every game record contains a complete taxonomy structure.
- `externally_validated` = the scientific name and hierarchy have been checked against the live authoritative/curated source set.

The second status must never be inferred merely because the first exists.
